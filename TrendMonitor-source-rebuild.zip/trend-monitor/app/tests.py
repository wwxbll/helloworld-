import json
import os
from dataclasses import replace
from datetime import timedelta
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from urllib.parse import urlsplit

from django.core.management import call_command
from django.test import SimpleTestCase, TestCase
from django.utils.timezone import now

from app.collection import collect_one
from app.config import load_yaml, sources
from app.digest import build_digest
from app.matching import Matcher
from app.models import Event, Keyword, Notification, Signal, SourceRun
from app.sources.common import FetchContext, SourceError, _request_proxy
from app.sources.feeds import parse_html
from app.sources.providers import map_rows
from app.summarize import enrich


class RequestProxyTests(SimpleTestCase):
    def test_selection_honors_config_environment_and_loopback(self):
        target = urlsplit("https://www.example.test/")
        fallback = "http://proxy.example.test:8080"
        with (patch.dict(os.environ, {}, clear=True),
              patch("app.sources.common.OPTIONS", {"network": {"proxy": fallback}}),
              patch("app.sources.common.proxy_bypass", return_value=False),
              patch("app.sources.common.getproxies", return_value={"all": "127.0.0.1:3128"})):
            self.assertEqual(_request_proxy(target), fallback)
            os.environ["TREND_PROXY"] = "auto"
            self.assertEqual(_request_proxy(target), "http://127.0.0.1:3128")
            os.environ["TREND_PROXY"] = "direct"
            self.assertIsNone(_request_proxy(target))
            os.environ["TREND_PROXY"] = "socks5://127.0.0.1:1080"
            with self.assertRaises(SourceError) as failure:
                _request_proxy(target)
            self.assertEqual(failure.exception.status, "bad_config")
            for address in ("http://localhost:18765", "http://127.0.0.1:18766", "http://[::1]:18766"):
                self.assertIsNone(_request_proxy(urlsplit(address)))

    def test_no_proxy_can_exclude_a_domain_from_the_explicit_proxy(self):
        with patch.dict(os.environ, {"TREND_PROXY": "http://127.0.0.1:3128", "NO_PROXY": ".example.test"}, clear=True):
            self.assertIsNone(_request_proxy(urlsplit("https://news.example.test/feed")))


class MonitorTests(TestCase):
    def setUp(self):
        call_command("keywords", "import", verbosity=0)
        self.options = sources()
        self.clock = now()

    def test_demo_pipeline_add_keyword_and_disable_source(self):
        with (patch("app.config.PROFILE", "demo"),
              patch("app.collection.PROFILE", "demo"),
              patch("app.views.PROFILE", "demo"),
              patch.dict(os.environ, {"TREND_MODEL_PROVIDER": "rules"})):
            for entry in self.options:
                collect_one(entry, self.clock - timedelta(hours=2), demo_round=1)
                collect_one(entry, self.clock, demo_round=2)
            first = build_digest(self.options, self.clock)
            event = Event.objects.get(title__contains="Orion 2")
            self.assertEqual(set(event.platforms), {"x", "aiweekly", "google"})
            self.assertEqual(event.momentum, "新信号")
            self.assertEqual(len(event.evidence), 3)
            self.assertIn("Google Breakout", first.lines[0])
            self.assertIn("持续发酵", first.lines[1])
            self.assertTrue(Notification.objects.filter(event=event).exists())
            self.assertFalse(Event.objects.filter(title__contains="台积电").exists())
            self.assertTrue(Signal.objects.filter(raw_title__contains="台积电", matched_keywords=[]).exists())
            self.assertEqual(len(event.editorial["angles"]), 2)
            dashboard = self.client.get("/")
            self.assertContains(dashboard, "切入角度")
            self.assertContains(dashboard, "标题草案")
            self.assertContains(dashboard, f'href="#topic-{event.key}" class="board-linked"')
            self.assertNotContains(dashboard, "#WinterMarket")
            self.assertNotContains(dashboard, "#gta6")
            self.assertContains(dashboard, "#OpenAI")
            google = next(board for board in dashboard.context["boards"] if board["id"] == "google")
            self.assertEqual(google["regional_count"], 2)
            self.assertEqual(google["rows"][0]["title"], "NVIDIA Atlas chip shipments")
            self.assertEqual(set(google["rows"][0]["regions"]), {"GB", "US"})
            self.assertEqual(google["rows"][0]["metric"], "20K+")
            self.assertTrue(google["rows"][0]["topic_url"])
            self.assertEqual(len(google["rows"]), 1)
            domestic = self.client.get("/", {"board_group": "domestic"})
            domestic_boards = {board["id"]: board for board in domestic.context["boards"]}
            self.assertTrue({"weibo", "baidu", "douyin", "bilibili", "xiaohongshu", "ithome"} <= domestic_boards.keys())
            self.assertNotIn("google", domestic_boards)
            self.assertTrue(domestic_boards["weibo"]["rows"])
            self.assertEqual([row["rank"] for row in domestic_boards["weibo"]["rows"]], [11])
            international = self.client.get("/", {"board_group": "international"})
            self.assertEqual({board["id"] for board in international.context["boards"]},
                             {"x", "google", "tiktok", "reddit", "hackernews"})
            self.assertEqual(domestic.context["total"], international.context["total"])
            detail = self.client.get(f"/events/{event.key}/")
            self.assertContains(detail, "3 条")
            self.assertContains(detail, event.editorial["title_draft"])
            self.assertEqual(self.client.get("/api/notifications/").json()["items"][0]["path"],
                             f"/events/{event.key}/")

            Keyword.objects.create(key="tsmc", label="台积电", aliases=["TSMC", "台積電"], weight=1.25)
            build_digest(self.options, self.clock, notify=False)
            tsmc = Event.objects.get(title__contains="台积电")
            self.assertEqual(tsmc.keywords, ["台积电"])
            self.assertTrue(Signal.objects.filter(raw_title__contains="台积电",
                                                  matched_keywords=["tsmc"]).exists())
            scoped = self.client.get("/", {"topic": "台积电"})
            self.assertContains(scoped, "台积电先进封装扩产")
            scoped_weibo = next(board for board in scoped.context["boards"] if board["id"] == "weibo")
            self.assertEqual([row["title"] for row in scoped_weibo["rows"]], ["台积电先进封装扩产"])
            self.assertEqual([event.keywords for event in scoped.context["page"]], [["台积电"]])

            updated = [replace(entry, enabled=False) if entry.id == "x_trends" else entry for entry in self.options]
            count = Signal.objects.filter(source="x_trends").count()
            run = collect_one(updated[0], self.clock)
            self.assertEqual(run.status, "disabled")
            build_digest(updated, self.clock)
            event.refresh_from_db()
            self.assertEqual(Signal.objects.filter(source="x_trends").count(), count)
            self.assertNotIn("x", event.platforms)
            with patch("app.views.sources", return_value=updated):
                self.assertNotIn(f"/events/{event.key}/", [item["path"] for item in
                                  self.client.get("/api/notifications/").json()["items"]])

    def test_imported_snapshot_retains_time_and_does_not_add_event(self):
        stamp = self.clock - timedelta(days=5)
        payload = {
            "board": "reddit", "observed_at": stamp.isoformat(),
            "scope": "r/artificial · 样本", "source": "示例共享榜",
            "rows": [
                {"rank": 1, "title": "Poker chips advice"},
                {"rank": 3, "title": "NVIDIA GPU discussion", "metric": "42 赞", "url": "javascript:bad()"},
            ],
        }
        with TemporaryDirectory() as directory:
            path = Path(directory) / "snapshot.json"
            path.write_text(json.dumps(payload), encoding="utf-8")
            call_command("import_board", str(path))
            call_command("import_board", str(path))
        dashboard = self.client.get("/")
        board = next(item for item in dashboard.context["boards"] if item["id"] == "reddit")
        self.assertEqual(board["observed_at"], stamp)
        self.assertEqual(board["status"], "暂未更新")
        self.assertTrue(board["imported"])
        self.assertEqual([row["rank"] for row in board["rows"]], [3])
        self.assertEqual(board["rows"][0]["url"], "")
        self.assertEqual(board["rows"][0]["topic_url"], "")
        self.assertFalse(Event.objects.exists())

    def test_sync_applies_complete_keyword_file_including_removals(self):
        with TemporaryDirectory() as directory:
            path = Path(directory) / "keywords.yaml"
            path.write_text("- key: ai\n  label: 人工智能\n  aliases: [AI, 推理模型]\n", encoding="utf-8")
            call_command("keywords", "import", path, sync=True)
        self.assertEqual(list(Keyword.objects.filter(enabled=True).values_list("key", flat=True)), ["ai"])
        self.assertEqual(Keyword.objects.get(key="ai").aliases, ["AI", "推理模型"])

    def test_baidu_board_preserves_rank_and_excludes_unranked_pin(self):
        entry = next(source for source in self.options if source.id == "baidu_realtime")
        page = """
        <div class="category-wrap_test">
          <div class="index_test"><img src="pin.png"></div>
          <a class="title_test"><div class="c-single-text-ellipsis">置顶话题</div></a>
        </div>
        <div class="category-wrap_test">
          <div class="index_test">1</div>
          <a class="title_test" href="https://www.baidu.com/s?wd=GPU">
            <div class="c-single-text-ellipsis">GPU 新产品</div><span>热</span>
          </a>
          <div class="hot-index_test">7500000</div>
        </div>
        """
        context = FetchContext(self.clock, 10, 12, [], "")
        rows, _ = parse_html(page.encode("utf-8"), entry.options, context)
        self.assertEqual([(row.title, row.rank, row.heat, row.region) for row in rows],
                         [("GPU 新产品", 1, 7500000, "CN")])

    def test_model_editorial_augments_summary(self):
        row = {"keywords": ["芯片"], "category": "芯片", "momentum": "首次观察", "editorial": {},
               "evidence": [{"raw_title": "Example GPU ships to developers"}]}
        result = {"id": 1, "category": "人工智能", "summary": "示例 GPU 向开发者开放交付。",
                  "angles": [
                      {"heading": "首批供给", "approach": "查看开发者招募范围与实际配送名单。"},
                      {"heading": "开发者反馈", "approach": "采访先拿到硬件的开发者核实初期体验。"},
                  ], "title_draft": "示例 GPU 开始交付，首批面向哪些开发者？"}
        response = {"choices": [{"message": {"content": json.dumps({"events": [result]})}}]}
        with (patch.dict(os.environ, {"TREND_MODEL_PROVIDER": "local_openai",
                                     "TREND_MODEL_URL": "http://127.0.0.1:18766/v1"}),
              patch("app.summarize.editorial_config", return_value={"prompt": "核实芯片的交付时间。"}),
              patch("app.summarize.read_json", return_value=response) as upstream):
            enrich([row])
        self.assertIn("核实芯片的交付时间。", upstream.call_args.kwargs["payload"]["messages"][0]["content"])
        self.assertEqual(row["editorial"]["title_draft"], result["title_draft"])
        self.assertEqual(row["editorial"]["angles"], result["angles"])
        self.assertEqual(row["category"], "芯片")

    def test_google_related_search_marks_breakout_and_preserves_origin(self):
        source = next(item for item in self.options if item.id == "google_rising")
        context = FetchContext(self.clock, 1, 12, ["OpenAI"], "")
        rows = map_rows([{
            "relatedQueries": {"rising": [{"query": "Orion 2 release", "formattedValue": "Breakout",
                                           "value": 12000}]},
            "provenance": {"canonicalUrl": "https://trends.google.com/trends/explore?q=OpenAI",
                           "request": {"terms": ["OpenAI"]}},
        }], source.options, context)
        self.assertEqual(rows[0].kind, "breakout")
        self.assertIn("OpenAI", rows[0].text)
        self.assertEqual(rows[0].url_kind, "trend")
        matcher = Matcher(Keyword.objects.filter(enabled=True))
        self.assertEqual(matcher.match(rows[0].title, rows[0].text, kind=rows[0].kind), [])

    def test_extension_loads_through_config_and_uses_normal_pipeline(self):
        from app.config import Source

        entry = Source(**load_yaml("examples/hackernews.yaml")[0])
        with patch("app.sources.hackernews.read_json", side_effect=[
            [128], {"title": "NVIDIA plans new GPU release", "score": 45, "time": int(self.clock.timestamp())},
        ]):
            run = collect_one(entry, self.clock)
        self.assertEqual(run.status, "ok")
        self.assertEqual(run.matched_count, 1)
        signal = Signal.objects.get(run=run)
        self.assertEqual(signal.platform, "hackernews")
        self.assertEqual(signal.rank, 1)

    def test_no_apify_execution_without_free_account_confirmation(self):
        with (patch.dict(os.environ, {"APIFY_TOKEN": "synthetic-token", "APIFY_FREE_PLAN_CONFIRMED": ""}),
              patch("app.collection.fetch") as upstream):
            run = collect_one(self.options[0], self.clock)
        self.assertEqual(run.status, "free_only")
        upstream.assert_not_called()
        self.assertTrue(SourceRun.objects.filter(source="x_trends", status="free_only").exists())

    def test_manual_refreshes_minutes_apart_are_not_counted_as_sustained(self):
        entry = next(item for item in self.options if item.id == "aiweekly_live")
        with (patch("app.config.PROFILE", "demo"),
              patch("app.collection.PROFILE", "demo"),
              patch.dict(os.environ, {"TREND_MODEL_PROVIDER": "rules"})):
            collect_one(entry, self.clock - timedelta(minutes=5), demo_round=2)
            collect_one(entry, self.clock, force=True, demo_round=2)
            build_digest([entry], self.clock, notify=False)
            self.assertEqual(Event.objects.get(title__contains="Orion 2").momentum, "首次观察")
