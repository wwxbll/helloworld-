from pathlib import Path

import yaml
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from app.config import CONFIG_DIR
from app.models import Keyword


class Command(BaseCommand):
    help = "Import or export the active keyword table."

    def add_arguments(self, parser):
        parser.add_argument("operation", choices=["import", "export"])
        parser.add_argument("file", nargs="?", type=Path)
        parser.add_argument("--sync", action="store_true", help="Apply the full list and disable omitted keywords.")

    def handle(self, operation, file, sync, **kwargs):
        if operation == "export":
            if sync:
                raise CommandError("--sync 只能与 import 一起使用。")
            rows = list(Keyword.objects.values("key", "label", "aliases", "seeds", "weight", "enabled"))
            contents = yaml.safe_dump(rows, allow_unicode=True, sort_keys=False)
            if file:
                file.write_text(contents, encoding="utf-8")
            else:
                self.stdout.write(contents)
            return

        path = file or CONFIG_DIR / "keywords.yaml"
        rows = yaml.safe_load(path.read_text(encoding="utf-8"))
        if not isinstance(rows, list) or any(
            not isinstance(row, dict) or not isinstance(row.get("key"), str) for row in rows
        ):
            raise CommandError("关注词文件应为列表，每项都需要字符串 key。")
        keys = {row["key"] for row in rows}
        if len(keys) != len(rows):
            raise CommandError("关注词 key 不能重复。")
        defaults = {"label": "", "aliases": [], "seeds": [], "weight": 1, "enabled": True}
        with transaction.atomic():
            for row in rows:
                keyword = Keyword.objects.filter(key=row["key"]).first() or Keyword(key=row["key"])
                for field, default in defaults.items():
                    if sync or field in row:
                        setattr(keyword, field, row.get(field, default))
                keyword.full_clean()
                keyword.save()
            disabled = Keyword.objects.filter(enabled=True).exclude(key__in=keys).update(enabled=False) if sync else 0
        self.stdout.write(f"已导入 {len(rows)} 条关注词" + (f"，另停用 {disabled} 条" if disabled else ""))
