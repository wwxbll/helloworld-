import json
from datetime import timedelta
from pathlib import Path

from django.core.management.base import BaseCommand, CommandError
from django.utils import timezone
from django.utils.dateparse import parse_datetime

from app.collection import safe_url
from app.config import OPTIONS
from app.models import BoardSnapshot


class Command(BaseCommand):
    help = "Import a timestamped, authorized ranking snapshot from a local JSON file."

    def add_arguments(self, parser):
        parser.add_argument("file", type=Path)

    def handle(self, file, **kwargs):
        if not file.is_file() or file.stat().st_size > 256_000:
            raise CommandError("请输入不超过 256 KB 的 JSON 文件。")
        try:
            payload = json.loads(file.read_text(encoding="utf-8"))
            board_id = payload["board"]
            stamp = parse_datetime(payload["observed_at"])
            source = text(payload["source"], 80)
            scope = text(payload.get("scope", ""), 160, required=False)
            rows = payload["rows"]
        except (OSError, KeyError, ValueError, TypeError, AttributeError) as exc:
            raise CommandError("快照的 JSON 或必填字段格式无效。") from exc

        if not isinstance(board_id, str) or board_id not in {board["id"] for board in OPTIONS.get("boards", [])}:
            raise CommandError("榜单标识无效。")
        if not stamp or timezone.is_naive(stamp) or stamp > timezone.now() + timedelta(minutes=5):
            raise CommandError("observed_at 必须是带时区的实际榜单时间。")
        if not isinstance(rows, list) or not 1 <= len(rows) <= 100:
            raise CommandError("rows 必须含 1 到 100 条。")
        normalized = []
        seen = set()
        try:
            for row in rows:
                rank = row["rank"]
                if type(rank) is not int or not 1 <= rank <= 1000 or rank in seen:
                    raise ValueError(rank)
                seen.add(rank)
                normalized.append({
                    "rank": rank, "title": text(row["title"], 500),
                    "metric": text(row.get("metric", ""), 80, required=False),
                    "url": safe_url(text(row.get("url", ""), 1800, required=False)),
                    "regions": [],
                })
        except (AttributeError, KeyError, TypeError, ValueError) as exc:
            raise CommandError("每行需要唯一整数排名和标题，热度及链接可选。") from exc
        BoardSnapshot.objects.update_or_create(
            board=board_id, observed_at=stamp,
            defaults={"source": source, "scope": scope, "rows": normalized},
        )
        self.stdout.write(f"已保存 {board_id} 榜单，{len(normalized)} 条。")


def text(value, limit, required=True):
    if not isinstance(value, str):
        raise ValueError(value)
    value = " ".join(value.split())
    if len(value) > limit or (required and not value):
        raise ValueError(value)
    return value
