from datetime import timedelta

from django.urls import reverse

from app.collection import DATA_STATES, safe_url
from app.config import OPTIONS
from app.matching import normalize
from app.models import BoardSnapshot, Signal, SourceRun


def _entries(source, board, matcher):
    filters = {"kind": board["kind"]}
    if board.get("region"):
        filters["region"] = board["region"]
    run = (SourceRun.objects.filter(source=source, status__in=DATA_STATES, row_count__gt=0)
           .filter(**{f"signals__{key}": value for key, value in filters.items()})
           .order_by("-started_at", "-pk").first())
    if not run:
        return None
    rows = []
    signals = Signal.objects.filter(run=run, **filters).order_by("pk")
    for position, signal in enumerate(signals, 1):
        metric = signal.heat_label
        if signal.heat is not None:
            if board.get("metric_suffix"):
                metric = f'{signal.heat:,.0f} {board["metric_suffix"]}'
            elif not metric:
                metric = f"{signal.heat:,.0f}"
        rows.append({
            "rank": signal.rank or position, "title": signal.raw_title, "url": safe_url(signal.url),
            "metric": metric, "heat": signal.heat, "regions": [signal.region] if signal.region else [],
            "signal_ids": [signal.pk],
            "keys": matcher.match(signal.raw_title, signal.signal_text, kind=signal.kind),
        })
    return run.snapshot_at or run.started_at, rows


def _prominence(row):
    return (-(row["heat"] if row["heat"] is not None else -1), row["rank"], normalize(row["title"]))


def _merge_google(rows):
    grouped = {}
    for row in sorted(rows, key=_prominence):
        key = normalize(row["title"])
        if key in grouped:
            existing = grouped[key]
            existing["regions"] = list(dict.fromkeys(existing["regions"] + row["regions"]))
            existing["signal_ids"].extend(row["signal_ids"])
            existing["keys"] = list(dict.fromkeys(existing["keys"] + row["keys"]))
        else:
            grouped[key] = row
    combined = sorted(grouped.values(), key=lambda row: (-len(row["regions"]), *_prominence(row)))
    for rank, row in enumerate(combined, 1):
        row["rank"] = rank
    return combined


def _linked_events(events, on_page):
    links = {}
    for event in events:
        url = f"#topic-{event.key}" if event.key in on_page else reverse("event", args=[event.key])
        for evidence in event.evidence:
            if evidence.get("id") is not None:
                links.setdefault(evidence["id"], url)
    return links


def board_cards(config, coverage, source_labels, events, page, now, matcher, allowed_keys, group=""):
    source_map = {source.id: source for source in config if source.active}
    links = _linked_events(events, {event.key for event in page})
    for settings in OPTIONS.get("boards", []):
        if group and settings.get("group", "international") != group:
            continue
        board = {**settings, "rows": [], "observed_at": None, "older_at": None,
                 "status": "", "detail": "", "imported": False, "regional_count": 0}
        sources = settings["sources"]
        collected = [
            snapshot for source in sources if source in source_map
            if (snapshot := _entries(source, settings, matcher))
        ]
        manual = BoardSnapshot.objects.filter(board=settings["id"]).order_by("-observed_at", "-pk").first()
        observed = max((snapshot[0] for snapshot in collected), default=None)
        if manual and (not observed or manual.observed_at > observed):
            board.update(
                rows=[{**row, "keys": matcher.match(row["title"])}
                      for row in sorted(manual.rows, key=lambda row: row["rank"])],
                observed_at=manual.observed_at, scope=manual.scope or settings["scope"],
                provider=manual.source, imported=True,
            )
        elif collected:
            available = [row for _, rows in collected for row in rows]
            rows = (_merge_google(available) if settings["id"] == "google"
                    else sorted(available, key=lambda row: row["rank"]))
            board.update(rows=rows, observed_at=observed, regional_count=len(collected),
                         older_at=min(snapshot[0] for snapshot in collected))
        if board["observed_at"]:
            cutoff = now - timedelta(hours=settings["stale_hours"])
            if board["observed_at"] < cutoff:
                board["status"] = "暂未更新"
            elif board["older_at"] and board["older_at"] < cutoff:
                board["status"] = "部分地区待更新"
            elif not board["imported"] and len(collected) < len(sources):
                board["status"] = "部分地区可用"
            elif not board["imported"] and all(
                coverage.get(source, {}).get("status") not in DATA_STATES
                or not coverage.get(source, {}).get("rows") for source in sources
            ):
                board["status"] = "暂未更新"
        else:
            states = [coverage.get(source, {}) for source in sources]
            preferred = next((state for state in states if state.get("status") in {
                "missing_key", "free_only", "unavailable", "rate_limited", "blocked", "http_error",
                "network_error", "shape_changed", "quota", "local_quota", "stale",
                "robots_blocked", "bad_payload", "bad_config", "disabled",
            }), {})
            board["status"] = source_labels.get(preferred.get("status"), "暂无数据")
            board["detail"] = preferred.get("detail", "")
        board["rows"] = [row for row in board["rows"] if allowed_keys.intersection(row["keys"])][:settings["limit"]]
        for row in board["rows"]:
            row["topics"] = [matcher.keywords[key].label for key in row["keys"]]
            row["topic_url"] = next((links[id_] for id_ in row.get("signal_ids", []) if id_ in links), "")
        yield board
