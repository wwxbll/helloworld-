import os
import re
from dataclasses import dataclass
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
CONFIG_DIR = Path(os.getenv("TREND_CONFIG_DIR", ROOT / "config")).resolve()
DATA_DIR = Path(os.getenv("TREND_DATA_DIR", ROOT / "data")).resolve()
PROFILE = os.getenv("TREND_PROFILE", "live")
if PROFILE not in {"live", "demo"}:
    raise ValueError("TREND_PROFILE must be live or demo")


def load_yaml(name):
    with (CONFIG_DIR / name).open(encoding="utf-8") as file:
        return yaml.safe_load(file)


OPTIONS = load_yaml("app.yaml")


@dataclass(frozen=True)
class Source:
    id: str
    name: str
    platform: str
    adapter: str
    enabled: bool
    interval_minutes: int
    options: dict
    credential_env: str = ""
    paid: bool = False
    demo_enabled: bool | None = None

    @property
    def active(self):
        if PROFILE == "demo" and self.demo_enabled is not None:
            return self.demo_enabled
        return self.enabled


def sources():
    entries = [Source(**entry) for entry in load_yaml("sources.yaml")["sources"]]
    if len({entry.id for entry in entries}) != len(entries):
        raise ValueError("Duplicate source IDs in sources.yaml")
    for entry in entries:
        if not re.fullmatch(r"[a-z][a-z0-9_]{0,63}", entry.id) or entry.interval_minutes < 60:
            raise ValueError(f"Invalid ID or interval for {entry.id}")
        if entry.paid and entry.enabled:
            raise ValueError(f"{entry.id} is a paid path and cannot be enabled in this release")
    return entries
