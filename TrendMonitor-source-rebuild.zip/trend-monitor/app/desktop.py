import argparse
import hashlib
import json
import os
import re
import sys
from pathlib import Path
from urllib.parse import urlsplit

from PySide6.QtCore import QPoint, Qt, QTimer, QUrl
from PySide6.QtGui import QColor, QDesktopServices, QIcon, QPainter, QPixmap
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkReply, QNetworkRequest
from PySide6.QtWidgets import QApplication, QFrame, QLabel, QMenu, QPushButton, QSystemTrayIcon, QVBoxLayout, QWidget

from app.config import DATA_DIR, OPTIONS

EVENT_PATH = re.compile(r"/events/[a-f0-9]{32}/")


def icon():
    image = QPixmap(32, 32)
    image.fill(Qt.GlobalColor.transparent)
    painter = QPainter(image)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.setPen(Qt.PenStyle.NoPen)
    for inset, color in [(1, "#164640"), (6, "#c6e6db"), (8, "#164640"), (12, "#c6e6db")]:
        painter.setBrush(QColor(color))
        painter.drawEllipse(inset, inset, 32 - 2 * inset, 32 - 2 * inset)
    painter.end()
    return QIcon(image)


class Toast(QWidget):
    def __init__(self, title, body, *, demo, opening):
        flags = (Qt.WindowType.Tool | Qt.WindowType.FramelessWindowHint
                 | Qt.WindowType.WindowStaysOnTopHint | Qt.WindowType.WindowDoesNotAcceptFocus)
        super().__init__(None, flags)
        self.setWindowTitle("热点雷达 · 桌面通知")
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setStyleSheet("""
            QWidget { background: #f7fbf9; color: #213c36; font: 13px 'Microsoft YaHei UI', sans-serif; }
            #shell { border: 1px solid #7fa59a; background: #f7fbf9; }
            #eyebrow { font-size: 12px; color: #416b60; }
            #title { font-size: 19px; font-weight: 700; color: #164640; }
            #body { font-size: 14px; color: #293c36; }
            QPushButton { background: #164640; border: 0; color: white; border-radius: 5px; padding: 5px 9px; }
            QPushButton:hover { background: #236d63; }
        """)
        self.setFixedWidth(416)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        frame = QFrame()
        frame.setObjectName("shell")
        outer.addWidget(frame)
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(15, 11, 15, 11)
        layout.setSpacing(5)
        heading = title.removeprefix("热点雷达 · ")
        labels = [
            ("eyebrow", "热点雷达 · 演示样本" if demo else "热点雷达 · 舆情推送"),
            ("title", heading), ("body", body),
        ]
        for name, text in labels:
            label = QLabel(text)
            label.setObjectName(name)
            label.setTextFormat(Qt.TextFormat.PlainText)
            label.setWordWrap(True)
            layout.addWidget(label)
        button = QPushButton("查看完整事件  ›")
        button.setCursor(Qt.CursorShape.PointingHandCursor)
        button.clicked.connect(opening)
        layout.addWidget(button, alignment=Qt.AlignmentFlag.AlignLeft)

    def show_bottom_right(self):
        self.adjustSize()
        desktop = QApplication.primaryScreen().availableGeometry()
        self.move(desktop.right() - self.width() - 15, desktop.bottom() - self.height() - 15)
        self.show()
        self.raise_()


class DesktopClient:
    def __init__(self, app, base_url, profile, backend, once=False, capture=None):
        self.app = app
        self.base_url = base_url
        self.profile = profile
        self.once = once
        self.backend = backend
        self.capture = capture
        self.toast = None
        self.reply = None
        self.notice_url = None
        self.http = QNetworkAccessManager()
        self.token = os.getenv("TREND_NOTIFY_TOKEN", "")
        key = hashlib.sha256(f"{base_url}/{profile}".encode()).hexdigest()[:16]
        self.cursor_path = DATA_DIR / f"desktop-{key}.cursor"
        try:
            self.cursor = int(self.cursor_path.read_text(encoding="ascii").strip()) if not capture else 0
        except (OSError, ValueError):
            self.cursor = 0
        self.tray = QSystemTrayIcon(icon())
        self.tray.setToolTip("热点雷达")
        self.menu = QMenu()
        self.menu.addAction("打开热点雷达", lambda: QDesktopServices.openUrl(QUrl(self.base_url + "/")))
        self.menu.addAction("退出", self.app.quit)
        self.tray.setContextMenu(self.menu)
        self.tray.messageClicked.connect(self.open_notice)
        if not self.once or self.backend == "native":
            self.tray.show()
        self.poller = QTimer()
        self.poller.timeout.connect(self.poll)
        if not once:
            self.poller.start(1000 * OPTIONS["notification"]["poll_seconds"])
        QTimer.singleShot(0, self.poll)

    def poll(self):
        if self.reply is not None:
            return
        req = QNetworkRequest(QUrl(f"{self.base_url}/api/notifications/?after={self.cursor}"))
        req.setTransferTimeout(5000)
        req.setAttribute(QNetworkRequest.Attribute.RedirectPolicyAttribute,
                         QNetworkRequest.RedirectPolicy.ManualRedirectPolicy)
        if self.token:
            req.setRawHeader(b"Authorization", f"Bearer {self.token}".encode())
        self.reply = self.http.get(req)
        self.reply.finished.connect(self.received)

    def received(self):
        resp, self.reply = self.reply, None
        if resp.error() != QNetworkReply.NetworkError.NoError:
            error = resp.errorString()
            resp.deleteLater()
            if self.once:
                print(f"通知读取失败 · {error}", file=sys.stderr)
                self.app.exit(1)
            return
        body = bytes(resp.readAll())
        resp.deleteLater()
        try:
            packet = json.loads(body)
            if packet["profile"] != self.profile:
                raise ValueError("dashboard profile mismatch")
            items = packet["items"]
            if not items:
                if self.once:
                    print("暂无符合条件的未查看通知。")
                    self.app.exit(2)
                return
            item = items[0]
            if not EVENT_PATH.fullmatch(item["path"]) or type(item["id"]) is not int:
                raise ValueError("invalid notification data")
            self.show(item)
            self.cursor = item["id"]
            if not self.capture:
                self.cursor_path.parent.mkdir(parents=True, exist_ok=True)
                pending = self.cursor_path.with_suffix(".tmp")
                pending.write_text(str(self.cursor), encoding="ascii")
                pending.replace(self.cursor_path)
        except (ValueError, KeyError, TypeError, OSError) as exc:
            if self.once:
                print(f"通知无效 · {type(exc).__name__}", file=sys.stderr)
                self.app.exit(1)

    def open_notice(self):
        if self.notice_url:
            QDesktopServices.openUrl(QUrl(self.notice_url))
        if self.toast:
            self.toast.close()

    def show(self, item):
        self.notice_url = self.base_url + item["path"]
        duration = 1000 * OPTIONS["notification"]["display_seconds"]
        if self.backend == "native":
            self.tray.showMessage(item["title"], item["body"], QSystemTrayIcon.MessageIcon.Information, duration)
        else:
            if self.toast:
                self.toast.close()
            self.toast = Toast(item["title"], item["body"], demo=self.profile == "demo", opening=self.open_notice)
            self.toast.show_bottom_right()
            QTimer.singleShot(duration, self.toast.close)
            if self.capture:
                QTimer.singleShot(650, self.capture_toast)
        if self.once:
            QTimer.singleShot(duration, self.app.quit)

    def capture_toast(self):
        if not self.toast or not self.toast.isVisible():
            self.app.exit(1)
            return
        screen = QApplication.primaryScreen()
        geom = self.toast.geometry()
        desktop = screen.availableGeometry()
        origin = screen.geometry().topLeft()
        pos = self.toast.mapToGlobal(QPoint(0, 0)) - origin
        shot = screen.grabWindow(0, pos.x(), pos.y(), geom.width(), geom.height())
        self.capture.parent.mkdir(parents=True, exist_ok=True)
        if not shot.save(str(self.capture)):
            print("截图失败。", file=sys.stderr)
            self.app.exit(1)
            return
        print(f"桌面通知已显示并截图 · {self.capture} · 窗口 {geom.getRect()} · 可用工作区 {desktop.getRect()}",
              flush=True)


def main():
    parser = argparse.ArgumentParser(description="Display Trend Monitor notifications.")
    parser.add_argument("--url", default=os.getenv("TREND_PUBLIC_URL") or f"http://127.0.0.1:{OPTIONS['web']['port']}")
    parser.add_argument("--demo", action="store_true")
    parser.add_argument("--backend", choices=["qt", "native"], default="qt")
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--capture", type=Path, help="Capture the actual visible Qt popup during one-shot QA.")
    args = parser.parse_args()
    parts = urlsplit(args.url)
    local = parts.hostname in {"localhost", "127.0.0.1", "::1"}
    if (not parts.hostname or parts.username or parts.password or parts.query or parts.fragment
            or (parts.scheme != "https" and not (local and parts.scheme == "http"))):
        parser.error("Remote notification URLs must use HTTPS.")
    if args.capture and (args.backend != "qt" or not args.once):
        parser.error("--capture requires --once and the Qt backend")

    app = QApplication([sys.argv[0]])
    app.setQuitOnLastWindowClosed(False)
    client = DesktopClient(app, args.url.rstrip("/"), "demo" if args.demo else "live",
                           args.backend, args.once, args.capture)
    try:
        return app.exec()
    finally:
        client.tray.hide()


if __name__ == "__main__":
    sys.exit(main())
