import re
import unicodedata


def normalize(text):
    return " ".join(unicodedata.normalize("NFKC", text).casefold().split())


def phrase_pattern(phrase):
    phrase = normalize(phrase)
    beginning = r"(?<![a-z0-9])" if phrase[:1].isascii() and phrase[:1].isalnum() else ""
    ending = r"(?![a-z0-9])" if phrase[-1:].isascii() and phrase[-1:].isalnum() else ""
    return re.compile(beginning + re.escape(phrase) + ending)


class Matcher:
    def __init__(self, keywords):
        self.keywords = {keyword.key: keyword for keyword in keywords}
        self.patterns = {}
        for key, keyword in self.keywords.items():
            values = {normalize(word) for word in [keyword.label, *keyword.aliases] if word.strip()}
            self.patterns[key] = [phrase_pattern(value) for value in sorted(values, key=len, reverse=True)]

    def match(self, title, text="", *, kind=""):
        if kind in {"rising", "breakout"}:
            # Google query seeds are provenance and do not establish what the query is about.
            text = ""
        data = normalize(f"{title} {text}")
        return [key for key, patterns in self.patterns.items() if any(p.search(data) for p in patterns)]

    def without_aliases(self, text, keys):
        for key in keys:
            for pattern in self.patterns[key]:
                text = pattern.sub(" ", text)
        return text
