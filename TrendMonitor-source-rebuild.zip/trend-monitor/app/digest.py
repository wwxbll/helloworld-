import uuid
from collections import defaultdict
from datetime import timedelta

from django.db import transaction

from app.collection import DATA_STATES, hash_value, source_gate
from app.config import OPTIONS
from app.editorial import editorial_config, rule_editorial
from app.events import cluster_signals, event_summary
from app.matching import Matcher, normalize, phrase_pattern
from app.models import Digest, Event, Keyword, Notification, Signal, SourceRun
from app.summarize import SYSTEM, digest_lines, enrich, model_config

CACHE_VERSION = 5


def coverage_for(sources):
    coverage = {}
    for source in sources:
        gate = source_gate(source)
        history = SourceRun.objects.filter(source=source.id).order_by("-started_at", "-pk")
        run = history.first()
        status, detail = gate or ((run.status, run.detail) if run else ("pending", "等待第一次采集。"))
        data = history.filter(status__in=DATA_STATES).first() if status == "unchanged" else run
        coverage[source.id] = {
            "name": source.name, "platform": source.platform, "status": status, "detail": detail,
            "rows": data.row_count if data and not gate else 0,
            "matches": data.matched_count if data and not gate else 0,
            "checked_at": run.started_at.isoformat() if run else None,
            "snapshot_at": run.snapshot_at.isoformat() if run and run.snapshot_at else None,
        }
    return coverage


def _prepare(sources, matcher, now):
    history_cutoff = now - timedelta(hours=OPTIONS["collection"]["active_hours"])
    packets = {}
    heat_values = defaultdict(list)
    signals = []
    changed = []
    run_counts = {}
    for source in sources:
        if source_gate(source):
            continue
        runs = list(SourceRun.objects.filter(source=source.id, started_at__gte=history_cutoff,
                                             status__in=DATA_STATES)
                    .order_by("-started_at", "-pk"))
        if not runs:
            continue
        freshness = timedelta(minutes=max(180, source.interval_minutes * 2))
        if now - runs[0].started_at > freshness:
            check = SourceRun.objects.filter(source=source.id, status="unchanged",
                                             started_at__gte=now-freshness,
                                             snapshot_key=runs[0].snapshot_key).exists()
            if not check:
                continue
        packets[source.id] = runs
        run_counts.update({row.pk: 0 for row in runs})
        for signal in Signal.objects.filter(run_id__in=[row.pk for row in runs]).order_by("-observed_at", "pk"):
            if signal.heat is not None:
                heat_values[signal.run_id].append(signal.heat)
            matches = matcher.match(signal.raw_title, signal.signal_text, kind=signal.kind)
            if signal.matched_keywords != matches:
                signal.matched_keywords = matches
                changed.append(signal)
            if signal.matched_keywords:
                signals.append(signal)
                run_counts[signal.run_id] += 1
    if changed:
        with transaction.atomic():
            Signal.objects.bulk_update(changed, ("matched_keywords",), batch_size=100)
            for run in (item for group in packets.values() for item in group):
                if run.matched_count != run_counts[run.pk]:
                    SourceRun.objects.filter(pk=run.pk).update(matched_count=run_counts[run.pk])
    return packets, heat_values, signals


def _identify(rows, previous):
    known = defaultdict(list)
    for event in previous:
        for signature in event.signatures:
            known[signature].append(event)
    claimed = set()
    edits = []
    for row in rows:
        choices = [item for signature in row["signatures"] for item in known[signature] if item.key not in claimed]
        event = min(choices, key=lambda entry: entry.first_seen) if choices else Event(key=uuid.uuid4().hex)
        if choices:
            row["first_seen"] = min(row["first_seen"], event.first_seen)
        claimed.add(event.key)
        for name, value in row.items():
            setattr(event, name, value)
        event.active = True
        edits.append(event)
    return edits, claimed


def notification_signature(event):
    return hash_value([event.platforms, any(row["kind"] == "breakout" for row in event.evidence)])


def _queue(events, digest, now):
    options = OPTIONS["notification"]
    for event in events:
        if event.score < options["min_score"] or event.momentum == "标签观察":
            continue
        if now - event.last_seen > timedelta(hours=options["max_age_hours"]):
            continue
        previous = Notification.objects.filter(event=event).order_by("-created_at").first()
        signature = notification_signature(event)
        if previous:
            if previous.signature == signature or now - previous.created_at < timedelta(hours=options["cooldown_hours"]):
                continue
        body = (event.summary or event.title)[:110].rstrip("。！？")
        status = f"{event.momentum} · {len(event.platforms)} 个来源"
        Notification.objects.create(event=event, digest=digest, created_at=now, signature=signature,
                                    title=("热点雷达 · " + status)[:160], body=body + "。")
        return


def build_digest(sources, now, *, notify=True):
    matcher = Matcher(Keyword.objects.filter(enabled=True))
    editorial = editorial_config()
    packets, heat_values, signals = _prepare(sources, matcher, now)
    coverage = coverage_for(sources)
    key = hash_value([
        CACHE_VERSION, [(key, item.label, item.weight, item.aliases) for key, item in matcher.keywords.items()],
        [s.pk for s in signals], coverage, OPTIONS["ranking"], model_config()[:3], SYSTEM, editorial,
    ])
    latest = Digest.objects.order_by("-created_at", "-pk").first()
    if latest and latest.input_key == key:
        if notify and not Notification.objects.filter(digest=latest).exists():
            current = list(Event.objects.filter(active=True))
            _queue(current, latest, now)
        return latest
    source_map = {source.id: source for source in sources}
    moments = []
    priority = [phrase_pattern(term) for term in editorial["priority_terms"] if term.strip()]
    current_ids = {runs[0].pk for runs in packets.values()}
    for cluster in cluster_signals(signals, matcher):
        if not any(signal.run_id in current_ids for signal in cluster.signals):
            continue
        event = event_summary(cluster, matcher, source_map, packets, heat_values, now)
        event["editorial"] = rule_editorial(event["title"], event["evidence"], event["momentum"],
                                            editorial["fallback"])
        titles = [normalize(row["raw_title"]) for row in event["evidence"]]
        if event["momentum"] != "标签观察" and any(pattern.search(title) for title in titles for pattern in priority):
            bonus = round(max(0, min(editorial["priority_bonus"], 100 - event["score"])), 1)
            event["reasons"]["editorial"] = bonus
            event["score"] = round(event["score"] + bonus, 1)
        moments.append(event)
    moments.sort(key=lambda row: (-row["score"], -row["last_seen"].timestamp(), row["title"]))
    model_used = enrich(moments[:5], editorial["prompt"])
    lines = digest_lines(moments)
    with transaction.atomic():
        previous = Event.objects.filter(last_seen__gte=now - timedelta(hours=48))
        events, claimed = _identify(moments, previous)
        Event.objects.filter(active=True).exclude(key__in=claimed).update(active=False)
        for event in events:
            event.save()
        digest, _ = Digest.objects.update_or_create(input_key=key, defaults={
            "created_at": now, "lines": lines, "model_used": model_used, "event_count": len(events),
            "coverage": coverage,
        })
        if notify:
            _queue(events, digest, now)
    return digest
