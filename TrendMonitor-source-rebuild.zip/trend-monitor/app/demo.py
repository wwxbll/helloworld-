from dataclasses import replace
from datetime import timedelta

from app.config import load_yaml
from app.sources.common import FetchResult, RawSignal


def fixture(source, now, round_number):
    config = load_yaml("demo-signals.yaml")
    if source.id not in config:
        return FetchResult(status="no_fixture", detail="该来源没有演示样本。")
    entries = config[source.id]
    if entries.get("error"):
        return FetchResult(status=entries["error"], detail=entries["detail"])
    rows = []
    for entry in entries.get(f"round_{round_number}", []):
        fields = dict(entry)
        age = fields.pop("age_minutes", 5)
        row = RawSignal(**fields)
        rows.append(replace(row, timestamp=now - timedelta(minutes=age), time_precision="source"))
    return FetchResult(rows, status="fixture", detail=f"演示样本 · 第 {round_number} 轮", snapshot_at=now)
