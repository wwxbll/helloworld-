import argparse
import os
from datetime import timedelta


def main():
    parser = argparse.ArgumentParser(description="Run collection and digest once.")
    parser.add_argument("--job", choices=["init", "collect", "digest", "all"], default="all")
    parser.add_argument("--demo", action="store_true", help="Use isolated fixtures, with no source requests.")
    parser.add_argument("--source", help="Restrict collection to a configured source ID.")
    parser.add_argument("--force", action="store_true", help="Refresh due checks for public, keyless feeds.")
    parser.add_argument("--no-notify", action="store_true")
    parser.add_argument("--sync-keywords", action="store_true", help="Apply the full config/keywords.yaml list.")
    parser.add_argument("--init", action="store_true", help="Apply migrations and seed an empty keyword table.")
    options = parser.parse_args()
    if options.demo:
        os.environ["TREND_PROFILE"] = "demo"
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "app.settings")

    import django
    django.setup()
    from django.core.management import call_command
    from django.utils import timezone

    from app.collection import collect_one
    from app.config import PROFILE, sources
    from app.digest import build_digest
    from app.locking import BusyJob, job_lock
    from app.models import Keyword, SourceRun

    entries = sources()
    targets = [entry for entry in entries if options.source is None or options.source == entry.id]
    if not targets:
        parser.error("Unknown --source")

    now = timezone.now()
    try:
        with job_lock():
            initialize = options.init or options.job == "init"
            if initialize:
                call_command("migrate", interactive=False, verbosity=0)
            if options.sync_keywords:
                call_command("keywords", "import", sync=True)
            elif initialize and not Keyword.objects.exists():
                call_command("keywords", "import")
            if options.job in {"collect", "all"}:
                for entry in targets:
                    if PROFILE == "demo" and not SourceRun.objects.filter(source=entry.id).exists():
                        collect_one(entry, now - timedelta(hours=2), demo_round=1)
                    run = collect_one(entry, now, force=options.force, demo_round=2)
                    print(f"{entry.id}  {run.status}  rows={run.row_count}  matched={run.matched_count}  {run.detail}")
            if options.job in {"digest", "all"}:
                report = build_digest(entries, now, notify=not options.no_notify)
                print(f"摘要 #{report.pk} · {report.event_count} 个事件 · {report.model_used}")
                for line in report.lines:
                    print(line)
    except BusyJob as exc:
        parser.exit(1, f"{exc}\n")


if __name__ == "__main__":
    main()
