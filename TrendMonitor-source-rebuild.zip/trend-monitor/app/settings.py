import os
import secrets
from pathlib import Path

from app.config import DATA_DIR, OPTIONS, PROFILE, ROOT

DATA_DIR.mkdir(parents=True, exist_ok=True)
secret_file = DATA_DIR / ".django-secret"
SECRET_KEY = os.getenv("TREND_DJANGO_SECRET")
if not SECRET_KEY:
    try:
        with secret_file.open("x", encoding="ascii") as file:
            file.write(secrets.token_urlsafe(48))
    except FileExistsError:
        pass
    SECRET_KEY = secret_file.read_text(encoding="ascii").strip()

DEBUG = False
ALLOWED_HOSTS = os.getenv("TREND_ALLOWED_HOSTS", "127.0.0.1,localhost,[::1]").split(",")
CSRF_TRUSTED_ORIGINS = [s for s in os.getenv("TREND_TRUSTED_ORIGINS", "").split(",") if s]
ROOT_URLCONF = "app.urls"
WSGI_APPLICATION = "app.wsgi.application"
INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "app",
]
MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]
TEMPLATES = [{
    "BACKEND": "django.template.backends.django.DjangoTemplates",
    "APP_DIRS": True,
    "OPTIONS": {"context_processors": [
        "django.template.context_processors.request",
        "django.contrib.auth.context_processors.auth",
        "django.contrib.messages.context_processors.messages",
    ]},
}]
db_override = os.getenv("TREND_DEMO_DB_PATH" if PROFILE == "demo" else "TREND_DB_PATH")
db_path = Path(db_override or DATA_DIR / f"{PROFILE}.sqlite3").resolve()
db_path.parent.mkdir(parents=True, exist_ok=True)
DATABASES = {"default": {
    "ENGINE": "django.db.backends.sqlite3",
    "NAME": db_path,
    "OPTIONS": {"timeout": 20, "transaction_mode": "IMMEDIATE"},
}}
LANGUAGE_CODE = "zh-hans"
TIME_ZONE = os.getenv("TREND_TIME_ZONE", OPTIONS["web"]["time_zone"])
USE_TZ = True
STATIC_URL = "/static/"
STATIC_ROOT = DATA_DIR / "static"
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"
SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_REFERRER_POLICY = "same-origin"
if os.getenv("TREND_HTTPS") == "1":
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True
    SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
