import hashlib
import json
import logging
import os
from datetime import timedelta
from decimal import Decimal
from urllib.parse import urlsplit

from django.db import transaction
from django.utils.timezone import now as clock

from app.config import OPTIONS, PROFILE
from app.demo import fixture
from app.matching import Matcher
from app.models import Keyword, Signal, SourceRun
from app.sources.common import FetchContext, FetchResult, SourceError
from app.sources.registry import fetch

LOG = logging.getLogger(__name__)
DATA_STATES = {"ok", "fallback", "fixture"}
SKIP_STATES = {"disabled", "missing_key", "free_only", "unavailable", "no_fixture", "local_quota"}


def hash_value(value):
    body = json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha256(body.encode()).hexdigest()


def safe_url(url):
    try:
        parsed = urlsplit(url)
        if parsed.scheme in {"http", "https"} and parsed.hostname and not parsed.username and not parsed.password:
            return url[:1800]
    except ValueError:
        pass
    return ""


def source_gate(source):
    if source.paid:
        return "disabled", source.options.get("reason", "付费路径已关闭。")
    if not source.active:
        return ("unavailable" if source.adapter == "unavailable" else "disabled",
                source.options.get("reason", "配置已禁用。"))
    if PROFILE != "demo" and source.credential_env and not os.getenv(source.credential_env):
        return "missing_key", f"等待免费凭据 {source.credential_env}。"
    if PROFILE != "demo" and source.adapter == "apify" and os.getenv("APIFY_FREE_PLAN_CONFIRMED") != "1":
        return "free_only", "确认账户为 Apify Free 后启用，当前未发起 Actor。"
    if PROFILE != "demo" and source.adapter == "trends_mcp" and os.getenv("TRENDS_MCP_FREE_CONFIRMED") != "1":
        return "free_only", "确认账户未购买额度再启用。"
    return None


def _monthly_budget(source, now):
    month = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    attempts = SourceRun.objects.filter(started_at__gte=month).exclude(status__in=SKIP_STATES)
    if source.adapter == "trends_mcp":
        if attempts.filter(source=source.id).count() >= source.options["monthly_cap"]:
            raise SourceError("local_quota", "已到本地每月免费请求上限。")
    if source.adapter == "apify":
        # Reserve the configured maximum, even for a timeout whose result was lost.
        from app.config import sources
        costs = {entry.id: Decimal(str(entry.options["max_charge_usd"]))
                 for entry in sources() if entry.adapter == "apify"}
        total = sum(attempts.filter(source=key).count() * cost for key, cost in costs.items())
        if total + costs[source.id] > Decimal("4.80"):
            raise SourceError("local_quota", "已到本地 Apify 共享额度保护线。")


def collect_one(source, now, *, force=False, demo_round=2):
    gate = source_gate(source)
    all_runs = SourceRun.objects.filter(source=source.id).order_by("-started_at", "-pk")
    latest = all_runs.first()
    if gate and latest and latest.status == gate[0] and latest.detail == gate[1]:
        return latest
    if not gate and PROFILE == "demo" and not force and latest and latest.detail == f"演示样本 · 第 {demo_round} 轮":
        return latest
    if not gate and latest and PROFILE != "demo":
        if latest.retry_at and now < latest.retry_at:
            return latest
        if latest.status not in SKIP_STATES and now - latest.started_at < timedelta(minutes=source.interval_minutes):
            # A manual refresh may recheck public feeds, but never exceed a credentialed source's cadence.
            if not force or source.credential_env:
                return latest
    if gate:
        return SourceRun.objects.create(source=source.id, started_at=now, finished_at=now,
                                        status=gate[0], detail=gate[1])

    recent = all_runs.filter(status__in=DATA_STATES | {"unchanged"}).first()
    keywords = list(Keyword.objects.filter(enabled=True))
    matcher = Matcher(keywords)
    context = FetchContext(
        now=now, timeout=OPTIONS["collection"]["timeout_seconds"],
        limit=OPTIONS["collection"]["max_rows"],
        seeds=[seed for keyword in keywords for seed in keyword.seeds],
        token=os.getenv(source.credential_env, "") if source.credential_env else "",
        etag=recent.etag if recent and not force else "",
        modified=recent.modified if recent and not force else "",
    )
    runs = SourceRun.objects
    if PROFILE != "demo":
        try:
            _monthly_budget(source, now)
        except SourceError as exc:
            return runs.create(source=source.id, started_at=now, finished_at=clock(),
                               status=exc.status, detail=exc.detail,
                               retry_at=now + timedelta(days=1))
    # Commit the attempt before calling an upstream so a killed process still reserves its quota.
    run = runs.create(source=source.id, started_at=now, finished_at=now, status="started")
    retry_at = None
    try:
        result = fixture(source, now, demo_round) if PROFILE == "demo" else fetch(source, context)
    except SourceError as exc:
        result = FetchResult(status=exc.status, detail=exc.detail)
        if exc.status == "rate_limited":
            retry_at = now + timedelta(seconds=exc.retry_seconds or source.interval_minutes * 60)
    except (TypeError, ValueError, KeyError) as exc:
        LOG.warning("Invalid adapter configuration or data for %s (%s)", source.id, type(exc).__name__)
        result = FetchResult(status="bad_payload", detail="适配器配置或响应字段有误。")
    if (PROFILE != "demo" and result.status in DATA_STATES and result.snapshot_at
            and recent and recent.snapshot_at and result.snapshot_at <= recent.snapshot_at):
        result = FetchResult(status="unchanged", detail="上游仍为同一期榜单。",
                             snapshot_at=recent.snapshot_at, etag=result.etag, modified=result.modified)

    rows = []
    seen = set()
    for raw in result.rows:
        title = raw.title.strip()[:500]
        url = safe_url(raw.url)
        key = (raw.external_id or title, url, raw.region, raw.kind)
        if not title or key in seen:
            continue
        seen.add(key)
        rows.append(Signal(
            run=run, source=source.id, platform=source.platform, external_id=raw.external_id[:300],
            raw_title=title, signal_text=(raw.text or title)[:2200], url=url,
            url_kind=raw.url_kind if url else "none", timestamp=raw.timestamp,
            time_precision=raw.time_precision, observed_at=now, heat=raw.heat, heat_label=raw.heat_label[:60],
            rank=raw.rank, growth=raw.growth[:40], region=raw.region[:20], kind=raw.kind[:32],
            source_domain=raw.source_domain[:200], context_only=raw.context_only,
            matched_keywords=matcher.match(title, raw.text, kind=raw.kind),
        ))
    snapshot_key = ""
    if result.status in DATA_STATES:
        snapshot_key = hash_value([(e.raw_title, e.url, e.heat, e.rank, e.growth, e.kind) for e in rows])
    with transaction.atomic():
        if rows:
            Signal.objects.bulk_create(rows)
        run.finished_at = clock()
        run.status = result.status
        run.detail = result.detail[:240]
        run.row_count = len(rows)
        run.matched_count = sum(bool(row.matched_keywords) for row in rows)
        run.snapshot_at = result.snapshot_at or (recent.snapshot_at if recent and result.status == "unchanged" else None)
        run.snapshot_key = snapshot_key or (recent.snapshot_key if recent and result.status == "unchanged" else "")
        run.retry_at = retry_at
        run.etag = (result.etag or (context.etag if result.status == "unchanged" else ""))[:240]
        run.modified = (result.modified or (context.modified if result.status == "unchanged" else ""))[:140]
        run.save()
    return run
