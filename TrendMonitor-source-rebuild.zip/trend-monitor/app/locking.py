import os
from contextlib import contextmanager
from pathlib import Path

from django.conf import settings


class BusyJob(RuntimeError):
    pass


@contextmanager
def job_lock():
    database = Path(settings.DATABASES["default"]["NAME"])
    with database.with_suffix(database.suffix + ".lock").open("a+b") as handle:
        handle.seek(0, os.SEEK_END)
        if not handle.tell():
            handle.write(b"\0")
            handle.flush()
        handle.seek(0)
        if os.name == "nt":
            import msvcrt
            lock = lambda: msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            unlock = lambda: msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            lock = lambda: fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            unlock = lambda: fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        try:
            lock()
        except OSError:
            raise BusyJob("已有采集或摘要作业在运行。") from None
        try:
            yield
        finally:
            handle.seek(0)
            unlock()
