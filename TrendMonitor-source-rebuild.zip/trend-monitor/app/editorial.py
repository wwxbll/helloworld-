import re

import yaml

from app.config import ROOT, load_yaml
from app.matching import normalize


ANGLE_RULES = (
    (r"\b(?:exploits?|vulnerabilit(?:y|ies)|breach|cyberattack)\b|漏洞|网络攻击|泄露",
     "影响范围与应对", "对照官方通告核实受影响范围、时间线和可用的防护措施。"),
    (r"\b(?:financing|funding|raises?|valuation|ipo|s-1|equity)\b|融资|上市|估值|股权|募资",
     "资本动作与业务信号", "查公告或披露文件，核实金额口径、资金用途和下一件可以跟踪的事。"),
    (r"\b(?:benchmark|throughput|performance|fp64|speedup|top[s]?)\b|跑分|吞吐|性能",
     "数据能不能横向比较", "找原始测试，对照任务、硬件、参数精度和基线，再列出适用场景。"),
    (r"\b(?:shipments?|delivery|shipping|capacity|foundry|fabs?)\b|交付|出货|扩产|封装|晶圆",
     "供应与落地时间", "核对交付或投产时间、供应范围与受影响环节，找一个能验证进展的下游案例。"),
    (r"\b(?:outage|incident|downtime|delays?|failure)\b|故障|中断|宕机|延迟|事故",
     "影响面与恢复进展", "整理时间线、受影响用户和恢复情况，区分当前状态和未核实的原因。"),
    (r"\b(?:fines?|regulation|lawsuit|policy|court|ban)\b|条例|监管|罚款|起诉|法院",
     "实际会影响谁", "对照原始条文或文件，梳理适用对象、生效条件以及用户会遇到的变化。"),
    (r"\b(?:launch(?:es|ed)?|releas(?:e|es|ed)|introduces?|announces?|preview|rolls out)\b|发布|推出|上线|开放",
     "谁可以先用", "核对开放对象、使用门槛和现有替代方案，设计一个能重现实用差异的对比。"),
    (r"\b(?:conjecture|proof|theorem)\b|猜想|定理|证明",
     "证明主张如何核查", "找完整证明或正式论文，梳理同行对关键步骤、适用范围和结论的公开评议。"),
    (r"\b(?:research|paper|evaluates?|study|proof|arxiv)\b|研究|论文|证明|评估",
     "结论在哪些场景成立", "查原始材料，明确样本、评估边界和一个可以独立验证的结果。"),
)


def editorial_config():
    try:
        return load_yaml("editorial.yaml")
    except FileNotFoundError:
        with (ROOT / "config" / "editorial.yaml").open(encoding="utf-8") as file:
            return yaml.safe_load(file)


def rule_editorial(title, evidence, momentum, fallback=None):
    subject = " ".join(title.split())[:64].rstrip("，,。")
    if momentum == "标签观察":
        return {
            "angles": [
                {"heading": "这个标签为什么被讨论", "approach": "抽看代表性内容，按新事件、活动和旧梗回流分类。"},
                {"heading": "值不值得单独报道", "approach": "找平台外的独立信号，确认讨论有具体对象和可核实的新变化。"},
            ],
            "title_draft": f"{subject} 为什么出现在热榜上？",
        }
    text = normalize(" ".join([title, *(row["raw_title"] for row in evidence)]))
    fallback = fallback or editorial_config()["fallback"]
    lead, approach = next(
        ((heading, plan) for pattern, heading, plan in ANGLE_RULES if re.search(pattern, text)),
        (fallback["heading"], fallback["approach"]),
    )
    independent = len({row.get("platform") for row in evidence if row.get("platform")})
    if independent >= 2:
        second = {
            "heading": "不同平台在关注什么",
            "approach": "比较搜索词、帖子或报道各自强调的细节，找出共同事实和仍待确认的分歧。",
        }
    else:
        second = {
            "heading": "哪些说法需要第二个来源",
            "approach": "把标题中的核心主张写成待核实问题，找原始文件、当事方或独立实测补证。",
        }
    return {
        "angles": [{"heading": lead, "approach": approach}, second],
        "title_draft": f"{subject}｜{lead}",
    }


def model_editorial(edit):
    draft = edit.get("title_draft")
    angles = edit.get("angles")
    if not _valid_text(draft, 8, 90) or not isinstance(angles, list):
        return None
    valid = []
    seen = set()
    for item in angles[:3]:
        if not isinstance(item, dict):
            continue
        heading, approach = item.get("heading"), item.get("approach")
        if not _valid_text(heading, 3, 22) or not _valid_text(approach, 10, 85):
            continue
        heading = " ".join(heading.split())
        if heading not in seen:
            seen.add(heading)
            valid.append({"heading": heading, "approach": " ".join(approach.split())})
    if len(valid) < 2:
        return None
    return {"angles": valid, "title_draft": " ".join(draft.split())}


def _valid_text(value, minimum, maximum):
    return (isinstance(value, str) and minimum <= len(" ".join(value.split())) <= maximum
            and "://" not in value and bool(re.search(r"[\u3400-\u9fff]", value)))
