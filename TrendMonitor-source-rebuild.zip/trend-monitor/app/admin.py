from django.contrib import admin

from app.models import Keyword

admin.site.site_header = "热点雷达 · 关注词管理"
admin.site.site_title = "热点雷达"
admin.site.index_title = "监控设置"
admin.site.site_url = "/"


@admin.register(Keyword)
class KeywordAdmin(admin.ModelAdmin):
    list_display = ("label", "key", "weight", "enabled")
    list_editable = ("weight", "enabled")
    search_fields = ("label", "key")
    list_filter = ("enabled",)
