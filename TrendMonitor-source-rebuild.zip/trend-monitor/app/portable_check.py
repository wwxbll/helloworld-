import ctypes
import http.client
import json
import os
import shutil
import socket
import struct
import subprocess
import sys
import time
from ctypes import wintypes
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from tempfile import TemporaryDirectory
from threading import Thread

import yaml

TITLE = "OpenAI 便携版兼容性自检样本"
TOAST_TITLE = "热点雷达 · 桌面通知"


class TestFeed(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/robots.txt":
            body = b"User-agent: *\nDisallow:\n"
            content_type = "text/plain"
        elif self.path == "/feed":
            body = (f'<?xml version="1.0" encoding="UTF-8"?><rss version="2.0">'
                    f'<channel><title>兼容性自检</title><item><title>{TITLE}</title>'
                    '<link>/item</link></item></channel></rss>').encode("utf-8")
            content_type = "application/rss+xml"
        else:
            self.send_error(404)
            return
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args):
        pass


def write_yaml(path, value):
    path.write_text(yaml.safe_dump(value, allow_unicode=True, sort_keys=False), encoding="utf-8")


def isolated_config(source, config, port, feed_port):
    config.mkdir()
    options = yaml.safe_load((source / "app.yaml").read_text(encoding="utf-8"))
    options["web"]["port"] = port
    options["model"]["provider"] = "rules"
    options["notification"].update(min_score=0, poll_seconds=1, display_seconds=10)
    options["boards"] = [{
        "id": "compat", "title": "兼容性自检", "scope": "本机样本", "group": "domestic",
        "sources": ["compat_test"], "kind": "headline", "limit": 3, "stale_hours": 4,
    }]
    write_yaml(config / "app.yaml", options)
    write_yaml(config / "sources.yaml", {"sources": [{
        "id": "compat_test", "name": "自检来源", "platform": "compat", "adapter": "rss",
        "enabled": True, "interval_minutes": 120,
        "options": {"url": f"http://127.0.0.1:{feed_port}/feed", "signal_type": "headline"},
    }]})
    write_yaml(config / "keywords.yaml", [{"key": "openai", "label": "OpenAI"}])
    shutil.copyfile(source / "editorial.yaml", config / "editorial.yaml")


def read_http(port, path):
    connection = http.client.HTTPConnection("127.0.0.1", port, timeout=2)
    try:
        connection.request("GET", path)
        response = connection.getresponse()
        return response.status, response.read()
    finally:
        connection.close()


def toast_visible(pid):
    user32 = ctypes.windll.user32
    user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    user32.IsWindowVisible.argtypes = [wintypes.HWND]
    user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    visible = False

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def check(hwnd, _):
        nonlocal visible
        owner = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(owner))
        if owner.value == pid and user32.IsWindowVisible(hwnd):
            title = ctypes.create_unicode_buffer(128)
            user32.GetWindowTextW(hwnd, title, len(title))
            visible = title.value == TOAST_TITLE
        return not visible

    user32.EnumWindows(check, 0)
    return visible


def check_instance(root, stage, feed, blocked_port, lines):
    config, data = stage / "config", stage / "data"
    isolated_config(Path(os.environ["TREND_CONFIG_DIR"]), config, blocked_port, feed.server_port)
    env = {key: value for key, value in os.environ.items() if not key.upper().startswith("TREND_")}
    env.update(TREND_CONFIG_DIR=str(config), TREND_DATA_DIR=str(data))
    command = [sys.executable]
    if not getattr(sys, "frozen", False):
        command.extend(("-m", "app.portable"))
    proc = subprocess.Popen([*command, "--no-browser"], env=env, cwd=root,
                            creationflags=subprocess.CREATE_NO_WINDOW)
    try:
        marker = data / "dashboard.port"
        deadline = time.monotonic() + 30
        while not marker.is_file() and proc.poll() is None and time.monotonic() < deadline:
            time.sleep(0.2)
        if not marker.is_file() or not (data / "live.sqlite3").is_file():
            raise RuntimeError("启动看板或初始化测试库失败。")
        port = int(marker.read_text(encoding="ascii"))
        if port == blocked_port:
            raise RuntimeError("端口回退失败。")
        lines.append("通过 · 首次建库和端口回退")
        if any(read_http(port, path)[0] != 200 for path in ("/", "/static/app/dashboard.css")):
            raise RuntimeError("看板或样式加载失败。")
        lines.append("通过 · 看板和样式")
        deadline = time.monotonic() + 20
        collected = shown = False
        while time.monotonic() < deadline:
            status, body = read_http(port, "/api/notifications/")
            collected = status == 200 and bool(json.loads(body)["items"])
            if collected and toast_visible(proc.pid):
                shown = True
                break
            time.sleep(0.25)
        if not collected or TITLE.encode() not in read_http(port, "/")[1]:
            raise RuntimeError("本机样本采集或选题生成失败。")
        lines.append("通过 · 本机样本采集和选题生成")
        if not shown:
            raise RuntimeError("找不到可见通知窗口，请在已登录的 Windows 桌面运行。")
        lines.append("通过 · 桌面弹窗")
    except Exception:
        log = data / "运行日志.txt"
        if log.is_file():
            detail = log.read_text(encoding="utf-8", errors="replace")[-2600:]
            lines += ["", "运行日志节选", detail.replace(str(stage), "<测试目录>").replace(str(root), "<应用目录>")]
        raise
    finally:
        if proc.poll() is None:
            taskkill = Path(os.environ["SystemRoot"]) / "System32" / "taskkill.exe"
            subprocess.run([str(taskkill), "/PID", str(proc.pid), "/T", "/F"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                           creationflags=subprocess.CREATE_NO_WINDOW)
            proc.wait(timeout=7)


def run_check(root):
    version = sys.getwindowsversion()
    lines = ["热点雷达 · Windows 兼容性检查", datetime.now().astimezone().isoformat(timespec="seconds"),
             f"系统构建号 {version.major}.{version.minor}.{version.build}",
             f"内置 Python {sys.version.split()[0]} · {8 * struct.calcsize('P')} 位",
             "本次使用本机模拟订阅。", ""]
    exit_code = 0
    try:
        with (TemporaryDirectory(prefix="TrendMonitor-check-") as directory, socket.socket() as busy,
              ThreadingHTTPServer(("127.0.0.1", 0), TestFeed) as feed):
            busy.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            busy.bind(("127.0.0.1", 0))
            busy.listen()
            listener = Thread(target=feed.serve_forever, daemon=True)
            listener.start()
            try:
                check_instance(root, Path(directory), feed, busy.getsockname()[1], lines)
            finally:
                feed.shutdown()
                listener.join()
    except Exception as exc:
        lines.append(f"失败 · {exc}")
        exit_code = 1
    report = root / "compatibility-check.txt"
    report.write_text("\n".join(lines) + "\n", encoding="utf-8-sig")
    return exit_code
