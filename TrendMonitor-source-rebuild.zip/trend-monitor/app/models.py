from django.core.exceptions import ValidationError
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models


class Keyword(models.Model):
    key = models.SlugField("标识", max_length=60, unique=True)
    label = models.CharField("显示名称", max_length=80)
    aliases = models.JSONField("别名（JSON 数组）", default=list, blank=True)
    seeds = models.JSONField("Google 查询词（JSON 数组）", default=list, blank=True)
    weight = models.FloatField("权重", default=1, validators=[
        MinValueValidator(0.1), MaxValueValidator(2),
    ])
    enabled = models.BooleanField("启用", default=True)

    class Meta:
        verbose_name = verbose_name_plural = "关注词"
        ordering = ["pk"]

    def __str__(self):
        return self.label

    def clean(self):
        for field in ("aliases", "seeds"):
            values = getattr(self, field)
            if not isinstance(values, list) or any(
                not isinstance(value, str) or not value.strip() or len(value) > 80
                for value in values
            ):
                raise ValidationError({field: "请填写由非空字符串组成的 JSON 数组。"})


class SourceRun(models.Model):
    source = models.CharField(max_length=64)
    started_at = models.DateTimeField()
    finished_at = models.DateTimeField()
    status = models.CharField(max_length=32)
    detail = models.CharField(max_length=240, blank=True)
    row_count = models.PositiveIntegerField(default=0)
    matched_count = models.PositiveIntegerField(default=0)
    snapshot_at = models.DateTimeField(null=True)
    snapshot_key = models.CharField(max_length=64, blank=True)
    retry_at = models.DateTimeField(null=True)
    etag = models.CharField(max_length=240, blank=True)
    modified = models.CharField(max_length=140, blank=True)

    class Meta:
        indexes = [models.Index(fields=["source", "-started_at"])]


class Signal(models.Model):
    run = models.ForeignKey(SourceRun, on_delete=models.CASCADE, related_name="signals")
    source = models.CharField(max_length=64)
    platform = models.CharField(max_length=40)
    external_id = models.CharField(max_length=300, blank=True)
    raw_title = models.CharField(max_length=500)
    signal_text = models.TextField(blank=True)
    url = models.URLField(max_length=1800, blank=True)
    url_kind = models.CharField(max_length=16, default="none")
    timestamp = models.DateTimeField(null=True)
    time_precision = models.CharField(max_length=16, default="observed")
    observed_at = models.DateTimeField(db_index=True)
    heat = models.FloatField(null=True)
    heat_label = models.CharField(max_length=60, blank=True)
    rank = models.PositiveIntegerField(null=True)
    growth = models.CharField(max_length=40, blank=True)
    region = models.CharField(max_length=20, blank=True)
    kind = models.CharField(max_length=32)
    matched_keywords = models.JSONField(default=list)
    source_domain = models.CharField(max_length=200, blank=True)
    context_only = models.BooleanField(default=False)


class Digest(models.Model):
    created_at = models.DateTimeField()
    input_key = models.CharField(max_length=64, unique=True)
    lines = models.JSONField(default=list)
    model_used = models.CharField(max_length=80)
    event_count = models.PositiveIntegerField(default=0)
    coverage = models.JSONField(default=dict)


class Event(models.Model):
    key = models.CharField(max_length=40, unique=True)
    first_seen = models.DateTimeField()
    last_seen = models.DateTimeField()
    active = models.BooleanField(default=True, db_index=True)
    title = models.CharField(max_length=500)
    category = models.CharField(max_length=80, blank=True)
    momentum = models.CharField(max_length=40)
    score = models.FloatField()
    reasons = models.JSONField(default=dict)
    keywords = models.JSONField(default=list)
    platforms = models.JSONField(default=list)
    regions = models.JSONField(default=list)
    signatures = models.JSONField(default=list)
    evidence = models.JSONField(default=list)
    summary = models.CharField(max_length=450, blank=True)
    editorial = models.JSONField(default=dict, blank=True)

    class Meta:
        ordering = ["-score", "-last_seen", "pk"]


class BoardSnapshot(models.Model):
    board = models.SlugField(max_length=24)
    observed_at = models.DateTimeField()
    source = models.CharField(max_length=80)
    scope = models.CharField(max_length=160, blank=True)
    rows = models.JSONField(default=list)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["board", "observed_at"], name="unique_board_snapshot")]


class Notification(models.Model):
    event = models.ForeignKey(Event, on_delete=models.CASCADE)
    digest = models.ForeignKey(Digest, on_delete=models.CASCADE)
    created_at = models.DateTimeField()
    signature = models.CharField(max_length=64)
    title = models.CharField(max_length=160)
    body = models.CharField(max_length=260)

    class Meta:
        indexes = [models.Index(fields=["event", "-created_at"])]
