import argparse
import errno
import os
import subprocess
import sys
import time
import traceback
from pathlib import Path


def use_local_paths():
    root = (Path(sys.executable).resolve().parent if getattr(sys, "frozen", False)
            else Path(__file__).resolve().parents[1])
    os.environ.setdefault("TREND_CONFIG_DIR", str(root / "config"))
    os.environ.setdefault("TREND_DATA_DIR", str(root / "data"))
    os.environ["TREND_PROFILE"] = "live"
    return root


def serve_worker(port, ready):
    from app.serve import create_dashboard

    host = "127.0.0.1"
    try:
        server = create_dashboard(host, port)
    except OSError as exc:
        address_error = {exc.errno, getattr(exc, "winerror", None)}
        if not port or not address_error.intersection({errno.EADDRINUSE, errno.EACCES, 10048, 10013}):
            raise
        server = create_dashboard(host, 0)
        print(f"端口 {port} 无法使用，改用 {server.effective_port}。", flush=True)
    print(f"看板地址 http://{host}:{server.effective_port}/", flush=True)
    pending = ready.with_suffix(".tmp")
    pending.write_text(str(server.effective_port), encoding="ascii")
    pending.replace(ready)
    server.run()


class Launcher:
    def __init__(self, application, root, data, config, options, no_browser):
        from PySide6.QtCore import QTimer

        self.application = application
        self.root = root
        self.config = config
        self.no_browser = no_browser
        self.port = int(os.environ.get("TREND_PORT", options["web"]["port"]))
        if not 0 <= self.port <= 65535:
            raise ValueError("web.port 必须在 0 至 65535 之间。")
        self.ready = data / "dashboard.port"
        self.log = data / "运行日志.txt"
        self.server = self.setup = self.job = self.client = None
        self.deadline = time.monotonic() + 60
        self.ready.unlink(missing_ok=True)
        self.timer = QTimer()
        self.timer.timeout.connect(self.check_startup)
        self.refresh = QTimer()
        self.refresh.setSingleShot(True)
        self.refresh.setInterval(60_000 * max(60, int(options.get("portable", {}).get("refresh_minutes", 120))))
        self.refresh.timeout.connect(self.collect)
        self.setup = self.start_worker("job", "--job", "init")
        self.timer.start(250)

    def start_worker(self, kind, *arguments):
        command = [sys.executable]
        if not getattr(sys, "frozen", False):
            command.extend(("-m", "app.portable"))
        command.extend(("--worker", kind, *arguments))
        with self.log.open("a", encoding="utf-8") as log:
            print(f"\n{time.strftime('%Y-%m-%d %H:%M:%S')} · {kind}", file=log, flush=True)
            return subprocess.Popen(command, cwd=self.root, stdout=log, stderr=subprocess.STDOUT,
                                    stdin=subprocess.DEVNULL, creationflags=subprocess.CREATE_NO_WINDOW)

    def show_error(self, message):
        from PySide6.QtWidgets import QMessageBox

        self.timer.stop()
        QMessageBox.critical(None, "热点雷达", f"{message}\n\n运行日志\n{self.log}")
        self.application.exit(1)

    def check_startup(self):
        try:
            if self.setup and self.setup.poll() is not None:
                if self.setup.returncode:
                    self.show_error("无法初始化数据。")
                    return
                self.setup = None
                self.server = self.start_worker("web", str(self.port), str(self.ready))
            if self.server and self.server.poll() is not None:
                self.show_error("本地看板服务已停止。")
                return
            if not self.client and self.ready.is_file():
                self.attach_tray(int(self.ready.read_text(encoding="ascii")))
            if not self.client and time.monotonic() > self.deadline:
                self.show_error("启动超时。")
            if self.job and self.job.poll() is not None:
                status = "上一次更新已完成" if self.job.returncode == 0 else "更新失败，请查看运行日志"
                self.client.tray.setToolTip(f"热点雷达 · {status}")
                self.job = None
                self.refresh.start()
        except (OSError, ValueError) as exc:
            self.show_error(f"启动失败（{type(exc).__name__}）。")

    def attach_tray(self, port):
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QAction, QDesktopServices

        from app.desktop import DesktopClient

        address = f"http://127.0.0.1:{port}"
        self.client = DesktopClient(self.application, address, "live", "qt")
        menu = self.client.menu
        exit_action = menu.actions()[-1]
        for text, action in (
            ("检查更新", self.collect),
            ("应用关注词文件", lambda: self.collect(sync=True)),
            ("打开配置文件夹", lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.config)))),
            ("查看运行日志", lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.log)))),
        ):
            item = QAction(text, menu)
            item.triggered.connect(action)
            menu.insertAction(exit_action, item)
        self.timer.setInterval(1000)
        if not self.no_browser:
            QDesktopServices.openUrl(QUrl(address + "/"))
        self.collect()

    def collect(self, *, sync=False):
        if self.job and self.job.poll() is None:
            self.client.tray.showMessage("热点雷达", "已有更新正在运行，请稍后再试。")
            return
        arguments = ["--job", "digest", "--sync-keywords", "--no-notify"] if sync else ["--job", "all"]
        self.refresh.stop()
        try:
            self.job = self.start_worker("job", *arguments)
            self.client.tray.setToolTip("热点雷达 · 正在更新")
        except OSError:
            self.client.tray.showMessage("热点雷达", "无法启动更新。")
            self.refresh.start()

    def close(self):
        self.timer.stop()
        self.refresh.stop()
        if self.client:
            self.client.tray.hide()
        for worker in (self.setup, self.job, self.server):
            if worker and worker.poll() is None:
                worker.terminate()
                try:
                    worker.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    worker.kill()
                    worker.wait()
        self.ready.unlink(missing_ok=True)


def launch(root, no_browser):
    from PySide6.QtCore import QLockFile, QUrl
    from PySide6.QtGui import QDesktopServices
    from PySide6.QtWidgets import QApplication, QMessageBox

    app = QApplication([sys.argv[0]])
    app.setApplicationName("热点雷达")
    app.setQuitOnLastWindowClosed(False)
    try:
        from app.config import CONFIG_DIR, DATA_DIR, OPTIONS

        DATA_DIR.mkdir(parents=True, exist_ok=True)
        lock = QLockFile(str(DATA_DIR / "portable.lock"))
        lock.setStaleLockTime(0)
        if not lock.tryLock(0):
            if lock.error() != QLockFile.LockError.LockFailedError:
                raise OSError("无法写入便携版运行锁。")
            ready = DATA_DIR / "dashboard.port"
            if ready.is_file() and not no_browser:
                port = int(ready.read_text(encoding="ascii"))
                QDesktopServices.openUrl(QUrl(f"http://127.0.0.1:{port}/"))
            elif not no_browser:
                QMessageBox.information(None, "热点雷达", "热点雷达正在启动，请稍候。")
            return 0
        try:
            launcher = Launcher(app, root, DATA_DIR, CONFIG_DIR, OPTIONS, no_browser)
            try:
                return app.exec()
            finally:
                launcher.close()
        finally:
            lock.unlock()
    except Exception:
        try:
            with (Path(os.environ["TREND_DATA_DIR"]) / "运行日志.txt").open("a", encoding="utf-8") as log:
                traceback.print_exc(file=log)
        except OSError:
            pass
        QMessageBox.critical(None, "热点雷达", "无法启动。请检查文件夹写入权限与配置，详情见 data 中的运行日志。")
        return 1


def main():
    root = use_local_paths()
    if sys.argv[1:2] == ["--worker"]:
        kind, *arguments = sys.argv[2:]
        if sys.stdout is None or sys.stderr is None:
            file = Path(os.environ["TREND_DATA_DIR"]) / "运行日志.txt"
            sys.stdout = sys.stderr = file.open("a", encoding="utf-8", buffering=1)
        if kind == "web":
            port, ready = arguments
            serve_worker(int(port), Path(ready))
        elif kind == "job":
            from app.run_once import main as run_job

            sys.argv[1:] = arguments
            run_job()
        else:
            raise SystemExit("Unknown worker.")
        return 0
    parser = argparse.ArgumentParser(description="热点雷达便携版")
    parser.add_argument("--no-browser", action="store_true", help="启动时保留托盘，不自动打开看板。")
    parser.add_argument("--compat-check", action="store_true", help="在临时目录检查 Windows 运行情况。")
    arguments = parser.parse_args()
    if arguments.compat_check:
        from app.portable_check import run_check

        return run_check(root)
    return launch(root, arguments.no_browser)


if __name__ == "__main__":
    sys.exit(main())
