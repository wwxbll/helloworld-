import hmac
import os
from collections import defaultdict
from datetime import timedelta

from django.core.paginator import Paginator
from django.http import HttpResponseForbidden, JsonResponse
from django.shortcuts import get_object_or_404, render
from django.utils.dateparse import parse_datetime
from django.utils.timezone import localtime, now
from django.views.decorators.http import require_safe

from app.boards import board_cards
from app.collection import source_gate
from app.config import OPTIONS, PROFILE, sources
from app.digest import coverage_for, notification_signature
from app.editorial import rule_editorial
from app.matching import Matcher
from app.models import Digest, Event, Keyword, Notification

SOURCE_STATUS = {
    "ok": "已采集", "fallback": "备用页", "unchanged": "榜单未更新", "fixture": "演示样本",
    "missing_key": "待免费密钥", "free_only": "待确认免费档", "unavailable": "暂不可用",
    "disabled": "已停用", "no_fixture": "无演示样本", "pending": "待采集",
    "network_error": "连接失败", "blocked": "访问受限", "rate_limited": "限流退避",
    "robots_blocked": "自动访问受限", "local_quota": "本地额度上限", "quota": "上游额度不足",
    "shape_changed": "结构变更", "stale": "快照过期", "bad_payload": "数据异常",
    "http_error": "HTTP 错误", "bad_config": "配置错误", "started": "采集中",
}
PLATFORM_NAMES = {
    "x": "X", "google": "Google", "aiweekly": "AI Weekly",
    "weibo": "微博", "tiktok": "TikTok", "reddit": "Reddit",
    "baidu": "百度", "douyin": "抖音", "bilibili": "B 站", "xiaohongshu": "小红书",
    "v2ex": "V2EX", "ithome": "IT之家", "sspai": "少数派",
    "solidot": "Solidot", "oschina": "开源中国", "hackernews": "Hacker News",
}
BOARD_GROUPS = [("", "全部"), ("domestic", "国内"), ("international", "国际")]
MOMENTS = ["新信号", "持续发酵", "首次观察", "标签观察"]
REGION_NAMES = {"CN": "中国", "US": "美国", "GB": "英国", "CA": "加拿大",
                "AU": "澳大利亚", "SG": "新加坡", "WORLD": "全球"}
SORT_FIELDS = {"score": "-score", "time": "-last_seen"}
URL_LABELS = {"article": "查看报道", "search": "查看搜索结果", "trend": "查看趋势",
              "tag": "查看标签", "discussion": "查看讨论", "none": "无原始链接"}
KIND_LABELS = {
    "rising": "Rising", "breakout": "Breakout", "trending_now": "Trending Now",
    "live_alert": "Live Alert", "live_story": "实时报道", "ranked_trend": "榜单",
    "hashtag": "标签", "headline": "资讯",
}


def shown_time(value):
    stamp = parse_datetime(value) if value else None
    return localtime(stamp).strftime("%m-%d %H:%M") if stamp and stamp.tzinfo else ""


def platform_name(name):
    return PLATFORM_NAMES.get(name, name)


def _event_view(event):
    event.platform_labels = [platform_name(item) for item in event.platforms]
    event.is_new = event.momentum == "新信号"
    if not event.editorial:
        event.editorial = rule_editorial(event.title, event.evidence, event.momentum)
    return event


def _event_topics(event, matcher):
    return {key for row in event.evidence for key in matcher.match(
        row["raw_title"], row.get("signal_text", ""), kind=row.get("kind", "")
    )}


@require_safe
def dashboard(request):
    displayed_at = now()
    config = sources()
    coverage = coverage_for(config)
    cards = defaultdict(list)
    for entry in coverage.values():
        cards[entry["platform"]].append({**entry, "label": SOURCE_STATUS.get(entry["status"], entry["status"]),
                                         "time": shown_time(entry["snapshot_at"] or entry["checked_at"]),
                                         "is_ok": entry["status"] in {"ok", "fixture", "unchanged", "fallback"}})
    panel = [{"name": platform_name(platform), "entries": entries}
             for platform, entries in cards.items()]
    recent = Digest.objects.order_by("-created_at", "-pk").first()
    selection = {field: request.GET.get(field, "")[:100]
                 for field in ("q", "topic", "source", "region", "momentum", "sort", "scope", "hours")}
    matcher = Matcher(Keyword.objects.filter(enabled=True))
    allowed_keys = {key for key, keyword in matcher.keywords.items()
                    if not selection["topic"] or selection["topic"] == keyword.label}
    group = request.GET.get("board_group", "")
    if group not in dict(BOARD_GROUPS):
        group = ""
    order = SORT_FIELDS.get(selection["sort"], "-score")
    horizon = int(selection["hours"]) if selection["hours"] in {"6", "12", "24", "72"} else 24
    query = Event.objects.order_by(order, "-last_seen", "pk")
    if selection["scope"] != "history":
        query = query.filter(active=True, last_seen__gte=displayed_at - timedelta(hours=horizon))
    if selection["momentum"] in MOMENTS:
        query = query.filter(momentum=selection["momentum"])
    enabled = {entry.id for entry in config if not source_gate(entry)}
    keep_history = selection["scope"] == "history"
    q = selection["q"].casefold()
    visible = []
    for event in query:
        if not keep_history and not any(row["source"] in enabled for row in event.evidence):
            continue
        if not allowed_keys.intersection(_event_topics(event, matcher)):
            continue
        if selection["source"] and not any(row["source"] == selection["source"] for row in event.evidence):
            continue
        if selection["region"] and selection["region"] not in event.regions:
            continue
        if q and not any(q in item.casefold() for item in [event.title, event.summary, *event.keywords,
                                                         *(row["raw_title"] for row in event.evidence)]):
            continue
        visible.append(_event_view(event))
    page = Paginator(visible, 24).get_page(request.GET.get("page"))
    topics = [keyword.label for keyword in matcher.keywords.values()]
    platform_count = sum(any(entry["is_ok"] for entry in item["entries"]) for item in panel)
    regions = sorted({str(source.options["region"]) for source in config if source.options.get("region")})
    return render(request, "app/dashboard.html", {
        "page": page, "total": len(visible), "topics": topics, "selected": selection,
        "moments": MOMENTS, "sources": config, "coverage_panel": panel, "recent": recent,
        "platform_count": platform_count, "platform_total": len(panel),
        "demo": PROFILE == "demo", "horizon": horizon,
        "regions": [(region, REGION_NAMES.get(region, region)) for region in regions],
        "boards": list(board_cards(config, coverage, SOURCE_STATUS, visible, page, displayed_at,
                                  matcher, allowed_keys, group)),
        "board_groups": BOARD_GROUPS, "board_group": group,
    })


@require_safe
def event_detail(request, key):
    event = _event_view(get_object_or_404(Event, key=key))
    evidence = [{
        **row, "kind_label": KIND_LABELS.get(row["kind"], row["kind"]),
        "url_label": URL_LABELS.get(row["url_kind"], "查看来源"),
        "readable_time": shown_time(row["timestamp"] or row["observed_at"]),
    } for row in event.evidence]
    return render(request, "app/event.html", {
        "event": event, "evidence": evidence, "demo": PROFILE == "demo",
    })


@require_safe
def notifications(request):
    secret = os.getenv("TREND_NOTIFY_TOKEN")
    local = request.META.get("REMOTE_ADDR") in {"127.0.0.1", "::1"}
    if secret:
        header = request.headers.get("Authorization", "").encode("utf-8")
        if not hmac.compare_digest(header, f"Bearer {secret}".encode()):
            return HttpResponseForbidden()
    elif not local or request.headers.get("X-Forwarded-For"):
        return HttpResponseForbidden()
    try:
        after = max(0, min(2**63-1, int(request.GET.get("after", "0"))))
    except (ValueError, OverflowError):
        return JsonResponse({"error": "invalid cursor"}, status=400)
    cutoff = now() - timedelta(hours=OPTIONS["notification"]["max_age_hours"])
    active = {source.id for source in sources() if not source_gate(source)}
    matcher = Matcher(Keyword.objects.filter(enabled=True))
    items = []
    for notice in Notification.objects.filter(pk__gt=after, created_at__gte=cutoff, event__active=True
                                               ).select_related("event").order_by("-pk")[:12]:
        if (notice.signature != notification_signature(notice.event)
                or any(row["source"] not in active for row in notice.event.evidence)
                or not _event_topics(notice.event, matcher)):
            continue
        text = notice.event.summary[:110].rstrip("。！？") + "。" if notice.event.summary else notice.body
        items.append({"id": notice.pk, "title": notice.title, "body": text,
                      "path": f"/events/{notice.event.key}/", "created_at": notice.created_at.isoformat()})
    response = JsonResponse({"items": items[:1], "profile": PROFILE})
    response.headers["Cache-Control"] = "no-store"
    return response
