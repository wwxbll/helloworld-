import argparse
import os


def create_dashboard(host, port):
    from django.contrib.staticfiles.handlers import StaticFilesHandler
    from waitress import create_server

    from app.wsgi import application

    return create_server(StaticFilesHandler(application), host=host, port=port,
                         clear_untrusted_proxy_headers=True, ident="trend-monitor")


def main():
    parser = argparse.ArgumentParser(description="Serve the Trend Monitor dashboard.")
    parser.add_argument("--demo", action="store_true")
    parser.add_argument("--host")
    parser.add_argument("--port", type=int)
    args = parser.parse_args()
    if args.demo:
        os.environ["TREND_PROFILE"] = "demo"

    from app.config import OPTIONS, PROFILE

    host = args.host or os.getenv("TREND_HOST", OPTIONS["web"]["host"])
    port = args.port or int(os.getenv("TREND_PORT", OPTIONS["web"]["port"]))
    server = create_dashboard(host, port)
    print(f"热点雷达 · {PROFILE} · http://{host}:{server.effective_port}/", flush=True)
    server.run()


if __name__ == "__main__":
    main()
