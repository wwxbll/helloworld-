import json
import os
import re
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from email.utils import parsedate_to_datetime
from ipaddress import ip_address
from ssl import SSLCertVerificationError
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, ProxyHandler, Request, build_opener, getproxies, proxy_bypass
from urllib.robotparser import RobotFileParser

from app.config import OPTIONS

USER_AGENT = "TrendMonitor/1.0"
MAX_BODY = 4 * 1024 * 1024


class SourceError(Exception):
    def __init__(self, status, detail, retry_seconds=None):
        self.status = status
        self.detail = detail
        self.retry_seconds = retry_seconds
        super().__init__(detail)


@dataclass
class RawSignal:
    title: str
    text: str = ""
    external_id: str = ""
    url: str = ""
    url_kind: str = "none"
    timestamp: datetime | None = None
    time_precision: str = "observed"
    heat: float | None = None
    heat_label: str = ""
    rank: int | None = None
    growth: str = ""
    region: str = ""
    kind: str = "headline"
    source_domain: str = ""
    context_only: bool = False


@dataclass
class FetchResult:
    rows: list[RawSignal] = field(default_factory=list)
    detail: str = ""
    status: str = "ok"
    snapshot_at: datetime | None = None
    etag: str = ""
    modified: str = ""


@dataclass
class FetchContext:
    now: datetime
    timeout: int
    limit: int
    seeds: list[str]
    token: str = field(repr=False)
    etag: str = ""
    modified: str = ""


class SafeRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        before, after = urlsplit(req.full_url), urlsplit(newurl)
        if (before.scheme, before.netloc) != (after.scheme, after.netloc):
            raise SourceError("blocked", "目标重定向到其他站点，先停用并检查入口。")
        if req.has_header("Authorization") or req.get_method() != "GET":
            raise SourceError("blocked", "鉴权请求不跟随重定向。")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def retry_seconds(value):
    if not value:
        return None
    try:
        return max(1, int(value))
    except ValueError:
        stamp, _ = read_time(value)
        return max(1, int((stamp - datetime.now(UTC)).total_seconds())) if stamp else None


def _is_loopback(hostname):
    if hostname.rstrip(".") == "localhost":
        return True
    try:
        return ip_address(hostname).is_loopback
    except ValueError:
        return False


def _request_proxy(parts):
    if _is_loopback(parts.hostname):
        return None
    value = os.getenv("TREND_PROXY", OPTIONS.get("network", {}).get("proxy", "auto"))
    if not isinstance(value, str):
        raise SourceError("bad_config", "network.proxy 必须是 auto、direct 或 HTTP 代理地址。")
    value = value.strip()
    if value.lower() == "direct":
        return None
    if value.lower() in {"", "auto"}:
        proxies = getproxies()
        value = proxies.get(parts.scheme) or proxies.get("all")
    if not value or proxy_bypass(parts.netloc):
        return None
    try:
        endpoint = urlsplit(value if "://" in value else f"http://{value}")
        if (endpoint.scheme != "http" or not endpoint.hostname or endpoint.port == 0
                or endpoint.path not in {"", "/"} or endpoint.query or endpoint.fragment
                or any(char.isspace() for char in value)):
            raise ValueError
    except ValueError:
        raise SourceError("bad_config", "请填写可用的 HTTP 或混合代理地址，例如 http://127.0.0.1:7890。") from None
    return endpoint.geturl()


def request(url, timeout, *, headers=None, payload=None, allow=()):
    parts = urlsplit(url)
    if parts.scheme not in {"https", "http"} or not parts.hostname or parts.username or parts.password:
        raise SourceError("bad_config", "请求 URL 配置无效。")
    req = Request(url, headers={"User-Agent": USER_AGENT, **(headers or {})})
    if payload is not None:
        req.data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req.add_header("Content-Type", "application/json")
    proxy = _request_proxy(parts)
    opener = build_opener(ProxyHandler({parts.scheme: proxy} if proxy else {}), SafeRedirect())
    try:
        with opener.open(req, timeout=timeout) as resp:
            data = resp.read(MAX_BODY + 1)
            if len(data) > MAX_BODY:
                raise SourceError("bad_payload", "来源响应超过大小限制。")
            return resp.status, resp.headers, data
    except HTTPError as exc:
        code = exc.code
        if code in allow:
            return code, exc.headers, b""
        if code == 407:
            raise SourceError("network_error", "代理要求身份验证（HTTP 407），请核对代理凭据。") from None
        if code == 429:
            raise SourceError("rate_limited", "HTTP 429，按服务要求退避。",
                              retry_seconds(exc.headers.get("Retry-After"))) from None
        if code in {401, 403}:
            raise SourceError("blocked", f"HTTP {code}，请核验凭据或公开访问许可。") from None
        if code == 402:
            raise SourceError("quota", "HTTP 402，额度或计费门槛。") from None
        raise SourceError("http_error", f"HTTP {code}。") from None
    except (URLError, OSError) as exc:
        reason = getattr(exc, "reason", exc)
        if isinstance(reason, SSLCertVerificationError):
            raise SourceError("network_error", "TLS 证书验证失败，请检查受信任的 CA 和系统时间。") from None
        if proxy and str(reason).startswith("Tunnel connection failed: 407"):
            raise SourceError("network_error", "代理要求身份验证（HTTP 407），请核对代理凭据。") from None
        if proxy:
            raise SourceError("network_error", f"代理连接失败（{type(reason).__name__}），请检查代理服务和端口。") from None
        raise SourceError("network_error", f"连接失败（{type(reason).__name__}）。") from None


def read_json(url, timeout, **kwargs):
    _, _, body = request(url, timeout, **kwargs)
    try:
        return json.loads(body)
    except (UnicodeError, ValueError):
        raise SourceError("bad_payload", "来源未返回有效 JSON。") from None


def request_public(url, context, *, conditional=True):
    parts = urlsplit(url)
    robots_url = f"{parts.scheme}://{parts.netloc}/robots.txt"
    status, _, robots = request(robots_url, context.timeout, allow=(404, 410))
    if status == 200:
        parser = RobotFileParser()
        parser.parse(robots.decode("utf-8", "replace").splitlines())
        if not parser.can_fetch(USER_AGENT, url):
            raise SourceError("robots_blocked", "robots.txt 禁止自动访问该路径。")
    headers = {}
    if conditional and context.etag:
        headers["If-None-Match"] = context.etag
    if conditional and context.modified:
        headers["If-Modified-Since"] = context.modified
    return request(url, context.timeout, headers=headers, allow=(304,))


def read_time(value, now=None):
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        try:
            return datetime.fromtimestamp(value, UTC), "source"
        except (OverflowError, OSError, ValueError):
            return None, "observed"
    if not value or not isinstance(value, str):
        return None, "observed"
    text = value.strip()
    try:
        stamp = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        try:
            stamp = parsedate_to_datetime(text)
        except (ValueError, TypeError):
            stamp = None
    if stamp and stamp.tzinfo:
        return stamp.astimezone(UTC), "source"
    relative = re.search(r"(?i)\b(\d+)\s*([mhd])(?:inutes?|ours?|ays?)?\s+ago\b", text)
    if relative and now:
        value, unit = relative.groups()
        field = {"m": "minutes", "h": "hours", "d": "days"}[unit]
        return now - timedelta(**{field: int(value)}), "estimated"
    return None, "observed"


def number(value):
    match = re.fullmatch(r"([+-]?\d+(?:\.\d+)?)\s*([kKmMbB万亿]?)\+?", str(value).strip().replace(",", ""))
    if not match:
        return None
    units = {"k": 1_000, "m": 1_000_000, "b": 1_000_000_000, "万": 10_000, "亿": 100_000_000}
    return float(match[1]) * units.get(match[2].lower(), 1)


def rank(value):
    result = number(value)
    return int(result) if result is not None and 1 <= result <= 100000 else None


def field_at(obj, path):
    if not path:
        return None
    for field in path.split("."):
        if not isinstance(obj, dict):
            return None
        obj = obj.get(field)
    return obj
