from app.sources.common import FetchResult, RawSignal, SourceError, number, read_json, read_time

API = "https://hacker-news.firebaseio.com/v0"


def fetch(source, context):
    limit = min(context.limit, int(source.options.get("limit", 8)))
    if not 1 <= limit <= 12:
        raise SourceError("bad_config", "Hacker News 采集条数须在 1 至 12 条之间。")
    ids = read_json(f"{API}/topstories.json", context.timeout)
    if not isinstance(ids, list) or any(type(item) is not int or item < 1 for item in ids[:limit]):
        raise SourceError("shape_changed", "Hacker News 热帖 ID 列表格式异常。")
    rows = []
    for place, item in enumerate(ids[:limit], 1):
        data = read_json(f"{API}/item/{item}.json", context.timeout)
        if not isinstance(data, dict) or not data.get("title") or data.get("deleted") or data.get("dead"):
            continue
        timestamp, precision = read_time(data.get("time"))
        rows.append(RawSignal(
            title=data["title"], external_id=str(item), url=f"https://news.ycombinator.com/item?id={item}",
            url_kind="discussion", rank=place, heat=number(data.get("score")),
            timestamp=timestamp, time_precision=precision, kind="headline",
        ))
    return FetchResult(rows, detail=f"官方 Top Stories，已读取前 {limit} 个 ID。")
