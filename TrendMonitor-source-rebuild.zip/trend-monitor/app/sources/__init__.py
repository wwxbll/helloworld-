"""Source adapters return RawSignal objects and source-level snapshot metadata."""
