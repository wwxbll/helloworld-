from importlib import import_module

from app.sources.common import SourceError
from app.sources.feeds import fetch_html, fetch_json_list, fetch_rss
from app.sources.providers import fetch_apify, fetch_trends_mcp

BUILTINS = {
    "rss": fetch_rss,
    "html": fetch_html,
    "json_list": fetch_json_list,
    "apify": fetch_apify,
    "trends_mcp": fetch_trends_mcp,
}


def fetch(source, context):
    adapter = BUILTINS.get(source.adapter)
    if adapter is None:
        module, sep, function = source.adapter.partition(":")
        if not sep or not module.startswith("app.sources.") or function != "fetch":
            raise SourceError("bad_config", "未知适配器；自定义入口格式为 app.sources.模块:fetch。")
        try:
            adapter = import_module(module).fetch
        except (ImportError, AttributeError):
            raise SourceError("bad_config", "无法载入自定义适配器。") from None
    return adapter(source, context)
