import re
from datetime import UTC, datetime, timedelta
from urllib.parse import urljoin
from zoneinfo import ZoneInfo

from bs4 import BeautifulSoup
from defusedxml import ElementTree
from defusedxml.common import DefusedXmlException
from soupsieve import SelectorSyntaxError

from app.sources.common import FetchResult, RawSignal, SourceError, number, rank, read_time, request_public

TAG_NAME = re.compile(r"^h[1-6]$")


def _tag_name(element):
    return element.tag.rsplit("}", 1)[-1]


def parse_rss(body, options, context):
    try:
        document = ElementTree.fromstring(body)
    except (DefusedXmlException, ElementTree.ParseError):
        raise SourceError("bad_payload", "RSS/XML 无法解析。") from None
    if _tag_name(document) not in {"rss", "feed", "RDF"}:
        raise SourceError("bad_payload", "来源响应不符合 RSS/Atom 结构。")
    rows = []
    for item in document.iter():
        if _tag_name(item) not in {"item", "entry"}:
            continue
        values = {_tag_name(tag): (tag.text or "").strip() for tag in item}
        title = values.get("title", "")
        if not title:
            continue
        link = values.get("link", "")
        if not link:
            link = next((tag.get("href", "") for tag in item if _tag_name(tag) == "link"
                         and tag.get("rel", "alternate") == "alternate"), "")
        stamp, precision = read_time(values.get("pubDate") or values.get("published") or values.get("updated"))
        traffic = values.get("approx_traffic", "")
        rows.append(RawSignal(
            title=title, external_id=values.get("guid") or values.get("id", ""),
            url=urljoin(options["url"], link) if link else "",
            url_kind=options.get("url_kind", "article"), timestamp=stamp, time_precision=precision,
            heat=number(traffic), heat_label=traffic, region=options.get("region", ""),
            kind=options.get("signal_type", "headline"),
        ))
        if len(rows) >= context.limit:
            break
    return rows


def fetch_rss(source, context):
    status, headers, body = request_public(source.options["url"], context)
    if status == 304:
        return FetchResult(status="unchanged", detail="HTTP 304，快照未变。")
    return FetchResult(parse_rss(body, source.options, context), etag=headers.get("ETag", ""),
                       modified=headers.get("Last-Modified", ""))


def _get(node, selector, attr=None):
    item = node.select_one(selector) if selector else None
    if not item:
        return ""
    return str(item.get(attr, "")).strip() if attr else item.get_text(" ", strip=True)


def parse_html(body, options, context):
    document = BeautifulSoup(body, "html.parser", from_encoding="utf-8")
    section = document
    if options.get("section_heading"):
        heading = next((tag for tag in document.find_all(TAG_NAME)
                        if tag.get_text(" ", strip=True) == options["section_heading"]), None)
        if heading is None:
            raise SourceError("shape_changed", "未找到声明的 HTML 区块。")
        section = heading.find_parent("section") or heading.parent

    snapshot = None
    if options.get("snapshot_selector"):
        selector = options["snapshot_selector"]
        raw = _get(document, selector, options.get("snapshot_attr"))
        if options.get("snapshot_pattern"):
            match = re.search(options["snapshot_pattern"], raw)
            if match:
                stamp = datetime.fromisoformat(match[1])
                snapshot = stamp.replace(tzinfo=ZoneInfo(options["snapshot_timezone"])).astimezone(UTC)
        else:
            snapshot, _ = read_time(raw)
        if snapshot is None:
            raise SourceError("shape_changed", "榜单页面缺少可核验的更新时间。")
        if snapshot < context.now - timedelta(hours=options.get("max_snapshot_age_hours", 8)):
            raise SourceError("stale", "公开榜单时间已超出允许的时效窗口。")
        if snapshot > context.now + timedelta(minutes=10):
            raise SourceError("bad_payload", "榜单页面时间晚于本轮采集时间。")

    rows = []
    for item in section.select(options["item_selector"], limit=context.limit):
        title = _get(item, options["title_selector"])
        if not title:
            continue
        position = rank(_get(item, options.get("rank_selector")))
        if position is None and options.get("require_rank"):
            continue
        link = _get(item, options.get("url_selector"), "href")
        time_selector = options.get("timestamp_selector")
        time = _get(item, time_selector, "datetime") or _get(item, time_selector)
        stamp, precision = read_time(time, context.now)
        if stamp is None and snapshot:
            stamp, precision = snapshot, "snapshot"
        heat = _get(item, options.get("heat_selector"))
        rows.append(RawSignal(
            title=title, url=urljoin(options["url"], link) if link else "",
            url_kind=options.get("url_kind", "article"), timestamp=stamp,
            time_precision=precision, heat=number(heat), heat_label=heat,
            rank=position,
            kind=options.get("signal_type", "headline"),
            region=options.get("region", ""),
            source_domain=time.partition(" · ")[0] if " · " in time else "",
        ))
    if not rows:
        raise SourceError("shape_changed", "页面可访问但选择器没有读到任何条目。")
    return rows, snapshot


def _fetch_html(options, context, conditional):
    code, headers, body = request_public(options["url"], context, conditional=conditional)
    if code == 304:
        return FetchResult(status="unchanged", detail="HTTP 304，快照未变。")
    try:
        rows, snapshot = parse_html(body, options, context)
    except SelectorSyntaxError:
        raise SourceError("bad_config", "HTML 选择器格式无效。") from None
    return FetchResult(rows, snapshot_at=snapshot, etag=headers.get("ETag", ""),
                       modified=headers.get("Last-Modified", ""))


def fetch_html(source, context):
    try:
        return _fetch_html(source.options, context, conditional=True)
    except SourceError as exc:
        fallback = source.options.get("fallback")
        if not fallback or exc.status not in {"shape_changed", "http_error"}:
            raise
        result = _fetch_html(fallback, context, conditional=False)
        result.status = "fallback"
        result.detail = "首页快讯区不可读，使用 AI Weekly 实时报道页。"
        result.etag = result.modified = ""
        return result


def fetch_json_list(source, context):
    options = source.options
    code, headers, body = request_public(options["url"], context)
    if code == 304:
        return FetchResult(status="unchanged", detail="HTTP 304，快照未变。")
    import json
    from app.sources.providers import map_rows
    try:
        payload = json.loads(body)
    except (UnicodeError, ValueError):
        raise SourceError("bad_payload", "来源未返回有效 JSON。") from None
    return FetchResult(map_rows(payload, options, context), etag=headers.get("ETag", ""),
                       modified=headers.get("Last-Modified", ""))
