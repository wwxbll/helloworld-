import os
import re
from urllib.parse import quote, urlencode

from app.sources.common import FetchResult, RawSignal, SourceError, field_at, number, rank, read_json, read_time

APIFY_ACTORS = {"omkar-cloud~twitter-trends-scraper", "lergassy~google-trends-scraper"}


def map_rows(payload, options, context):
    rows = field_at(payload, options.get("rows")) if options.get("rows") else payload
    if not isinstance(rows, list):
        raise SourceError("shape_changed", "未找到配置指定的结果数组。")

    results = []
    fields = options["fields"]
    for parent in rows:
        nested = field_at(parent, options.get("nested")) if options.get("nested") else [parent]
        if nested is None:
            continue
        if not isinstance(nested, list):
            raise SourceError("shape_changed", "来源的嵌套结果结构已变更。")
        for row in nested:
            value = field_at(row, fields["title"])
            if not isinstance(value, str) or not value.strip():
                continue
            stamp, precision = read_time(field_at(row, fields.get("timestamp")), context.now)
            raw_heat = field_at(row, fields.get("heat"))
            raw_growth = field_at(row, fields.get("growth")) or field_at(row, fields.get("growth_number"))
            growth = str(raw_growth) if raw_growth is not None else ""
            numeric_growth = number(field_at(row, fields.get("growth_number"))) or number(growth.rstrip("%"))
            url = field_at(row, fields.get("url")) or field_at(parent, options.get("parent_url")) or ""
            kind = options.get("signal_type", "headline")
            if growth.lower() == "breakout" or (kind == "rising" and (numeric_growth or 0) > 5000):
                kind = "breakout"
            text = str(field_at(row, fields.get("text")) or "")
            seeds = field_at(parent, options.get("parent_seeds"))
            if isinstance(seeds, list):
                text = f"{value} · Google 查询种子 {' / '.join(str(seed) for seed in seeds)}"
            results.append(RawSignal(
                title=value, text=text,
                external_id=str(field_at(row, fields.get("id")) or ""), url=str(url),
                url_kind=options.get("url_kind", "article"), timestamp=stamp,
                time_precision=precision, heat=number(raw_heat),
                heat_label=str(raw_heat) if raw_heat is not None else "",
                rank=rank(field_at(row, fields.get("rank"))), growth=growth,
                region=options.get("region", ""), kind=kind,
                context_only=options.get("context_only", False),
            ))
            if len(results) >= context.limit:
                return results
    if rows and not results and not options.get("nested"):
        raise SourceError("shape_changed", "来源有结果，但没有可读的标题字段。")
    return results


def fetch_apify(source, context):
    if os.getenv("APIFY_FREE_PLAN_CONFIRMED") != "1":
        raise SourceError("free_only", "仅启用已确认的 Apify Free 账户；当前未发起 Actor。")
    options = source.options
    actor = options["actor"]
    hard_limit = float(options["max_charge_usd"])
    if actor not in APIFY_ACTORS or not 0 < hard_limit <= 0.02:
        raise SourceError("bad_config", "Actor 或单轮消费上限不在免费档配置范围内。")
    data = dict(options.get("input", {}))
    if options.get("seed_field"):
        seeds = list(dict.fromkeys(context.seeds))
        if not seeds:
            return FetchResult(detail="当前关注词没有启用查询种子。")
        data[options["seed_field"]] = seeds
        per_run_max = options.get("max_seeds", 6)
        if len(seeds) > per_run_max:
            batch = (int(context.now.timestamp()) // (source.interval_minutes * 60)) % len(seeds)
            data[options["seed_field"]] = (seeds[batch:] + seeds[:batch])[:per_run_max]
    query = urlencode({"timeout": 60, "maxTotalChargeUsd": hard_limit, "memory": 512})
    url = f"https://api.apify.com/v2/acts/{quote(actor, safe='~')}/run-sync-get-dataset-items?{query}"
    rows = read_json(url, max(context.timeout, 75), payload=data,
                     headers={"Authorization": f"Bearer {context.token}"})
    signals = map_rows(rows, options, context)
    snapshot = max((signal.timestamp for signal in signals if signal.timestamp), default=None)
    return FetchResult(signals, snapshot_at=snapshot if options.get("signal_type") == "ranked_trend" else None)


def fetch_trends_mcp(source, context):
    if os.getenv("TRENDS_MCP_FREE_CONFIRMED") != "1":
        raise SourceError("free_only", "仅启用未购买额度的免费账户。")
    options = source.options
    if not 1 <= options["limit"] <= 10:
        raise SourceError("bad_config", "免费验证每次限单榜前 10 条。")
    query = {"mode": "get_top_trends", "type": options["board"],
             "country": options["region"], "limit": options["limit"]}
    if options.get("category"):
        query["category"] = options["category"]
    data = read_json("https://api.trendsmcp.ai/api", context.timeout, payload=query,
                     headers={"Authorization": f"Bearer {context.token}"})
    if not isinstance(data, dict):
        raise SourceError("shape_changed", "Trends MCP 的响应格式已改变。")
    if data.get("error") == "monthly_limit_reached":
        raise SourceError("quota", "Trends MCP 账户的免费额度用尽。")
    if data.get("error"):
        raise SourceError("bad_payload", "Trends MCP 返回错误，请检查地区和分类名。")
    raw = data if isinstance(data.get("data"), list) else data.get("result", {})
    if not isinstance(raw, dict) or not isinstance(raw.get("data"), list):
        raise SourceError("shape_changed", "Trends MCP 未返回文档中的榜单字段。")
    stamp, _ = read_time(raw.get("as_of_ts"))
    values = []
    for row in raw["data"][:min(context.limit, options["limit"])]:
        if isinstance(row, list) and len(row) >= 2:
            row = {"rank": row[0], "keyword": row[1]}
        if not isinstance(row, dict) or not isinstance(row.get("keyword"), str):
            continue
        keyword = row["keyword"].strip()
        if keyword:
            tag = re.sub(r"[^A-Za-z0-9_\u0080-\uffff]", "", keyword.lstrip("#"))
            values.append(RawSignal(
                keyword, url=f"https://www.tiktok.com/tag/{quote(tag)}" if tag else "",
                url_kind="tag", kind="hashtag", rank=rank(row.get("rank")),
                timestamp=stamp, time_precision="snapshot" if stamp else "observed",
                region=options["region"], context_only=True,
            ))
    if raw["data"] and not values:
        raise SourceError("shape_changed", "榜单未返回可解析的标签。")
    return FetchResult(values, detail="免费榜单可延迟 24 小时，仅供观察。", snapshot_at=stamp)
