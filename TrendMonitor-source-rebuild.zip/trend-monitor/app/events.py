import math
import re
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import timedelta
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from app.collection import hash_value
from app.config import OPTIONS
from app.matching import normalize

ACTION_RULES = {
    "release": r"\b(?:release[sd]?|launch(?:ed|es)?|unveil(?:s|ed)?|announces?)\b|发布|推出|上线",
    "shipping": r"\b(?:shipments?|deliver(?:y|ies)|shipping)\b|出货|交付",
    "funding": r"\b(?:funding|raises?|financing)\b|融资|募资",
    "outage": r"\b(?:outages?|downtime|disruption)\b|故障|中断|宕机",
    "earnings": r"\b(?:earnings|quarterly results)\b|财报|业绩",
    "capacity": r"\b(?:capacity|expansion|expand(?:s|ed)?)\b|扩产|产能",
}
STOP_WORDS = {
    "a", "an", "and", "as", "at", "by", "for", "from", "in", "is", "of", "on", "the", "to", "with",
    "ai", "model", "models", "chip", "chips", "new", "latest", "developers", "labs", "company",
}
WORD = re.compile(r"[a-z0-9]+|[\u3400-\u9fff]+")
GENERIC_ENTITIES = {"ai", "chips", "semiconductors"}


def canonical_link(signal):
    if not signal.url or signal.url_kind != "article":
        return ""
    data = urlsplit(signal.url)
    fields = [(k, v) for k, v in parse_qsl(data.query) if not k.lower().startswith("utm_")
              and k.lower() not in {"ref", "fbclid", "gclid"}]
    return urlunsplit(("https", data.netloc.lower().removeprefix("www."),
                       data.path.rstrip("/"), urlencode(sorted(fields)), ""))


@dataclass
class Fingerprint:
    title: str
    entities: set
    actions: set
    terms: set
    url: str
    context_only: bool

    @property
    def signature(self):
        return hash_value([self.title, sorted(self.entities), self.context_only])[:24]


def describe(signal, matcher):
    title = normalize(signal.raw_title).lstrip("#")
    entities = set(signal.matched_keywords)
    context_only = signal.context_only or signal.kind == "hashtag"
    text = matcher.without_aliases(title, entities)
    actions = {name for name, rule in ACTION_RULES.items() if re.search(rule, text)}
    for action in actions:
        text = re.sub(ACTION_RULES[action], " ", text)
    terms = set()
    for value in WORD.findall(text):
        if value in STOP_WORDS:
            continue
        if value.isascii():
            terms.add(value)
        else:
            terms.update(value[index:index + 2] for index in range(len(value) - 1))
    return Fingerprint(title, entities, actions, terms, canonical_link(signal), context_only)


def same_event(a, b):
    if a.context_only != b.context_only:
        return False
    if (a.url and a.url == b.url) or a.title == b.title:
        return True
    if a.context_only or not a.entities.intersection(b.entities):
        return False
    if a.actions and b.actions and not a.actions.intersection(b.actions):
        return False
    a_numbers = {term for term in a.terms if term.isdigit()}
    b_numbers = {term for term in b.terms if term.isdigit()}
    if a_numbers and b_numbers and a_numbers != b_numbers:
        return False
    overlap = a.terms.intersection(b.terms)
    if not overlap:
        return False
    strong_entity = a.entities.intersection(b.entities) - GENERIC_ENTITIES
    common_action = a.actions.intersection(b.actions)
    ratio = len(overlap) / len(a.terms | b.terms)
    return (ratio >= 0.65 and len(overlap) >= 2
            or bool(strong_entity and common_action and ratio >= 0.4 and len(overlap) >= 2))


@dataclass
class Cluster:
    fingerprints: list = field(default_factory=list)
    signals: list = field(default_factory=list)

    def append(self, signature, signal):
        self.fingerprints.append(signature)
        self.signals.append(signal)


def cluster_signals(signals, matcher):
    clusters = []
    by_entity = defaultdict(set)
    by_title = {}
    by_url = {}
    for signal in signals:
        fp = describe(signal, matcher)
        candidates = set().union(*(by_entity[key] for key in fp.entities))
        for lookup, value in ((by_title, fp.title), (by_url, fp.url)):
            if value and (value, fp.context_only) in lookup:
                candidates.add(lookup[(value, fp.context_only)])
        selected = next((index for index in sorted(candidates)
                         if all(same_event(fp, known) for known in clusters[index].fingerprints)), None)
        if selected is None:
            selected = len(clusters)
            clusters.append(Cluster())
        target = clusters[selected]
        if fp.signature not in {known.signature for known in target.fingerprints}:
            target.fingerprints.append(fp)
        target.signals.append(signal)
        for key in fp.entities:
            by_entity[key].add(selected)
        by_title[(fp.title, fp.context_only)] = selected
        if fp.url:
            by_url[(fp.url, fp.context_only)] = selected
    return clusters


def heat_score(signal, heat_values):
    if signal.rank:
        return 1 / (1 + math.log1p(signal.rank - 1) * 0.55)
    if signal.heat is None:
        return None
    distribution = heat_values.get(signal.run_id, [])
    if len(distribution) <= 1:
        return 0.5
    below = sum(value < signal.heat for value in distribution)
    equal = sum(value == signal.heat for value in distribution)
    return (below + 0.5 * equal) / len(distribution)


def evidence_row(signal, name, matcher):
    return {
        "id": signal.pk, "source": signal.source, "source_name": name, "platform": signal.platform,
        "raw_title": signal.raw_title, "signal_text": signal.signal_text, "url": signal.url,
        "url_kind": signal.url_kind, "timestamp": signal.timestamp.isoformat() if signal.timestamp else None,
        "observed_at": signal.observed_at.isoformat(), "time_precision": signal.time_precision,
        "heat": signal.heat, "heat_label": signal.heat_label, "rank": signal.rank, "growth": signal.growth,
        "region": signal.region, "kind": signal.kind, "source_domain": signal.source_domain,
        "context_only": signal.context_only, "matched_keywords": [
            matcher.keywords[key].label for key in signal.matched_keywords if key in matcher.keywords
        ],
    }


def event_summary(cluster, matcher, source_map, runs, heat_values, now):
    latest = {}
    for signal in sorted(cluster.signals, key=lambda row: (-row.observed_at.timestamp(), row.rank or 1_000_000)):
        latest.setdefault((signal.source, signal.region, signal.kind), signal)
    newest = list(latest.values())
    # One platform can expose multiple lists and representations of the same topic.
    platforms = sorted({signal.platform for signal in newest})
    keys = sorted({key for signal in newest for key in signal.matched_keywords},
                  key=lambda key: (-matcher.keywords[key].weight, key))
    primary = min(newest, key=lambda s: (
        s.kind not in {"headline", "live_story", "live_alert"}, s.context_only, -s.observed_at.timestamp()
    ))
    history = defaultdict(set)
    for sig in cluster.signals:
        history[(sig.source, sig.region)].add(sig.run_id)
    repeated = False
    comparable_new = False
    for sig in newest:
        adjacent = runs.get(sig.source, [])
        interval = timedelta(minutes=source_map[sig.source].interval_minutes)
        if len(adjacent) >= 2 and sig.run_id == adjacent[0].pk:
            earlier = adjacent[1]
            gap = (adjacent[0].snapshot_at or adjacent[0].started_at) - (earlier.snapshot_at or earlier.started_at)
            if 0.75 * interval <= gap <= 2.1 * interval:
                present = earlier.pk in history[(sig.source, sig.region)]
                repeated |= present
                comparable_new |= sig.kind == "ranked_trend" and not present

    kinds = {sig.kind for sig in newest}
    if primary.context_only or primary.kind == "hashtag":
        momentum, freshness = "标签观察", 0.15
    elif comparable_new or ("breakout" in kinds and not repeated):
        momentum, freshness = "新信号", 1.0
    elif repeated:
        momentum, freshness = "持续发酵", 0.70
    else:
        momentum, freshness = "首次观察", 0.45
    decay = max(0.25, 1 - (now - max(s.observed_at for s in newest)).total_seconds() / 86400)
    relevance = min(1, max(matcher.keywords[key].weight for key in keys) / 1.5 + 0.12 * (len(keys)-1))
    heat_by_platform = {}
    for signal in newest:
        value = heat_score(signal, heat_values)
        if value is not None:
            heat_by_platform[signal.platform] = max(heat_by_platform.get(signal.platform, 0), value)
    signals = {
        "relevance": relevance, "coverage": min(len(platforms) / 3, 1),
        "heat": sum(heat_by_platform.values()) / len(heat_by_platform) if heat_by_platform else 0.32,
        "momentum": freshness * decay,
    }
    weights = OPTIONS["ranking"]
    reasons = {key: round(value * weights[key], 1) for key, value in signals.items()}
    score = min(49 if momentum == "标签观察" else 100, round(sum(reasons.values()), 1))
    return {
        "title": primary.raw_title, "category": matcher.keywords[keys[0]].label,
        "keywords": [matcher.keywords[key].label for key in keys], "score": score,
        "platforms": platforms, "regions": sorted({sig.region for sig in newest if sig.region}),
        "momentum": momentum, "reasons": reasons,
        "signatures": sorted({item.signature for item in cluster.fingerprints}),
        "evidence": [evidence_row(sig, source_map[sig.source].name, matcher) for sig in newest],
        "first_seen": min(sig.observed_at for sig in cluster.signals),
        "last_seen": max(sig.observed_at for sig in newest),
        "summary": "",
    }
