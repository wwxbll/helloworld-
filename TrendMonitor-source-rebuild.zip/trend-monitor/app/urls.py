from django.contrib import admin
from django.urls import path

from app import views

urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("events/<slug:key>/", views.event_detail, name="event"),
    path("api/notifications/", views.notifications),
    path("admin/", admin.site.urls),
]
