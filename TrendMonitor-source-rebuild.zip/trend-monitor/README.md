# 热点雷达

聚合 AI、芯片、半导体、OpenAI、Anthropic 和英伟达相关热点。看板提供写作切入角度、标题草案、事件证据和按主题筛选的热榜。任务计划程序或 cron 定期采集，高优先级事件通过桌面弹窗推送。

[项目结构与使用指南](docs/项目结构与使用指南.md)

## Windows 便携版

收到 `TrendMonitor-portable-win-x64-*.zip` 后，解压整个文件夹，双击 `TrendMonitor.exe`。首次启动会建立空数据库、打开本地看板和托盘，并开始检查来源。收件人可以按包内的「快速开始」操作。

修改源码后，装有 64 位 Python 3.11 或 3.12 的 Windows 构建机可从项目目录重新生成便携包。构建默认使用 3.12，只有 3.11 时，在命令末尾加 `-PythonVersion 3.11`。

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\build-portable.ps1
```

构建产物在 `dist/`。自定义构建环境、增加适配器和分发步骤见[使用指南第 8 节](docs/项目结构与使用指南.md#8-windows-便携版与重建)。

## 启动

以下命令适用于源码目录。

从项目目录运行。请先准备 Python 3.11 或 3.12，然后建立虚拟环境并安装依赖。下面用 3.12 举例，使用 3.11 时把 `py -3.12` 改成 `py -3.11`。

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt -r requirements-desktop.txt
.\.venv\Scripts\python.exe -X utf8 -m app.run_once --init --job all
.\.venv\Scripts\python.exe -m app.serve
```

打开 [本地看板](http://127.0.0.1:18765/)。在已登录的 Windows 桌面另开一个窗口启动通知客户端。

```powershell
.\.venv\Scripts\python.exe -m app.desktop
```

`--job collect` 只采集，`--job digest` 只重算，`--job all` 依次执行。`--source aiweekly_live` 可限定采集源。`--force` 可手动重新检查公开来源，需凭据的接口仍遵守各自的轮询间隔。

## 热点选题和平台热榜

首页左侧提供写作选题，每张卡含切入角度和标题草案。初始优先关注模型发布、芯片供应、研究进展、公司关键决策和行业政策，切入角度聚焦影响与可核查的证据。详情页显示建议和原始证据。

右侧可在「全部 / 国内 / 国际」之间切换。国内可看微博、百度、抖音、B 站、小红书、V2EX 热榜，以及 IT之家、少数派、Solidot、开源中国的最新资讯。国际可看 X、Google、TikTok、Reddit 和 Hacker News。

所有平台的榜单、资讯和手工导入的榜单都只显示命中关注词的条目。保留来源排名或订阅顺序，并标明命中的主题。点主题标签可以同时筛选左侧选题和右侧榜单。一期没有匹配结果时显示空状态。加粗条目可以跳到对应选题。旧快照保留原时间并标为「暂未更新」。

- **X** 使用 Apify 的全球榜入口，配置免费凭据后采集。Trends24 的服务条款限制自动抓取。 [Trends24 条款](https://trends24.in/terms)
- **Google** 合并美国、英国、加拿大、澳大利亚和新加坡的 Trending Now RSS。重复词按覆盖地区数优先，再参考单地区最高热度和榜内顺序。热度数字显示各地区最高的区间值。 [Google Trending Now](https://support.google.com/trends/answer/3076011)
- **TikTok** 使用 Trends MCP，默认美国热门标签榜，每 24 小时最多检查一轮，显示前 10。免费榜可能延迟。 [Trends MCP 文档](https://www.trendsmcp.ai/docs/mcp)
- **Reddit** 显示精选版块榜的可用状态，允许导入获得授权的榜单快照。
- **Hacker News** 使用公开 Top Stories API，默认展示前 8 条热门讨论。 [Hacker News API](https://github.com/HackerNews/API)

[榜单配置和导入方法](docs/项目结构与使用指南.md#44-配置榜单及导入快照)

## 来源与费用

| 平台 | 本版接入 | 免费限制与状态 |
| --- | --- | --- |
| X | Apify Twitter Trends Scraper，单地区榜 | 需确认 Apify Free 账号及 token。本机当前等待免费密钥。按每轮最多 50 条、每两小时一次，约 $1.82/月用量，计入共享免费额度。使用前确认供应商的供数条款。 |
| Google | 五个地区的官方 Trending Now RSS；关键词 Rising 走独立 Apify Actor | RSS 无密钥、每 2 小时。Rising/Breakout 每 4 小时轮换查询最多 6 个种子，约 $1.62/月用量。两种数据有独立的信号类型。 |
| AI Weekly | 首页 Live Alerts 静态 HTML；结构异常时读实时报道页 | 免费、无密钥，首页约 5 条。站点 RSS 是期刊订阅。 |
| 微博、抖音、B 站、小红书 | okdata 公开聚合榜 HTML | 免费、无密钥。按页面标注的北京时间确认快照时效。小红书每天检查一次，其余每 2–4 小时检查。 |
| 百度 | 百度热搜实时榜 HTML | 免费、无密钥，每 2 小时检查。展示源榜排名和热搜指数。 |
| V2EX | 公开热门主题 JSON | 免费、无密钥，每 2 小时检查。展示上游排序和回复数。 |
| IT之家、少数派、Solidot、开源中国 | 站点 RSS | 免费、无密钥，每 2–4 小时检查。 |
| Hacker News | 官方 Top Stories API | 免费、无密钥，每 2 小时检查，取前 8 条。 |
| TikTok | Trends MCP 热门标签榜 REST | 需免费 key。默认美国，每天检查一次，每次最多 10 条，免费榜单可能延迟。 |
| Reddit | 来源状态和手工导入 | 自动入口暂不可用，支持导入获得授权的精选版块榜。 |

Apify Free 的 $5 额度由账号所有 Actor 共享。项目按单轮上限预留用量，在 $4.80/月停止新请求；单轮也设置了 Apify 的 `maxTotalChargeUsd`。公共页面检查 robots.txt 并使用条件请求。遇到鉴权、验证码、限流或无法确认结构时记录状态，等待下次可用入口。付费路径已关闭。 [Apify Free](https://apify.com/pricing) · [X Actor](https://apify.com/omkar-cloud/twitter-trends-scraper) · [Google RSS](https://trends.google.com/trending/rss?geo=US) · [Google Rising Actor](https://apify.com/lergassy/google-trends-scraper) · [AI Weekly](https://aiweekly.co/) · [微博聚合榜](https://okdata.online/zh/tools/hot-search/weibo/) · [Trends MCP](https://www.trendsmcp.ai/pricing)

国内平台选取参考了 TrendRadar 的公开配置。榜单优先使用已验证的公开页面、社区接口和站点订阅。 [TrendRadar 平台配置](https://github.com/sansan0/TrendRadar/blob/master/config/config.yaml) · [公开聚合榜](https://okdata.online/zh/tools/hot-search/) · [百度热搜](https://top.baidu.com/board?tab=realtime) · [V2EX 热门主题](https://www.v2ex.com/api/topics/hot.json)

Reddit 在 2026 年 5 月宣布关闭匿名 JSON，2026 年 10 月 31 日停止接受新的公共 Data API 请求，2026 年 11 月 13 日结束 RSS 支持。2027 年 1 月 12 日起开始移除未登记应用及用户访问权限，2027 年 3 月结束其余公共 API 访问。已有批准凭据可用于过渡。 [Reddit 公共 API 公告](https://www.reddit.com/r/redditdev/comments/1wubcvf/moving_data_api_apps_to_the_developer_platform/) · [RSS 停用公告](https://support.reddithelp.com/hc/en-us/articles/55472297340308-Changelog-November-10-2026)

### 凭据

| 环境变量 | 用途 |
| --- | --- |
| APIFY_TOKEN | X 和 Google Rising 共用的 Free 账户 token |
| APIFY_FREE_PLAN_CONFIRMED=1 | 确认账户为 Apify Free 后设置 |
| TRENDS_MCP_API_KEY | TikTok 免费榜单 |
| TRENDS_MCP_FREE_CONFIRMED=1 | 确认账户为无付费积分的 Free 档后设置 |
| TREND_NOTIFY_TOKEN | HTTPS 远程客户端的 Bearer token，服务端与客户端使用同一随机值 |
| TREND_CLOUD_API_KEY | 预留的云端模型接口 |

将凭据放在启动进程的环境变量里。Windows 调度需要设置运行任务的账户环境，Linux 可用受权限保护的服务环境文件。

## 采集代理

默认的 `network.proxy: auto` 会沿用 Python 能读取的代理设置。浏览器的自动代理脚本（PAC）和扩展通常只对浏览器生效。采集需要显式代理时，在 `config/app.yaml` 修改已有的配置，把示例端口换成代理软件显示的 **HTTP 或混合端口**。手动采集和定时任务都会读这个文件。

```yaml
network:
  proxy: 'http://127.0.0.1:7890'
```

`TREND_PROXY` 可以覆盖该配置，值为 `direct` 时直接连接。`auto` 下识别 `HTTP_PROXY`、`HTTPS_PROXY`，必要时回退到 `ALL_PROXY`。本机环回地址始终直连，其他直连域名可通过 `NO_PROXY` 设置。访问 HTTPS 站点时，普通 HTTP 代理地址仍以 `http://` 开头。 [Python 代理设置](https://docs.python.org/3.12/library/urllib.request.html#urllib.request.getproxies)

改完可用公开 RSS 单独测试。运行结果里的 `ok` 表示采集成功，`network_error` 后面会显示代理、证书或连接错误的提示。

```powershell
.\.venv\Scripts\python.exe -X utf8 -m app.run_once --job collect --source google_trending_now --force
```

## CPU 摘要

本地摘要支持 Qwen3 4B Q4 和 llama.cpp CPU 后端。准备模型和执行程序后，从项目目录启动环回服务：

```powershell
.\runtime\llama-cpu\llama-server.exe -m .\runtime\Qwen3-4B-Q4_K_M.gguf --host 127.0.0.1 --port 18766 --alias qwen3-4b-q4 --n-gpu-layers 0 --threads 6 --ctx-size 4096 --parallel 1 --reasoning off
```

模型约 2.5 GB，官方 SHA256 为 `7485fe6f11af29433bc51cab58009521f205840f5b4ae3a32fa7f92e8534fdf5`。`runtime/` 目录存放本机模型及运行时。可按目标 OS 更换运行时。 [Qwen GGUF](https://huggingface.co/Qwen/Qwen3-4B-GGUF) · [llama.cpp](https://github.com/ggml-org/llama.cpp/releases)

采用 Ollama 时，将 `TREND_MODEL_PROVIDER` 设为 `ollama`、`TREND_MODEL_URL` 设为 `http://127.0.0.1:11434`、`TREND_MODEL_NAME` 设为 `qwen3:4b-q4_K_M`。本地模型暂不可用时用规则模板生成摘要。将来启用云模型须配置 `cloud_openai`、HTTPS 接口、密钥和 `TREND_ALLOW_CLOUD=1`。重要性、跨源、新上榜和持续发酵由程序基于证据快照计算。

## 改关注主题和选题提示词

**改关注范围**时，编辑 [config/keywords.yaml](config/keywords.yaml)。`label` 是主题名称，`aliases` 放中文、英文或常见别名。增加主题就加一项，停用可以写 `enabled: false`，也可以从文件中去掉整项。保存后运行下面的命令，将这份完整词表应用到数据库，并用已有快照重算选题。

```powershell
.\.venv\Scripts\python.exe -X utf8 -m app.run_once --job digest --sync-keywords --no-notify
```

**改写作角度**时，编辑 [config/editorial.yaml](config/editorial.yaml) 的 `prompt: |` 下方文字，保留两格缩进。该提示词用于本轮优先的前 5 个选题的模型生成。启用本地模型时将 `config/app.yaml` 的 `model.provider` 设为 `local_openai`，并启动模型服务。`priority_terms` 和 `priority_bonus` 调整优先排序，`fallback` 是未匹配具体事件规则时的默认角度。只改这个文件时，保存后重算摘要即可。

```powershell
.\.venv\Scripts\python.exe -X utf8 -m app.run_once --job digest --no-notify
```

### 在管理页面编辑

```powershell
.\.venv\Scripts\python.exe manage.py createsuperuser
```

访问 `/admin/`，登录后进入「关注词」。填唯一英文标识、名称、别名和可选的 Google 查询种子。例如「台积电」可用 `["台积电", "台積電", "TSMC"]`，查询种子为 `["TSMC"]`。停用或删除也在这里处理。下次作业会用当前词表重算近期快照。使用 `--sync-keywords` 会以文件为准，停用只在管理页面创建、但未列在文件中的词。

```powershell
.\.venv\Scripts\python.exe -X utf8 manage.py keywords import .\config\examples\tsmc.yaml
.\.venv\Scripts\python.exe -X utf8 manage.py keywords export
.\.venv\Scripts\python.exe -X utf8 -m app.run_once --job digest
```

## 自己新增或停用平台

1. **添加采集来源。** 在 [config/sources.yaml](config/sources.yaml) 的 `sources:` 下追加一项。公开 RSS、静态网页、JSON 数组分别使用 `rss`、`html`、`json_list`。起一个唯一的 `id`，并填写平台、名称和数据入口。
2. **显示右侧榜单。** 在 [config/app.yaml](config/app.yaml) 的 `boards:` 下追加一项。`sources` 填上一步的来源 ID，`kind` 对应来源的 `options.signal_type`，`group` 填 `domestic` 或 `international`。保存后重启看板。
3. **单源验证。** 在项目目录运行下面的命令，把 `company_research_feed` 换成实际来源 ID。`rows` 是采集条数，`matched` 是命中当前关注词的条数。采集成功后，定时任务会按配置检查这个来源。

```powershell
.\.venv\Scripts\python.exe -X utf8 -m app.run_once --job all --source company_research_feed --no-notify
```

匹配通用格式的平台只要改配置。需要多步请求或特殊协议时，在 `app/sources/` 增加采集适配器，再用同样的配置登记。停用时把该来源的 `enabled` 改为 `false`，再运行单源命令。想隐藏整张右侧卡片，移除 `boards:` 中的对应项并重启看板。

两个文件的可复制示例、字段对应和空榜排查见[项目结构与使用指南的「新增平台」](docs/项目结构与使用指南.md#42-新增平台)。

## 定时采集、桌面通知和远程访问

Windows 的注册脚本在当前用户登录时每 2 小时运行采集与摘要。先完成初始化，再预览或注册任务。采集日志位于 `data/scheduled-collect.log`。

```powershell
.\scripts\register-windows-task.ps1 -WhatIf
.\scripts\register-windows-task.ps1
```

Linux 或 WSL2 可使用 cron，也可使用 systemd timer。cron 示例为 `0 */2 * * *`，从项目目录执行 `.venv/bin/python -m app.run_once --job all`。SQLite 和作业锁应放在应用主机的持久化盘。每轮最多生成一条推送，默认阈值 58。

默认 Qt 客户端支持 Windows 10 1809+ x64 的交互式桌面。Linux 图形桌面安装桌面依赖后可用 `--backend native` 走系统托盘通知。无桌面的 Linux 服务端运行采集和 Web，Windows 客户端可用 `--url` 或 `TREND_PUBLIC_URL` 指向部署后的 HTTPS 服务。 [Qt 平台支持](https://doc.qt.io/qt-6.11/supported-platforms.html)

使用 `TREND_CONFIG_DIR`、`TREND_DATA_DIR`、`TREND_DB_PATH`、`TREND_HOST`、`TREND_PORT` 和 `TREND_TIME_ZONE` 设置路径、地址与时区。需要远程访问时，配置 HTTPS 反向代理或私网访问，并设置 `TREND_ALLOWED_HOSTS`、`TREND_TRUSTED_ORIGINS`、`TREND_HTTPS=1`、`TREND_DJANGO_SECRET` 和通知 token。看板浏览权限可以在反向代理设置。数据库的备份和恢复步骤见使用指南。

## 独立验收演示

```powershell
.\.venv\Scripts\python.exe -X utf8 -m app.run_once --demo --init --job all
.\.venv\Scripts\python.exe -m app.serve --demo --port 18767
.\.venv\Scripts\python.exe -X utf8 -m app.desktop --demo --url http://127.0.0.1:18767 --once
.\.venv\Scripts\python.exe -X utf8 manage.py test
```

演示使用独立 SQLite 数据库和两轮虚构数据。界面区分「演示样本」与真实采集状态。Reddit 在演示中返回失败状态。`demo_enabled` 仅覆盖模拟状态。桌面命令可追加 `--capture .\verification\windows-toast.png`，截取实际显示的弹窗区域。

