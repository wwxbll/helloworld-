import re
import sys
from pathlib import Path

from PyInstaller.utils.hooks import collect_submodules

root = Path(SPECPATH).resolve().parent
sys.path.insert(0, str(root))
assets = [(str(root / "app" / name), "app/" + name) for name in ("templates", "static")]
modules = collect_submodules("app", filter=lambda name: name != "app.tests")

analysis = Analysis(
    [str(root / "app" / "portable.py")],
    pathex=[str(root)],
    datas=assets,
    hiddenimports=modules,
    hookspath=[str(root / "packaging" / "hooks")],
    excludes=["app.tests"],
)
# Qt uses the Windows ICU exports. A build Python may carry a different ICU
# with the same DLL name, which would otherwise shadow the Windows library.
analysis.binaries = [
    entry for entry in analysis.binaries
    if not re.fullmatch(r"icu(?:uc|in|dt[0-9]+)\.dll", entry[0], re.IGNORECASE)
]
python_modules = PYZ(analysis.pure)
launcher = EXE(
    python_modules, analysis.scripts, [],
    exclude_binaries=True,
    name="TrendMonitor",
    console=False,
    upx=False,
)
bundle = COLLECT(launcher, analysis.binaries, analysis.datas, upx=False, name="TrendMonitor")
