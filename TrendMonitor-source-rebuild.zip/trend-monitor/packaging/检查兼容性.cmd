@echo off
start "" /wait "%~dp0TrendMonitor.exe" --compat-check
if exist "%~dp0compatibility-check.txt" start "" notepad.exe "%~dp0compatibility-check.txt"
