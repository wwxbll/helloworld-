from PyInstaller.utils.hooks import collect_all

# Include Django's admin, translations, and built-in database migrations.
# Application modules and resources are collected separately by the spec.
datas, binaries, hiddenimports = collect_all("django", on_error="ignore")
