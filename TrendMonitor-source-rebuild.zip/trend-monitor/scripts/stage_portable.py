import argparse
import os
import shutil
import subprocess
import sys
from datetime import datetime
from importlib import metadata
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile

import yaml


def prepare_config(project, bundle):
    config = bundle / "config"
    config.mkdir()
    for name in ("app.yaml", "sources.yaml", "keywords.yaml", "editorial.yaml"):
        shutil.copy2(project / "config" / name, config / name)
    app_config = config / "app.yaml"
    settings = yaml.safe_load(app_config.read_text(encoding="utf-8"))
    settings["model"]["provider"] = "rules"
    settings.setdefault("network", {})["proxy"] = "auto"
    app_config.write_text(yaml.safe_dump(settings, allow_unicode=True, sort_keys=False), encoding="utf-8")


def prepare_notices(project, bundle):
    notices = bundle / "licenses"
    shutil.copytree(project / "packaging" / "licenses", notices)
    python_license = Path(sys.base_prefix) / "LICENSE.txt"
    if python_license.is_file():
        shutil.copy2(python_license, notices / "Python-LICENSE.txt")
    shipped = []
    for distribution in metadata.distributions():
        name = distribution.metadata["Name"]
        shipped.append(f"{name} {distribution.version}")
        for record in distribution.files or ():
            if ".dist-info" in record.as_posix() and record.name.lower().startswith(("license", "copying", "notice")):
                target = notices / name / record.name
                target.parent.mkdir(exist_ok=True)
                shutil.copy2(distribution.locate_file(record), target)
    qt_version = metadata.version("PySide6-Essentials")
    qt_series = ".".join(qt_version.split(".")[:2])
    qt_sources = f"https://download.qt.io/official_releases/qt/{qt_series}/{qt_version}/submodules/"
    (notices / "组件与源代码.txt").write_text(
        f"Build Python {sys.version.split()[0]}\n\nBuild environment packages:\n"
        + "\n".join(sorted(shipped, key=str.casefold))
        + f"\n\nQt / Qt for Python {qt_version} (LGPL v3)\n"
        + f"Qt modules: {qt_sources}\n"
        + f"Qt for Python: https://code.qt.io/cgit/pyside/pyside-setup.git/tag/?h=v{qt_version}\n"
        + "Qt DLLs and plugins are separate files in _internal/PySide6. See LGPL-3.0.txt and GPL-3.0.txt.\n",
        encoding="utf-8",
    )


def main():
    parser = argparse.ArgumentParser(description="Build a Windows x64 portable archive.")
    parser.add_argument("--output", type=Path, required=True)
    output = parser.parse_args().output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    project = Path(__file__).resolve().parents[1]
    name = f"TrendMonitor-portable-win-x64-{datetime.now():%Y%m%d-%H%M%S}.zip"
    target = output / name
    if target.exists():
        raise FileExistsError(target)
    with TemporaryDirectory(prefix=".portable-", dir=output) as directory:
        stage = Path(directory)
        env = {key: value for key, value in os.environ.items() if not key.startswith("TREND_")}
        env["PYINSTALLER_CONFIG_DIR"] = str(stage / "cache")
        subprocess.run(
            [sys.executable, "-m", "PyInstaller", "--noconfirm", "--workpath", str(stage / "build"),
             "--distpath", str(stage / "dist"), str(project / "packaging" / "portable.spec")],
            cwd=project, env=env, check=True,
        )
        bundle = stage / "dist" / "TrendMonitor"
        prepare_config(project, bundle)
        prepare_notices(project, bundle)
        for name in ("快速开始.html", "检查兼容性.cmd"):
            shutil.copy2(project / "packaging" / name, bundle)
        archive = stage / name
        with ZipFile(archive, "w", ZIP_DEFLATED, compresslevel=6) as zip_file:
            for entry in sorted(bundle.rglob("*")):
                if entry.is_file():
                    zip_file.write(entry, entry.relative_to(bundle.parent).as_posix())
        with ZipFile(archive) as zip_file:
            damaged = zip_file.testzip()
            if damaged:
                raise OSError(f"Archive integrity check failed: {damaged}")
        archive.rename(target)
    print(f"Portable ZIP: {target}")


if __name__ == "__main__":
    main()
