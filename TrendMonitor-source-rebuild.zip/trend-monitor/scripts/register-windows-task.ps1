[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$TaskName = 'Trend Monitor - Collect',
    [ValidateRange(60, 1440)][int]$IntervalMinutes = 120,
    [switch]$Replace
)

$ErrorActionPreference = 'Stop'
$existing = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if ($existing -and -not $Replace) { throw '同名任务已存在。确认需要更新后加 -Replace。' }
if (-not $PSCmdlet.ShouldProcess($TaskName, 'Register scheduled collection task')) { return }

$project = Split-Path -Parent $PSScriptRoot
$collector = Join-Path $PSScriptRoot 'collect-windows.ps1'
$shell = (Get-Command powershell.exe).Source
$arguments = '-NoProfile -WindowStyle Hidden -File "' + $collector + '"'
$action = New-ScheduledTaskAction -Execute $shell -Argument $arguments -WorkingDirectory $project
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(2) -RepetitionInterval (New-TimeSpan -Minutes $IntervalMinutes) -RepetitionDuration (New-TimeSpan -Days 365)
$trigger.Repetition.Duration = $null
$settings = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Minutes 15)
$identity = [Security.Principal.WindowsIdentity]::GetCurrent().Name
$principal = New-ScheduledTaskPrincipal -UserId $identity -LogonType Interactive
$task = @{
    TaskName = $TaskName
    Action = $action
    Trigger = $trigger
    Settings = $settings
    Principal = $principal
    Description = 'Free-source Trend Monitor collection and digest'
    Force = $Replace
}
Register-ScheduledTask @task | Out-Null
Write-Output "已注册 $TaskName，每 $IntervalMinutes 分钟运行。"
