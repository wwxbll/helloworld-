[CmdletBinding()]
param([string]$Python = $env:TREND_PYTHON)

$ErrorActionPreference = 'Stop'
$project = Split-Path -Parent $PSScriptRoot
if (-not $Python) { $Python = Join-Path $project '.venv\Scripts\python.exe' }
if (-not (Test-Path -LiteralPath $Python -PathType Leaf)) { throw '未找到 Python，请设置 TREND_PYTHON。' }
$data = if ($env:TREND_DATA_DIR) { $env:TREND_DATA_DIR } else { Join-Path $project 'data' }
$log = Join-Path $data 'scheduled-collect.log'
$env:TREND_PROFILE = 'live'

Push-Location -LiteralPath $project
try {
    New-Item -ItemType Directory -Path $data -Force | Out-Null
    Add-Content -LiteralPath $log -Encoding utf8 -Value (Get-Date -Format o)
    & $Python -X utf8 -m app.run_once --job all 2>&1 | Out-File -LiteralPath $log -Encoding utf8 -Append
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
} finally {
    Pop-Location
}
