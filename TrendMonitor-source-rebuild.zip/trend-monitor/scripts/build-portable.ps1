[CmdletBinding()]
param(
    [string]$Python,
    [ValidateSet('3.11','3.12')]
    [string]$PythonVersion = '3.12',
    [string]$OutputDir,
    [switch]$SkipInstall
)

$ErrorActionPreference = 'Stop'
$project = Split-Path -Parent $PSScriptRoot
if (-not $OutputDir) { $OutputDir = Join-Path $project 'dist' }
$output = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($OutputDir)
if ($Python) {
    $buildPython = (Resolve-Path -LiteralPath $Python).Path
} else {
    $venvName = if ($PythonVersion -eq '3.12') { '.venv-build' } else { '.venv-build-311' }
    $venv = Join-Path $project $venvName
    $buildPython = Join-Path $venv 'Scripts\python.exe'
    if (-not (Test-Path -LiteralPath $buildPython -PathType Leaf)) {
        $py = (Get-Command py.exe -ErrorAction Stop).Source
        & $py "-$PythonVersion" -m venv $venv
        if ($LASTEXITCODE -ne 0) { throw "Could not create the Python $PythonVersion build environment." }
    }
}

Push-Location -LiteralPath $project
try {
    & $buildPython -c "import sys, sysconfig; sys.exit(0 if sys.version_info[:2] in {(3, 11), (3, 12)} and sysconfig.get_platform() == 'win-amd64' else 'Use 64-bit Python 3.11 or 3.12 on Windows.')"
    if ($LASTEXITCODE -ne 0) { throw 'Unsupported build environment.' }
    if (-not $SkipInstall) {
        & $buildPython -m pip install -r requirements-build.txt
        if ($LASTEXITCODE -ne 0) { throw 'Build dependency installation failed.' }
    }
    & $buildPython -X utf8 scripts/stage_portable.py --output $output
    if ($LASTEXITCODE -ne 0) { throw 'Portable build failed.' }
} finally {
    Pop-Location
}
