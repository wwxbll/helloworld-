import {LocalTranslator} from "./local-translation.js";

const $ = id => document.getElementById(id);
const labels = {web: "网页提取", manual: "用户提供正文", supplement: "用户补充正文"};
const engines = {local: "本地", deepl: "DeepL", local_model: "本地模型", llm: "云端大模型"};
const localModelAddresses = {Ollama: "http://127.0.0.1:11434/v1", "llama.cpp": "http://127.0.0.1:8080/v1"};
const fullDate = new Intl.DateTimeFormat("zh-CN", {
  year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit",
  minute: "2-digit", second: "2-digit", hour12: false, timeZoneName: "short",
});
const nameOf = new Intl.DisplayNames(["zh-CN"], {type: "language"});
const langs = [...new Set(("af ar az be bg bn bs ca cs cy da de el en eo es et eu fa fi fr ga gu" +
  " he hi hr hu hy id is it ja ka kk ko la lt lv mi mk mn mr ms nb nl nn no pa pl pt ro ru sk sl" +
  " so sq sr sv sw ta te th tl tr uk ur vi xh yo zh zu und").split(" "))];

const state = {
  articles: [], active: null, materials: new Map(), rows: new Map(), working: new Set(),
  sourceSignature: "", pollBusy: false, listVersion: 0, blockChange: 0,
  selection: [], cloud: null, exportTarget: null, toastTimer: null,
  submitChain: Promise.resolve(),
};

function node(tag, text = "", css = "") {
  const element = document.createElement(tag);
  if (text) element.textContent = text;
  if (css) element.className = css;
  return element;
}

function button(text, CSS, action) {
  const item = node("button", text, "button " + CSS);
  item.type = "button";
  item.addEventListener("click", action);
  return item;
}

async function api(path, {method = "GET", body} = {}) {
  const headers = {"X-Archive-Request": "1"};
  if (body !== undefined) headers["Content-Type"] = "application/json";
  const response = await fetch(path, {method, headers, body: body === undefined ? undefined : JSON.stringify(body)});
  if (!response.ok) {
    const result = await response.json().catch(() => ({}));
    throw new Error(typeof result.detail === "string" ? result.detail :
      response.status === 422 ? "请检查输入格式或长度。" : "操作未完成，请重试。");
  }
  return response.json();
}

function fmt(date) {
  return date ? fullDate.format(new Date(date)) : "";
}

function languageName(code) {
  return !code || code === "und" ? "待确认" : nameOf.of(code);
}

function hostname(url) {
  try { return new URL(url).hostname; } catch { return "粘贴正文"; }
}

function toast(message) {
  $("toast").textContent = message;
  $("toast").hidden = false;
  clearTimeout(state.toastTimer);
  state.toastTimer = setTimeout(() => { $("toast").hidden = true; }, 3500);
}

function fieldError(id, message = "") {
  $(id).textContent = message;
  $(id).hidden = !message;
}

function articleStatus(article) {
  if (article.state === "queued") return "等待抓取";
  if (article.state === "fetching") return "抓取中";
  if (article.state === "failed") return "需要处理";
  if (!article.total) return "等待正文";
  if (article.done < article.total) return article.done + "/" + article.total + " 段";
  return "已就绪";
}

function displaySources() {
  const query = $("source-search").value.trim().toLowerCase();
  const items = state.articles.filter(a => [a.title, a.original_url].some(value =>
    (value || "").toLowerCase().includes(query)));
  const signature = JSON.stringify([query, items, state.active, state.articles.length]);
  if (state.sourceSignature === signature) return;
  state.sourceSignature = signature;
  $("source-count").textContent = state.articles.length;
  $("sources").replaceChildren();
  if (!items.length) {
    $("sources").append(node("p", query ? "没有匹配的来源。" : "还没有已收录的网页。", "source-placeholder"));
    return;
  }
  for (const article of items) {
    const entry = node("button", "", "source-item" + (state.active === article.id ? " active" : ""));
    entry.type = "button";
    if (article.id === state.active) entry.setAttribute("aria-current", "true");
    const title = node("span", article.title || hostname(article.original_url), "source-title");
    const meta = node("span", "", "source-detail");
    meta.append(node("span", hostname(article.original_url), "domain"), node("span", "·"),
      node("span", articleStatus(article), "state"));
    entry.append(title, meta);
    entry.addEventListener("click", () => openArticle(article.id, true));
    $("sources").append(entry);
  }
}

async function updateList() {
  const version = ++state.listVersion;
  const articles = await api("/api/articles");
  if (version !== state.listVersion) return;
  state.articles = articles;
  const ids = new Set(articles.map(article => article.id));
  for (const [id, material] of state.materials) {
    if (ids.has(id)) continue;
    forgetRows(material);
    material.element.remove();
    state.materials.delete(id);
  }
  if (state.selection.some(segment => !state.rows.has(segment.blockId))) clearSelection();
  if (!ids.has(state.active)) state.active = articles[0]?.id || null;
  $("collection-toolbar").hidden = !articles.length;
  $("empty-view").hidden = Boolean(articles.length);
  $("saved-count").textContent = articles.length + " 个 · 自动保存";
  displaySources();
  const updates = [];
  const container = $("materials");
  let previous = null;
  for (const [index, article] of articles.entries()) {
    const material = state.materials.get(article.id) || makeMaterial(article);
    const expected = previous ? previous.nextElementSibling : container.firstElementChild;
    if (material.element !== expected) container.insertBefore(material.element, expected);
    previous = material.element;
    material.parts["move-up"].disabled = index === 0;
    material.parts["move-down"].disabled = index === articles.length - 1;
    material.element.classList.toggle("active-material", article.id === state.active);
    const signature = JSON.stringify(article);
    if (material.summary !== signature || !material.view ||
        ["queued", "running"].includes(material.view?.job?.state)) {
      material.summary = signature;
      updates.push(refreshDetail(material).catch(error => {
        if (state.materials.has(material.id)) material.summary = "";
      }));
    }
  }
  await Promise.all(updates);
}

function sourceLink(url, label) {
  const link = node("a", label);
  link.href = url;
  link.title = url;
  link.target = "_blank";
  link.rel = "noreferrer";
  return link;
}

function articleNotice(view) {
  if (view.state === "queued" || view.state === "fetching")
    return [view.snapshot ? "正在重新抓取，当前正文版本仍可阅览。" : "正在抓取网页。可以继续粘贴下一条链接。", false];
  if (view.state === "failed") return [view.error || "网页抓取失败。", true];
  if (view.snapshot?.partial) return ["正文可能不完整。可核对来源，或补充遗漏段落。", true];
  if (!view.snapshot) return ["可以粘贴能访问到的正文。", false];
  return ["", false];
}

function setNotice(target, text, warning = false, action = null) {
  target.hidden = !text;
  target.classList.toggle("warning", warning);
  target.replaceChildren(node("span", text));
  if (action) target.append(action);
}

function renderHead(material, view) {
  const parts = material.parts;
  const snapshot = view.snapshot;
  const signature = JSON.stringify([view.id, snapshot, view.snapshots, view.state, view.checked_at, view.error]);
  if (signature === material.headSignature) return;
  material.headSignature = signature;
  parts["article-title"].textContent = snapshot?.title || hostname(view.original_url);
  const badges = parts["article-badges"];
  badges.replaceChildren(node("span", snapshot ? labels[snapshot.kind] : articleStatus(view),
    "badge" + (view.state === "failed" ? " pending" : "")));
  if (snapshot) badges.append(node("span", "原文 · " + languageName(snapshot.language), "badge quiet"));
  const fields = [];
  if (snapshot) {
    fields.push((snapshot.kind === "web" ? "抓取 " : "提交 ") + fmt(snapshot.captured_at));
    if (snapshot.author) fields.push("作者 " + snapshot.author);
    if (snapshot.published) fields.push("发布 " + snapshot.published);
  }
  if (view.checked_at && view.checked_at !== snapshot?.captured_at) fields.push("最近检查 " + fmt(view.checked_at));
  parts["article-meta"].replaceChildren(...fields.map(value => node("span", value)));
  const sources = parts["article-source"];
  sources.replaceChildren();
  if (view.original_url) sources.append(sourceLink(view.original_url,
    "原始链接 · " + view.original_url));
  if (snapshot?.final_url && snapshot.final_url !== view.original_url) sources.append(
    sourceLink(snapshot.final_url, "实际地址 · " + snapshot.final_url));
  sources.hidden = !sources.childElementCount;
  const [message, warning] = articleNotice(view);
  setNotice(parts["article-notice"], message, warning);
  const selected = parts["snapshot-select"];
  selected.replaceChildren(...view.snapshots.map(item => {
    const option = node("option", fmt(item.captured_at) + " · " + labels[item.kind]);
    option.value = item.id;
    return option;
  }));
  if (snapshot) selected.value = snapshot.id;
  selected.disabled = view.snapshots.length < 2;
  const busy = ["queued", "fetching"].includes(view.state);
  parts.refresh.hidden = !view.original_url;
  parts.refresh.disabled = busy;
  parts["manual-current"].textContent = snapshot ? "补充正文" : "粘贴正文";
  parts["manual-current"].disabled = busy;
  for (const key of ["reading-tools", "cloud-all", "export", "comparison"]) parts[key].hidden = !snapshot;
}

function getActive(block) {
  return block.translations.find(item => item.id === block.active_translation);
}

function engineName(translation) {
  if (translation.engine === "local" && translation.model) return translation.model + " 本地";
  if (["local_model", "llm"].includes(translation.engine) && translation.model)
    return engines[translation.engine] + " · " + translation.model;
  return engines[translation.engine] || translation.engine;
}

function sideMarks(block, id) {
  return block.highlights.filter(item => item.translation_id === id);
}

function visibleMarks(block) {
  return block.highlights.some(item => item.translation_id === null ||
    item.translation_id === block.active_translation);
}

function markText(container, text, marks) {
  if (!marks.length) {
    container.textContent = text;
    return;
  }
  const chars = Array.from(text);
  const breakpoints = [...new Set([0, chars.length, ...marks.flatMap(item => [item.start, item.end])])]
    .sort((a, b) => a - b);
  const pieces = [];
  for (let i = 1; i < breakpoints.length; i++) {
    const start = breakpoints[i - 1];
    const end = breakpoints[i];
    const value = chars.slice(start, end).join("");
    const matching = marks.filter(mark => start >= mark.start && start < mark.end);
    if (matching.length) {
      const mark = node("mark", value);
      mark.dataset.markId = matching[0].id;
      mark.title = "点击可复制或取消高亮";
      pieces.push(mark);
    } else {
      pieces.push(document.createTextNode(value));
    }
  }
  container.replaceChildren(...pieces);
}

function setCell(element, text, marks, translationId = null, pending = false) {
  const signature = JSON.stringify([text, marks, translationId, pending]);
  if (element.dataset.signature === signature) return;
  element.dataset.signature = signature;
  element.dataset.translationId = translationId || "";
  element.classList.toggle("inactive", pending);
  markText(element, text, marks);
}

function paragraphId(block) {
  return "P" + String(block.position).padStart(3, "0");
}

function renderNewRow(material, block) {
  const row = node("div", "", "pair kind-" + block.kind);
  row.id = "block-" + block.id;
  row.dataset.block = block.id;
  const left = node("div", "", "original");
  const right = node("div", "", "translated");
  const lHead = node("div", "", "cell-head");
  const rHead = node("div", "", "cell-head");
  const lActions = node("span", "", "cell-actions");
  const rActions = node("span", "", "cell-actions");
  const lText = node("p", "", "cell-text");
  const rText = node("p", "", "cell-text");
  lText.dataset.text = "left";
  rText.dataset.text = "right";
  const engineLabel = node("span", "", "engine-label");
  const language = button("语言", "plain", () => openLanguage(state.rows.get(block.id).block));
  language.title = "更正这一段的原文语言";
  const counterpart = button(paragraphId(block), "plain para-label", () => pulse(row));
  counterpart.title = "定位对应的双语段落";
  const version = button("译文版本", "plain", () => openVersions(state.rows.get(block.id).block));
  const cloud = button("重译", "plain", () => openCloud(material, block.id).catch(error => toast(error.message)));
  const retry = button("重试", "plain", () => retryLocal(block.id));
  const copy = button("复制双语", "plain", () => copyPair(material, state.rows.get(block.id).block));
  lActions.append(language, copy);
  rActions.append(retry, version, cloud);
  lHead.append(counterpart, lActions);
  rHead.append(engineLabel, rActions);
  left.append(lHead, lText);
  right.append(rHead, rText);
  row.append(left, right);
  const info = {material, row, block, lText, rText, engineLabel, version, language, cloud, retry, change: 0};
  state.rows.set(block.id, info);
  material.rows.set(block.id, info);
  return info;
}

function pendingText(block) {
  if (block.kind === "code") return "代码按原文保留";
  if (block.language === "zh") return "原文为中文";
  if (block.language === "und") return "原文语言待确认";
  if (block.local_error) return block.local_error;
  if (state.working.has(block.id)) return "翻译中…";
  if (!local.supported) return "此浏览器的本地翻译不可用";
  const status = local.status(block.language);
  if (status === "downloadable") return "等待启用语言包";
  if (status === "downloading") return "语言包下载中";
  if (status === "unavailable") return "本地暂不支持这个语言对";
  return "等待翻译";
}

function renderRow(info, block) {
  info.block = block;
  const active = getActive(block);
  info.lText.lang = block.language === "und" ? "" : block.language;
  setCell(info.lText, block.text, sideMarks(block, null));
  const rightLabel = active ? engineName(active) : "";
  if (info.engineLabel.textContent !== rightLabel) info.engineLabel.textContent = rightLabel;
  info.version.hidden = block.translations.length === (active ? 1 : 0);
  info.cloud.hidden = block.kind === "code" || block.language === "zh";
  info.retry.hidden = !block.local_error;
  info.language.title = "更正语言 · " + languageName(block.language);
  setCell(info.rText, active?.text || pendingText(block), active ? sideMarks(block, active.id) : [],
    active?.id, !active);
  info.row.hidden = info.material.parts["marked-only"].checked && !visibleMarks(block);
}

function rowSummary(material) {
  const blocks = [...material.rows.values()].map(info => info.block);
  const eligible = blocks.filter(b => b.language !== "zh" && b.kind !== "code");
  const complete = eligible.filter(b => b.active_translation != null).length;
  material.parts["translation-count"].textContent = eligible.length ? complete + " / " + eligible.length : "";
  material.parts["no-marks"].hidden = !material.parts["marked-only"].checked || blocks.some(visibleMarks);
}

function renderCloud(material, job) {
  const notice = material.parts["cloud-progress"];
  const busy = ["queued", "running"].includes(job?.state);
  material.parts["cloud-all"].disabled = busy;
  const signature = JSON.stringify(job);
  if (material.cloudSignature === signature) return;
  material.cloudSignature = signature;
  if (!job) {
    setNotice(notice, "");
    return;
  }
  const status = (engines[job.engine] || "") + " · " + job.done + "/" + job.total + " 段";
  if (busy) setNotice(notice, status + " · 正在翻译");
  else if (job.error) {
    setNotice(notice, status + " · " + job.error, true,
      job.engine === "deepl" ? null : button("续跑未完成段落", "secondary", async () => {
        try {
          await api("/api/cloud-jobs/" + job.id + "/retry", {method: "POST"});
          await refreshDetail(material);
        } catch (error) { toast(error.message); }
      }));
  } else if (job.mode === "candidate") {
    const info = state.rows.get(JSON.parse(job.block_ids)[0]);
    setNotice(notice, status + " · 重译已就绪", false, info ?
      button("查看重译", "secondary", () => openVersions(info.block)) : null);
  } else {
    setNotice(notice, status + " · 已完成");
  }
}

function forgetRows(material) {
  for (const id of material.rows.keys()) state.rows.delete(id);
  material.rows.clear();
  material.parts.rows.replaceChildren();
}

function renderArticle(material, view, requestChange) {
  const reset = material.view?.snapshot?.id !== view.snapshot?.id;
  material.view = view;
  renderHead(material, view);
  setCollapsed(material, material.collapsed);
  if (reset) {
    forgetRows(material);
    if (state.selection.some(segment => !state.rows.has(segment.blockId))) clearSelection();
  }
  const additions = document.createDocumentFragment();
  for (const block of view.blocks) {
    const old = material.rows.get(block.id);
    const info = old || renderNewRow(material, block);
    if (info.change <= requestChange) renderRow(info, block);
    if (!old) additions.append(info.row);
  }
  material.parts.rows.append(additions);
  rowSummary(material);
  renderCloud(material, view.job);
  renderPairs();
}

async function refreshDetail(material) {
  const version = ++material.request;
  const requestChange = state.blockChange;
  const query = material.pinned ? "?snapshot=" + material.pinned : "";
  const view = await api("/api/articles/" + material.id + query);
  if (version !== material.request || state.materials.get(material.id) !== material) return;
  renderArticle(material, view, requestChange);
}

function setCollapsed(material, collapsed) {
  material.collapsed = collapsed;
  material.parts["material-body"].hidden = !material.view || collapsed;
  material.parts.toggle.textContent = collapsed ? "展开" : "收起";
  material.parts.toggle.setAttribute("aria-expanded", String(!collapsed));
}

async function moveMaterial(material, direction) {
  const control = material.parts["move-" + direction];
  const hadFocus = document.activeElement === control;
  try {
    const result = await api("/api/articles/" + material.id + "/move", {method: "POST", body: {direction}});
    await updateList();
    if (result.moved && material.element.isConnected) {
      const fallback = material.parts[direction === "up" ? "move-down" : "move-up"];
      if (hadFocus) (control.disabled ? fallback : control).focus({preventScroll: true});
      control.scrollIntoView({block: "nearest"});
      toast("已保存素材顺序");
    }
  } catch (error) {
    toast(error.message);
  }
}

function makeMaterial(article) {
  const element = $("material-template").content.firstElementChild.cloneNode(true);
  const parts = Object.fromEntries([...element.querySelectorAll("[data-part]")].map(part =>
    [part.dataset.part, part]));
  const material = {id: article.id, element, parts, rows: new Map(), pinned: null,
    view: null, request: 0, collapsed: false, summary: "", headSignature: "", cloudSignature: ""};
  state.materials.set(article.id, material);
  parts["article-title"].textContent = article.title || hostname(article.original_url);
  parts["article-title"].id = "material-title-" + article.id;
  parts["material-body"].id = "material-body-" + article.id;
  parts.toggle.setAttribute("aria-controls", parts["material-body"].id);
  element.setAttribute("aria-labelledby", parts["article-title"].id);
  parts["article-badges"].append(node("span", articleStatus(article), "badge"));
  setCollapsed(material, false);

  parts.toggle.addEventListener("click", () => setCollapsed(material, !material.collapsed));
  parts.remove.addEventListener("click", () => openDelete(material));
  parts["move-up"].addEventListener("click", () => moveMaterial(material, "up"));
  parts["move-down"].addEventListener("click", () => moveMaterial(material, "down"));
  parts["snapshot-select"].addEventListener("change", event => {
    const selected = Number(event.target.value);
    material.pinned = selected === material.view.snapshots[0]?.id ? null : selected;
    refreshDetail(material).catch(error => toast(error.message));
  });
  parts["marked-only"].addEventListener("change", event => {
    for (const info of material.rows.values()) info.row.hidden = event.target.checked && !visibleMarks(info.block);
    rowSummary(material);
  });
  parts.refresh.addEventListener("click", async () => {
    try {
      await api("/api/articles/" + material.id + "/refresh", {method: "POST"});
      material.pinned = null;
      material.summary = "";
      await updateList();
    } catch (error) { toast(error.message); }
  });
  parts["manual-current"].addEventListener("click", () => openManual(material));
  parts["cloud-all"].addEventListener("click", () => openCloud(material).catch(error => toast(error.message)));
  parts.export.addEventListener("click", () => openExport(material));
  $("materials").append(element);
  return material;
}

function setSidebar(open) {
  $("sidebar").classList.toggle("open", open);
  $("sidebar-toggle").setAttribute("aria-expanded", String(open));
  $("sidebar-toggle").setAttribute("aria-label", open ? "收起来源" : "展开来源");
}

function openArticle(id, scroll) {
  const material = state.materials.get(id);
  if (!material) return;
  state.active = id;
  for (const item of state.materials.values()) item.element.classList.toggle("active-material", item === material);
  displaySources();
  setSidebar(false);
  if (scroll) {
    setCollapsed(material, false);
    material.element.scrollIntoView({block: "start"});
  }
  local.start();
}

function applyBlock(block) {
  const info = state.rows.get(block.id);
  if (info) {
    info.change = ++state.blockChange;
    renderRow(info, block);
    rowSummary(info.material);
  }
}

function pulse(row) {
  row.scrollIntoView({block: "nearest"});
  row.classList.add("paired-focus");
  setTimeout(() => row.classList.remove("paired-focus"), 1700);
}

async function copy(value) {
  try {
    await navigator.clipboard.writeText(value);
    toast("已复制");
  } catch {
    toast("无法访问剪贴板。可以选中文字后按 Ctrl+C。");
  }
}

function copyPair(material, block) {
  const snapshot = material.view.snapshot;
  const source = material.view.original_url;
  const current = getActive(block);
  const parts = [snapshot.title + " · " + paragraphId(block), block.text];
  if (current) parts.push(current.text);
  if (source) parts.push(source);
  return copy(parts.join("\n\n"));
}

function submitLinks(links) {
  fieldError("add-error");
  state.submitChain = state.submitChain.then(async () => {
    for (const url of links) {
      try {
        const result = await api("/api/articles", {method: "POST", body: {url}});
        await updateList();
        if (!result.added) openArticle(result.id, false);
        if (!result.added) toast("这条链接已在素材中");
      } catch (error) {
        fieldError("add-error", error.message);
      }
    }
  });
}

function clearSelection() {
  state.selection = [];
  $("selection-menu").hidden = true;
}

function selectionCell(node) {
  return (node?.nodeType === Node.ELEMENT_NODE ? node : node?.parentElement)?.closest("[data-text]");
}

function readSelection() {
  if (document.querySelector("dialog[open]")) return clearSelection();
  const selection = window.getSelection();
  if (!selection?.rangeCount || selection.isCollapsed) return clearSelection();
  const initial = selectionCell(selection.anchorNode);
  const terminal = selectionCell(selection.focusNode);
  if (!initial || !terminal || initial.dataset.text !== terminal.dataset.text) return clearSelection();
  const desired = initial.dataset.text;
  const range = selection.getRangeAt(0);
  const segments = [];
  for (const cell of $("materials").querySelectorAll("[data-text=" + desired + "]")) {
    if (!range.intersectsNode(cell) || cell.closest("[hidden]") ||
        (desired === "right" && !cell.dataset.translationId)) continue;
    const own = new Range();
    own.selectNodeContents(cell);
    const clipped = range.cloneRange();
    if (range.compareBoundaryPoints(Range.START_TO_START, own) < 0)
      clipped.setStart(own.startContainer, own.startOffset);
    if (range.compareBoundaryPoints(Range.END_TO_END, own) > 0)
      clipped.setEnd(own.endContainer, own.endOffset);
    const selected = clipped.toString();
    if (!selected.trim()) continue;
    const prefix = own.cloneRange();
    prefix.setEnd(clipped.startContainer, clipped.startOffset);
    const start = Array.from(prefix.toString()).length;
    segments.push({blockId: Number(cell.closest("[data-block]").dataset.block),
      translation_id: Number(cell.dataset.translationId) || null, start,
      end: start + Array.from(selected).length, selected});
  }
  if (!segments.length) return clearSelection();
  showSelection(segments, range.getBoundingClientRect());
}

function showSelection(segments, bounds) {
  state.selection = segments;
  $("selection-remove").hidden = !segments.some(s => overlaps(s).length);
  const menu = $("selection-menu");
  menu.hidden = false;
  menu.style.top = Math.max(6, bounds.top > 80 ? bounds.top - 42 : bounds.bottom + 7) + "px";
  menu.style.left = Math.min(innerWidth - menu.offsetWidth - 6, Math.max(6, bounds.left)) + "px";
}

function overlaps(segment) {
  const block = state.rows.get(segment.blockId)?.block;
  return block ? sideMarks(block, segment.translation_id)
    .filter(m => m.start < segment.end && segment.start < m.end) : [];
}

async function editMarks(remove) {
  const segments = [...state.selection];
  const ids = [...new Set(segments.flatMap(overlaps).map(mark => mark.id))];
  window.getSelection()?.removeAllRanges();
  clearSelection();
  try {
    if (remove) {
      for (const id of ids) applyBlock(await api("/api/highlights/" + id, {method: "DELETE"}));
    } else {
      for (const {blockId, ...mark} of segments)
        applyBlock(await api("/api/blocks/" + blockId + "/highlight", {method: "POST", body: mark}));
    }
    toast(remove ? "已取消高亮" : "已保存高亮");
  } catch (error) {
    toast(error.message);
  }
}

function renderPairs(pairs = local.pairs) {
  const pending = [...pairs].filter(([, record]) => record.state !== "available");
  const notice = $("language-packs");
  const signature = JSON.stringify(pending.map(([language, r]) => [language, r.state, r.progress, r.error]));
  if (notice.dataset.pairs === signature) return;
  notice.dataset.pairs = signature;
  notice.replaceChildren();
  notice.hidden = !pending.length;
  if (!pending.length) return;
  for (const [language, record] of pending) {
    const label = languageName(language);
    if (record.state === "downloading") notice.append(node("span", label + "语言包下载中…" + (record.progress || 0) + "%"));
    else if (record.state === "unavailable") {
      notice.append(node("span", "本地暂不支持" + label), button("重新检测", "secondary", () => local.recheck(language)));
    } else {
      notice.append(button((record.error ? "重试下载 · " : "启用本地翻译 · ") + label, "secondary",
        () => local.enable(language)));
    }
  }
}

async function retryLocal(id) {
  try {
    applyBlock(await api("/api/blocks/" + id + "/retry", {method: "POST"}));
    local.start();
  } catch (error) { toast(error.message); }
}

function openManual(material = null) {
  const form = $("manual-form");
  const view = material?.view;
  form.reset();
  form.dataset.article = view?.id || "";
  $("manual-title").textContent = view?.snapshot ? "补充正文" : "粘贴正文";
  $("manual-url-label").hidden = Boolean(view);
  form.elements.url.value = view?.original_url || "";
  form.elements.title.value = view?.snapshot?.title || "";
  form.elements.text.value = view?.blocks.map(block => block.text).join("\n\n") || "";
  fieldError("manual-error");
  $("manual-dialog").showModal();
  form.elements.text.focus();
}

async function withForm(event, errorId, action) {
  event.preventDefault();
  const form = event.currentTarget;
  const submit = form.querySelector("footer button:last-child");
  if (submit.disabled) return;
  submit.disabled = true;
  fieldError(errorId);
  try { await action(form); }
  catch (error) { fieldError(errorId, error.message); }
  finally { submit.disabled = false; }
}

async function openSettings() {
  const config = await api("/api/settings");
  const form = $("settings-form");
  form.reset();
  for (const key of ["local_provider", "local_model_url", "local_model_name", "llm_url", "llm_model", "terms"]) {
    form.elements[key].value = config[key];
  }
  form.elements.llm_structured.checked = config.llm_structured === "true";
  for (const engine of ["local_model", "llm"]) {
    $(engine + "-state").textContent = config[engine + "_ready"] ? "已配置" : "未配置";
  }
  updateLocalModelFields(form);
  fieldError("settings-error");
  $("settings-dialog").showModal();
}

function updateLocalModelFields(form) {
  form.elements.local_model_url.placeholder = localModelAddresses[form.elements.local_provider.value];
  $("local-model-list").replaceChildren();
  $("local-model-status").textContent = "";
}

async function testLocalModelConnection() {
  const form = $("settings-form");
  const values = form.elements;
  const localProvider = values.local_provider.value;
  const localAddress = values.local_model_url.value;
  const test = $("local-model-test");
  test.disabled = true;
  fieldError("settings-error");
  $("local-model-status").textContent = "连接中…";
  try {
    const result = await api("/api/local-models", {method: "POST", body: {
      local_provider: localProvider, local_model_url: localAddress,
      local_model_key: values.local_model_key.value, clear_local_model: values.clear_local_model.checked,
    }});
    if (values.local_provider.value !== localProvider || values.local_model_url.value !== localAddress ||
        !$("settings-dialog").open) return;
    $("local-model-list").replaceChildren(...result.models.map(model => {
      const option = node("option");
      option.value = model;
      return option;
    }));
    if (result.models.length === 1 && !values.local_model_name.value) {
      values.local_model_name.value = result.models[0];
    }
    $("local-model-status").textContent = result.models.length ?
      "连接成功，读取到 " + result.models.length + " 个模型。" :
      "服务已连接。请先下载或加载模型。";
  } catch (error) {
    $("local-model-status").textContent = "";
    fieldError("settings-error", error.message);
  } finally {
    test.disabled = false;
  }
}

function updateCloudHint(select) {
  const option = select.selectedOptions[0];
  const hint = $("cloud-hint");
  if (!option || option.disabled) {
    hint.textContent = "请先在翻译设置中配置本地模型或云端 API。";
    return;
  }
  hint.textContent = option.value === "local_model" ? "正文将提交给本机服务。" :
    "使用模型 " + option.dataset.model + "。调用会占用所选服务的额度。";
}

async function openCloud(material, blockId = null) {
  const snapshot = material.view?.snapshot;
  if (!snapshot) return;
  const config = await api("/api/settings");
  const form = $("cloud-form");
  form.reset();
  state.cloud = {material, snapshot: snapshot.id, blockId};
  const selected = form.elements.engine;
  for (const option of selected.options) {
    option.disabled = !config[option.value + "_ready"];
    const local = option.value === "local_model";
    const label = local ? "本地模型" : "云端 API";
    if (!local) option.dataset.model = config.llm_model;
    option.textContent = label + (option.disabled ? "（未配置）" : "");
  }
  const available = [...selected.options].find(item => !item.disabled);
  if (available) selected.value = available.value;
  form.querySelector("footer button:last-child").disabled = !available;
  $("cloud-title").textContent = blockId ? "重译 " + paragraphId(state.rows.get(blockId).block) : "模型翻译";
  $("cloud-mode").hidden = Boolean(blockId);
  updateCloudHint(selected);
  fieldError("cloud-error");
  $("cloud-dialog").showModal();
}

function openVersions(block) {
  const container = $("versions-list");
  $("versions-title").textContent = "译文版本 · " + paragraphId(block);
  container.replaceChildren();
  for (const version of block.translations) {
    const current = block.active_translation === version.id;
    const card = node("div", "", "version-card");
    const header = node("header");
    header.append(node("span", [engineName(version), fmt(version.created_at)].join(" · ")));
    if (current) header.append(node("span", "当前译文", "badge"));
    else header.append(button("使用此译文", "small secondary", async () => {
      try {
        applyBlock(await api("/api/blocks/" + block.id + "/active", {
          method: "POST", body: {translation_id: version.id},
        }));
        $("versions-dialog").close();
        toast("已切换译文版本");
      } catch (error) { toast(error.message); }
    }));
    const preview = node("p", "", "cell-text");
    markText(preview, version.text, sideMarks(block, version.id));
    card.append(header, preview);
    container.append(card);
  }
  if (!$("versions-dialog").open) $("versions-dialog").showModal();
}

function openLanguage(block) {
  const form = $("language-form");
  form.dataset.block = block.id;
  const selected = form.elements.language;
  const codes = [...new Set(["und", block.language, ...langs])];
  selected.replaceChildren(...codes.map(code => {
    const option = node("option", languageName(code));
    option.value = code;
    return option;
  }));
  selected.value = block.language;
  $("language-title").textContent = "更正语言 · " + paragraphId(block);
  fieldError("language-error");
  $("language-dialog").showModal();
}

function downloadName(response) {
  const value = response.headers.get("Content-Disposition")?.split("UTF-8''")[1];
  if (!value) return "素材对照.docx";
  try { return decodeURIComponent(value); } catch { return "素材对照.docx"; }
}

async function downloadWord(url) {
  const response = await fetch(url);
  if (!response.ok) throw new Error((await response.json().catch(() => ({}))).detail || "导出失败。");
  const objectUrl = URL.createObjectURL(await response.blob());
  const link = node("a");
  link.href = objectUrl;
  link.download = downloadName(response);
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(objectUrl), 5000);
  toast("已导出 Word");
}

function openExport(material) {
  fieldError("export-error");
  state.exportTarget = {id: material.id, snapshot: material.view.snapshot.id};
  $("export-form").elements.scope.value = material.parts["marked-only"].checked ? "marked" : "all";
  $("export-dialog").showModal();
}

function openDelete(material = null) {
  const form = $("delete-form");
  form.dataset.article = material?.id || "";
  $("delete-title").textContent = material ? "删除素材" : "清空素材";
  $("delete-submit").textContent = material ? "删除" : "清空全部";
  $("delete-message").textContent = material ?
    "将删除「" + material.parts["article-title"].textContent + "」的正文、译文和高亮。" :
    "将删除当前 " + state.articles.length + " 个素材及其正文、译文和高亮。";
  fieldError("delete-error");
  $("delete-dialog").showModal();
}

async function poll() {
  if (state.pollBusy) return;
  state.pollBusy = true;
  try {
    await updateList();
  } catch {
    // The next poll also handles the service returning after a restart.
  } finally {
    state.pollBusy = false;
  }
}

const local = new LocalTranslator({
  api,
  onBlock: applyBlock,
  onStatus: () => {
    renderPairs();
    for (const info of state.rows.values()) if (!getActive(info.block)) renderRow(info, info.block);
  },
  onWorking: (id, running) => {
    if (running) state.working.add(id);
    else state.working.delete(id);
    const info = state.rows.get(id);
    if (info) renderRow(info, info.block);
  },
  onToast: toast,
});

const browserLabel = local.browser ? local.browser + " " : "";
$("engine-status").replaceChildren(node("span"), document.createTextNode(
  browserLabel + (local.supported ? "本地翻译" : "本地翻译不可用")));
$("engine-status").classList.toggle("unavailable", !local.supported);

$("link-form").addEventListener("submit", event => {
  event.preventDefault();
  const input = $("link-input");
  if (input.value.trim()) submitLinks([input.value.trim()]);
  input.value = "";
  input.focus();
});
$("link-input").addEventListener("paste", event => {
  const urls = event.clipboardData.getData("text").trim().split(/\s+/);
  if (urls.length && urls.every(url => /^https?:\/\/\S+$/i.test(url))) {
    event.preventDefault();
    $("link-input").value = "";
    submitLinks(urls);
  }
});
$("source-search").addEventListener("input", displaySources);
$("sidebar-toggle").addEventListener("click", () => setSidebar(!$("sidebar").classList.contains("open")));
$("paste-manual").addEventListener("click", () => openManual());
$("empty-paste").addEventListener("click", () => openManual());
$("manual-form").addEventListener("submit", event => withForm(event, "manual-error", async form => {
  const values = Object.fromEntries(new FormData(form));
  const result = await api("/api/manual", {method: "POST", body: {
    ...values, article_id: Number(form.dataset.article) || null,
  }});
  $("manual-dialog").close();
  const material = state.materials.get(result.id);
  if (material) {
    material.pinned = null;
    material.summary = "";
  }
  await updateList();
  openArticle(result.id, true);
}));
$("settings-open").addEventListener("click", () => openSettings().catch(error => toast(error.message)));
$("settings-form").elements.local_provider.addEventListener("change", event => {
  const form = event.target.form;
  form.elements.local_model_url.value = "";
  form.elements.local_model_name.value = "";
  updateLocalModelFields(form);
});
$("settings-form").elements.local_model_url.addEventListener("input", event => updateLocalModelFields(event.target.form));
$("local-model-test").addEventListener("click", testLocalModelConnection);
$("settings-form").addEventListener("submit", event => withForm(event, "settings-error", async form => {
  const values = Object.fromEntries(new FormData(form));
  for (const key of ["llm_structured", "clear_local_model", "clear_llm"]) values[key] = form.elements[key].checked;
  await api("/api/settings", {method: "PUT", body: values});
  form.reset();
  $("settings-dialog").close();
  toast("已保存翻译设置");
}));
$("cloud-settings").addEventListener("click", () => {
  $("cloud-dialog").close();
  openSettings().catch(error => toast(error.message));
});
$("cloud-form").elements.engine.addEventListener("change", event => updateCloudHint(event.target));
$("cloud-form").addEventListener("submit", event => withForm(event, "cloud-error", async form => {
  await api("/api/snapshots/" + state.cloud.snapshot + "/cloud", {method: "POST", body: {
    engine: form.elements.engine.value, mode: state.cloud.blockId ? "candidate" : form.elements.mode.value,
    block_id: state.cloud.blockId, context: form.elements.context.checked,
  }});
  $("cloud-dialog").close();
  await refreshDetail(state.cloud.material);
}));
$("language-form").addEventListener("submit", event => withForm(event, "language-error", async form => {
  applyBlock(await api("/api/blocks/" + form.dataset.block + "/language", {
    method: "POST", body: {language: form.elements.language.value},
  }));
  $("language-dialog").close();
  local.start();
}));
$("export-form").addEventListener("submit", event => withForm(event, "export-error", async form => {
  const target = state.exportTarget;
  const url = "/api/articles/" + target.id + "/export?snapshot=" + target.snapshot +
    "&marked=" + (form.elements.scope.value === "marked") + "&tz=" + -new Date().getTimezoneOffset();
  await downloadWord(url);
  $("export-dialog").close();
}));
$("export-all").addEventListener("click", async event => {
  const submit = event.currentTarget;
  submit.disabled = true;
  try { await downloadWord("/api/export?tz=" + -new Date().getTimezoneOffset()); }
  catch (error) { toast(error.message); }
  finally { submit.disabled = false; }
});
$("clear-all").addEventListener("click", () => openDelete());
$("delete-form").addEventListener("submit", event => withForm(event, "delete-error", async form => {
  const id = form.dataset.article;
  await api("/api/articles" + (id ? "/" + id : ""), {method: "DELETE"});
  $("delete-dialog").close();
  await updateList();
  toast(id ? "已删除素材" : "已清空素材");
}));
for (const closer of document.querySelectorAll("[data-close]")) {
  closer.addEventListener("click", () => closer.closest("dialog").close());
}
document.addEventListener("selectionchange", readSelection);
document.addEventListener("scroll", clearSelection, {passive: true});
$("selection-menu").addEventListener("mousedown", event => event.preventDefault());
$("selection-highlight").addEventListener("click", () => editMarks(false));
$("selection-remove").addEventListener("click", () => editMarks(true));
$("selection-copy").addEventListener("click", () => copy(state.selection.map(s => s.selected).join("\n\n")));
$("materials").addEventListener("click", event => {
  const mark = event.target.closest("mark[data-mark-id]");
  if (!mark || !window.getSelection()?.isCollapsed) return;
  const info = state.rows.get(Number(mark.closest("[data-block]").dataset.block));
  const range = info?.block.highlights.find(item => item.id === Number(mark.dataset.markId));
  if (range) showSelection([{...range, blockId: info.block.id}], mark.getBoundingClientRect());
});

updateList().catch(error => toast(error.message));
setInterval(poll, 1550);
