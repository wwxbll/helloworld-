const targetLanguage = "zh-Hans";

function browserName() {
  const brands = navigator.userAgentData?.brands?.map(item => item.brand) || [];
  if (brands.includes("Microsoft Edge") || /\bEdg\//.test(navigator.userAgent)) return "Edge";
  if (brands.includes("Google Chrome") ||
      (!brands.length && /\bChrome\//.test(navigator.userAgent))) return "Chrome";
  return "";
}

function splitText(text, size = 3200) {
  const letters = Array.from(text);
  const parts = [];
  for (let start = 0; start < letters.length;) {
    let end = Math.min(start + size, letters.length);
    if (end < letters.length) {
      for (let i = end - 1; i > start + size / 2; i--) {
        if (/[。？！.!?\n]/u.test(letters[i])) {
          end = i + 1;
          break;
        }
      }
    }
    parts.push(letters.slice(start, end).join(""));
    start = end;
  }
  return parts;
}

export class LocalTranslator {
  constructor({api, onBlock, onStatus, onWorking, onToast}) {
    Object.assign(this, {api, onBlock, onStatus, onWorking, onToast});
    this.pairs = new Map();
    this.browser = browserName();
    this.supported = "Translator" in window;
    this.timer = null;
    this.working = false;
    this.start();
  }

  start(delay = 0) {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => this.run(), delay);
  }

  status(language) {
    return this.pairs.get(language)?.state || "";
  }

  options(language) {
    return {sourceLanguage: language, targetLanguage};
  }

  // Called directly by the button so the browser still sees user activation.
  enable(language) {
    const record = {state: "downloading", progress: 0};
    this.pairs.set(language, record);
    let promise;
    try {
      promise = window.Translator.create({
        ...this.options(language),
        monitor: monitor => monitor.addEventListener("downloadprogress", event => {
          record.progress = Math.floor(event.loaded * 100);
          this.onStatus(this.pairs);
        }),
      });
    } catch {
      record.state = "downloadable";
      this.onToast("语言包无法启动，请重试。");
      return;
    }
    this.onStatus(this.pairs);
    promise.then(translator => {
      record.translator = translator;
      record.state = "available";
      this.onStatus(this.pairs);
      this.start();
    }).catch(() => {
      record.state = "downloadable";
      record.error = true;
      this.onStatus(this.pairs);
      this.onToast("语言包下载失败，请检查浏览器设置或网络后重试。");
    });
  }

  recheck(language) {
    this.pairs.delete(language);
    this.onStatus(this.pairs);
    this.start();
  }

  async prepare(language) {
    if (this.pairs.has(language)) return this.pairs.get(language).translator;
    const options = this.options(language);
    let record = {state: "unavailable"};
    try {
      const availability = await window.Translator.availability(options);
      record = {state: availability === "downloading" ? "downloadable" : availability};
      if (availability === "available") record.translator = await window.Translator.create(options);
    } catch (error) {
      record = {state: error?.name === "NotAllowedError" ? "downloadable" : "unavailable"};
    }
    this.pairs.set(language, record);
    this.onStatus(this.pairs);
    return record.translator;
  }

  async translate(job, translator) {
    this.onWorking(job.id, true);
    let result;
    try {
      const pieces = [];
      for (const part of splitText(job.text)) {
        const piece = (await translator.translate(part)).trim();
        if (!piece) throw new Error("empty");
        pieces.push(piece);
      }
      result = {language: job.language, text: pieces.join("\n"), browser: this.browser};
    } catch (error) {
      result = {
        language: job.language,
        error: error?.name === "QuotaExceededError" ? "本机模型无法处理这段长度，可以更正语种或用云端重译。" :
          "本地翻译未完成，可重试或选用其他引擎。",
      };
    }
    try {
      this.onBlock(await this.api("/api/blocks/" + job.id + "/local", {method: "POST", body: result}));
    } finally {
      this.onWorking(job.id, false);
    }
  }

  async run() {
    if (this.working || !this.supported) return;
    this.working = true;
    let delay = 3200;
    try {
      const waiting = [...this.pairs].filter(([, pair]) => !pair.translator).map(([language]) => language);
      const jobs = await this.api("/api/local-work?exclude=" + waiting.join(","));
      const ready = [];
      for (const job of jobs) {
        const translator = await this.prepare(job.language);
        if (translator) ready.push([job, translator]);
        if (ready.length === 4) break;
      }
      for (let i = 0; i < ready.length; i += 2) {
        await Promise.allSettled(ready.slice(i, i + 2).map(([job, translator]) => this.translate(job, translator)));
      }
      if (ready.length) delay = 180;
    } catch {
      delay = 4500;
    } finally {
      this.working = false;
      this.start(delay);
    }
  }
}
