from datetime import datetime, timedelta, timezone
from io import BytesIO
from urllib.parse import urlsplit

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_COLOR_INDEX
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

from archive import ArchiveError


ENGINES = {"local": "浏览器本地", "deepl": "DeepL", "local_model": "本地模型", "llm": "云端大模型"}
ORIGINS = {"web": "网页提取", "manual": "用户提供正文", "supplement": "用户补充正文"}


def current_translation(block):
    return next((item for item in block["translations"] if item["id"] == block["active_translation"]), None)


def ranges_for(block, translation_id):
    return [(item["start"], item["end"]) for item in block["highlights"]
            if item["translation_id"] == translation_id]


def apply_text(paragraph, text, ranges, bold=False):
    points = sorted({0, len(text), *(offset for span in ranges for offset in span)})
    for start, end in zip(points, points[1:]):
        run = paragraph.add_run(text[start:end])
        run.bold = bold
        if any(a <= start < b for a, b in ranges):
            run.font.highlight_color = WD_COLOR_INDEX.YELLOW


def _add_property(parent, tag, val=None):
    element = OxmlElement(tag)
    if val is not None:
        element.set(qn("w:val"), val)
    parent.append(element)
    return element


def add_link(paragraph, url, label):
    from docx.opc.constants import RELATIONSHIP_TYPE

    if not url:
        return
    paragraph.add_run(label)
    link = OxmlElement("w:hyperlink")
    link.set(qn("r:id"), paragraph.part.relate_to(url, RELATIONSHIP_TYPE.HYPERLINK, is_external=True))
    run = OxmlElement("w:r")
    properties = _add_property(run, "w:rPr")
    _add_property(properties, "w:color", "1D5278")
    _add_property(properties, "w:u", "single")
    _add_property(run, "w:t").text = url
    link.append(run)
    paragraph._p.append(link)


def new_document(title):
    doc = Document()
    section = doc.sections[0]
    section.page_width = Cm(21)
    section.page_height = Cm(29.7)
    section.left_margin = section.right_margin = Cm(2)
    section.top_margin = section.bottom_margin = Cm(1.85)
    normal = doc.styles["Normal"]
    normal.font.name = "Aptos"
    normal.font.size = Pt(10.5)
    normal.element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    normal.paragraph_format.space_after = Pt(5)
    normal.paragraph_format.line_spacing = 1.22
    doc.core_properties.title = title
    return doc


def append_article(doc, article, timezone_minutes, only_highlights=False, new_page=False):
    snapshot = article["snapshot"]
    title = snapshot["title"] if snapshot else urlsplit(article["original_url"]).hostname or "待处理素材"
    heading = doc.add_heading(title, 0)
    if new_page:
        heading.paragraph_format.page_break_before = True
    zone = timezone(timedelta(minutes=timezone_minutes))
    if not snapshot:
        date = datetime.fromisoformat(article["created_at"]).astimezone(zone).isoformat(sep=" ", timespec="seconds")
        doc.add_paragraph(f"收录时间 {date}")
        if article["original_url"]:
            add_link(doc.add_paragraph(), article["original_url"], "原始链接  ")
        doc.add_paragraph(article["error"] or "正文待提取或补充。")
        return

    rows = []
    for block in article["blocks"]:
        active = current_translation(block)
        left = ranges_for(block, None)
        right = ranges_for(block, active["id"]) if active else []
        if not only_highlights or left or right:
            rows.append((block, active, left, right))
    if not rows:
        raise ArchiveError("当前正文版本没有可导出的高亮段落。")

    date = datetime.fromisoformat(snapshot["captured_at"]).astimezone(zone).isoformat(sep=" ", timespec="seconds")
    time_label = "抓取时间" if snapshot["kind"] == "web" else "提交时间"
    doc.add_paragraph(f"{time_label} {date}  ·  {ORIGINS[snapshot['kind']]}  ·  正文版本 #{snapshot['id']}")
    if article["original_url"]:
        add_link(doc.add_paragraph(), article["original_url"], "原始链接  ")
    if snapshot["final_url"] and snapshot["final_url"] != article["original_url"]:
        add_link(doc.add_paragraph(), snapshot["final_url"], "实际访问地址  ")
    details = [f"原文语言 {snapshot['language']}"]
    if snapshot["author"]:
        details.append(f"作者 {snapshot['author']}")
    if snapshot["published"]:
        details.append(f"发布日期 {snapshot['published']}")
    if snapshot["partial"]:
        details.append("正文可能不完整")
    if only_highlights:
        details.append("高亮摘录")
    doc.add_paragraph("  ·  ".join(details))

    table = doc.add_table(rows=1, cols=2)
    table.style = "Table Grid"
    table.autofit = False
    for column in table.columns:
        column.width = Cm(8.5)
    _add_property(table.rows[0]._tr.get_or_add_trPr(), "w:tblHeader")
    for cell, label in zip(table.rows[0].cells, ("原文", "简体中文")):
        cell.width = Cm(8.5)
        shading = _add_property(cell._tc.get_or_add_tcPr(), "w:shd")
        shading.set(qn("w:fill"), "E9F0F5")
        cell.paragraphs[0].add_run(label).bold = True

    for block, active, left, right in rows:
        row = table.add_row()
        right_text = (active["text"] if active else "原文为中文" if block["language"] == "zh" else
                      "代码按原文保留" if block["kind"] == "code" else "待翻译")
        if max(len(block["text"]), len(right_text)) < 1850 and max(
            block["text"].count("\n"), right_text.count("\n")
        ) < 26:
            _add_property(row._tr.get_or_add_trPr(), "w:cantSplit")
        original, translated = row.cells
        for cell in row.cells:
            cell.width = Cm(8.5)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.TOP
        label = original.paragraphs[0].add_run(f"P{block['position']:03}")
        label.font.size = Pt(8)
        label.font.color.rgb = RGBColor.from_string("475F71")
        apply_text(original.add_paragraph(), block["text"], left, bold=block["kind"] == "heading")
        if active:
            engine = ENGINES.get(active["engine"], active["engine"])
            if active["engine"] in {"local_model", "llm"} and active["model"]:
                engine += f" · {active['model']}"
            if active["engine"] == "local" and active["model"]:
                engine = f"{active['model']} 本地"
            provenance = translated.paragraphs[0].add_run(engine)
            provenance.font.size = Pt(8)
            provenance.font.color.rgb = RGBColor.from_string("475F71")
        else:
            translated.paragraphs[0].add_run("译文状态").font.size = Pt(8)
        apply_text(translated.add_paragraph(), right_text, right, bold=block["kind"] == "heading" and bool(active))


def export_word(article, only_highlights=False, timezone_minutes=480):
    if not article["snapshot"]:
        raise ArchiveError("请先提取或粘贴正文。")
    doc = new_document(article["snapshot"]["title"])
    append_article(doc, article, timezone_minutes, only_highlights)
    return document_data(doc)


def export_collection(articles, timezone_minutes=480):
    if not articles:
        raise ArchiveError("请先添加要导出的素材。")
    doc = new_document("素材对照 · 完整归档")
    for index, article in enumerate(articles):
        append_article(doc, article, timezone_minutes, new_page=index > 0)
    return document_data(doc)


def document_data(doc):
    output = BytesIO()
    doc.save(output)
    return output.getvalue()
