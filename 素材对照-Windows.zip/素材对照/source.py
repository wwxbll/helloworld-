import base64
import gzip
import http.client
import io
import ipaddress
import re
import socket
import ssl
import sys
import time
from collections import Counter
from functools import lru_cache
from urllib.parse import quote, unquote, urljoin, urlsplit, urlunsplit
from urllib import request as urllib_request

import certifi
from lingua import Language, LanguageDetectorBuilder
from lxml import html
from trafilatura import bare_extraction


MAX_PAGE = 5 * 1024 * 1024
MAX_TEXT = 350_000
AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/146.0.0.0 Safari/537.36"
HEADINGS = {"head", "h1", "h2", "h3", "h4", "h5", "h6"}
BLOCK_TAGS = HEADINGS | {"p", "li", "item", "quote", "blockquote", "pre", "code", "row"}
RESTRICTED = re.compile(
    r"sign in to (?:read|continue)|log in to (?:read|continue)|"
    r"subscribe to (?:read|continue)|unlock (?:this|the full) article|"
    r"enable javascript and cookies to continue|checking your browser|"
    r"请登录后(?:阅读|继续|查看)|登录后(?:阅读|查看)全文|订阅后(?:阅读|查看)",
    re.IGNORECASE,
)
TLS = ssl.create_default_context(cafile=certifi.where())


class SourceError(Exception):
    def __init__(self, message, transient=False):
        super().__init__(message)
        self.transient = transient


def clean_text(value):
    return re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\ud800-\udfff\ufffe\uffff]", "", value)


def normalize_url(raw):
    raw = raw.strip()
    if not raw or len(raw) > 4000 or any(ord(ch) < 32 for ch in raw) or "\\" in raw:
        raise SourceError("链接格式无效。")
    try:
        p = urlsplit(raw)
        port = p.port
        host = p.hostname
        if p.scheme not in {"http", "https"} or not host or p.username is not None or p.password is not None:
            raise ValueError
        if port is not None and port != (443 if p.scheme == "https" else 80):
            raise ValueError
        host = host.rstrip(".").encode("idna").decode("ascii")
        if ":" in host:
            host = f"[{host}]"
        return urlunsplit((p.scheme, host, quote(p.path or "/", safe="/%:@!$&'()*+,;=-._~"),
                           quote(p.query, safe="/%?:@!$&'()*+,;=-._~"), ""))
    except (UnicodeError, ValueError) as exc:
        raise SourceError("请输入有效的公开 HTTP(S) 网页链接。") from exc


def public_addresses(host, port):
    try:
        addresses = list(dict.fromkeys(item[4][0] for item in socket.getaddrinfo(
            host, port, type=socket.SOCK_STREAM
        )))
    except OSError as exc:
        raise SourceError("无法解析网站地址。", transient=True) from exc
    for address in addresses:
        ip = ipaddress.ip_address(address)
        if isinstance(ip, ipaddress.IPv6Address) and ip.ipv4_mapped:
            ip = ip.ipv4_mapped
        if not ip.is_global or ip.is_multicast or ip.is_reserved:
            raise SourceError("此功能仅抓取公开网络地址。")
    if not addresses:
        raise SourceError("网站没有可用的公开地址。")
    # When both families are available, try one of each before trying further addresses.
    alternate = next((address for address in addresses if (":" in address) != (":" in addresses[0])), None)
    if alternate:
        addresses.remove(alternate)
        addresses.insert(1, alternate)
    return addresses[:4]


REDIRECTS = {301, 302, 303, 307, 308}
READ_METHODS = {"GET", "HEAD"}


def time_left(deadline):
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise TimeoutError("Request deadline exceeded")
    return remaining


def system_proxy(parts):
    raw = urllib_request.getproxies().get(parts.scheme)
    if urllib_request.proxy_bypass(parts.hostname):
        return None
    if not raw and sys.platform == "win32":
        # NO_PROXY alone may mask the Windows settings in getproxies().
        if urllib_request.proxy_bypass_registry(parts.hostname):
            return None
        raw = urllib_request.getproxies_registry().get(parts.scheme)
    if not raw:
        return None
    try:
        proxy = urlsplit(raw if "://" in raw else "http://" + raw)
        if proxy.scheme != "http" or not proxy.hostname:
            raise ValueError
        return proxy, proxy.port or 80
    except ValueError as exc:
        raise SourceError("网页抓取需要支持 HTTP CONNECT 的代理，请检查系统代理设置。") from exc


def connection_to(parts, port, address, timeout, proxy_config):
    if proxy_config:
        proxy, proxy_port = proxy_config
        connection = http.client.HTTPConnection(proxy.hostname, proxy_port, timeout=timeout)
        tunnel_headers = {}
        if proxy.username is not None:
            credentials = f"{unquote(proxy.username)}:{unquote(proxy.password or '')}"
            encoded = base64.b64encode(credentials.encode("utf-8")).decode("ascii")
            tunnel_headers["Proxy-Authorization"] = f"Basic {encoded}"
        # The proxy receives the address that has already passed the public-address check.
        tunnel_host = f"[{address}]" if ":" in address else address
        connection.set_tunnel(tunnel_host, port, headers=tunnel_headers)
        return connection

    # Connect to the validated address, retaining the origin for HTTP Host and TLS SNI.
    connection = (http.client.HTTPSConnection(parts.hostname, port, timeout=timeout, context=TLS)
                  if parts.scheme == "https" else
                  http.client.HTTPConnection(parts.hostname, port, timeout=timeout))
    connection._create_connection = (
        lambda _, timeout, source_address: socket.create_connection((address, port), timeout, source_address)
    )
    return connection


def request_address(parts, port, address, method, headers, payload, limit, deadline, proxy_config):
    timeout = time_left(deadline)
    if method in READ_METHODS:
        timeout = min(3, timeout)
    connection = connection_to(parts, port, address, timeout, proxy_config)
    target = parts.path + (f"?{parts.query}" if parts.query else "")
    try:
        connection.connect()
        if proxy_config:
            headers = {**headers, "Host": parts.netloc}
            if parts.scheme == "https":
                connection.sock.settimeout(time_left(deadline))
                connection.sock = TLS.wrap_socket(connection.sock, server_hostname=parts.hostname)
        transport = connection.sock
        transport.settimeout(time_left(deadline))
        connection.request(method, target, body=payload, headers=headers)
        with connection.getresponse() as response:
            out_headers = {name.lower(): val for name, val in response.getheaders()}
            status = response.status
            encoding = out_headers.pop("content-encoding", "").lower()
            for name in ("content-length", "transfer-encoding", "connection", "set-cookie"):
                out_headers.pop(name, None)
            # The callers handle errors and redirects using status and headers.
            if method == "HEAD" or status in REDIRECTS or status >= 400:
                return status, out_headers, b""
            declared = response.length
            if declared is not None and declared > limit:
                raise SourceError("页面或接口响应超过大小上限。")
            chunks = []
            received = 0
            while True:
                transport.settimeout(time_left(deadline))
                chunk = response.read1(min(65_536, limit + 1 - received))
                if not chunk:
                    break
                chunks.append(chunk)
                received += len(chunk)
                if received > limit:
                    raise SourceError("页面或接口响应超过大小上限。")
            if response.length:
                raise http.client.IncompleteRead(b"", response.length)
            data = b"".join(chunks)
            if data and encoding in {"gzip", "x-gzip"}:
                with gzip.GzipFile(fileobj=io.BytesIO(data)) as stream:
                    data = stream.read(limit + 1)
                if len(data) > limit:
                    raise SourceError("解压内容超过大小上限。")
            elif data and encoding not in {"", "identity"}:
                raise SourceError("网站返回了无法识别的内容编码。")
            return status, out_headers, data
    finally:
        connection.close()


def request_url(url, *, method="GET", headers=None, payload=None, limit=MAX_PAGE, redirects=5, timeout=10):
    """Resolve each redirect once and retry interrupted reads on another validated address."""
    url = normalize_url(url)
    deadline = time.monotonic() + timeout
    request_headers = {"User-Agent": AGENT, "Accept-Encoding": "gzip" if method in READ_METHODS else "identity",
                       **(headers or {})}
    for _ in range(6):
        parts = urlsplit(url)
        port = 443 if parts.scheme == "https" else 80
        addresses = public_addresses(parts.hostname, port)
        proxy_config = system_proxy(parts) if parts.scheme == "https" and method in READ_METHODS else None
        error_message = ("系统代理连接失败或读取响应超时。" if proxy_config else "网络连接失败或读取响应超时。")
        failure = None
        for index, address in enumerate(addresses):
            attempt_deadline = deadline
            if method in READ_METHODS and index + 1 < len(addresses):
                attempt_deadline = min(deadline, time.monotonic() + 5)
            try:
                status, out_headers, data = request_address(
                    parts, port, address, method, request_headers, payload, limit, attempt_deadline, proxy_config
                )
                break
            except (OSError, http.client.HTTPException, EOFError) as exc:
                failure = exc
                # A POST may already have reached the provider.
                if method not in READ_METHODS or time.monotonic() >= deadline:
                    raise SourceError(error_message, transient=True) from exc
        else:
            raise SourceError(error_message, transient=True) from failure
        if status in REDIRECTS and out_headers.get("location"):
            if redirects <= 0 or method not in READ_METHODS:
                raise SourceError("链接跳转次数过多，或接口返回了重定向。")
            url = normalize_url(urljoin(url, out_headers["location"]))
            redirects -= 1
            continue
        return status, out_headers, data, url
    raise SourceError("链接跳转次数过多。")


@lru_cache(maxsize=1)
def detector():
    return LanguageDetectorBuilder.from_all_languages().with_low_accuracy_mode().build()


def identify(text):
    if sum(ch.isalpha() for ch in text) < 8:
        return ""
    values = detector().compute_language_confidence_values(text[:2400])
    if not values or values[0].value < 0.40:
        return ""
    if len(values) > 1 and values[0].value - values[1].value < 0.12:
        return ""
    if values[0].language == Language.CHINESE:
        return "zh"
    return values[0].language.iso_code_639_1.name.lower()


def language_blocks(blocks, hint=""):
    sample = " ".join(block["text"][:500] for block in blocks[:18])
    main = identify(sample) or hint.split("-")[0].lower()
    tally = Counter()
    for block in blocks:
        lang = identify(block["text"])
        block["language"] = lang or main or "und"
        if lang:
            tally[lang] += len(block["text"])
    return tally.most_common(1)[0][0] if tally else (main or "und")


def node_text(node):
    if node.tag == "pre" or node.tag == "code":
        return clean_text("".join(node.itertext())).strip()
    if node.tag == "row":
        return clean_text("  |  ".join(" ".join(cell.text_content().split())
                                       for cell in node if hasattr(cell, "text_content"))).strip()
    return clean_text(" ".join("".join(node.itertext()).split())).strip()


def extract_blocks(node):
    blocks = []
    for child in node:
        tag = child.tag
        if tag in BLOCK_TAGS:
            if tag in {"li", "item"} and any(n.tag in {"list", "ul", "ol", "p"} for n in child):
                intro = " ".join(
                    [child.text or ""] + [
                        "".join(n.itertext()) if n.tag not in {"list", "ul", "ol", "p"} else ""
                        for n in child
                    ]
                )
                if intro.strip():
                    blocks.append({"kind": "list", "text": clean_text(intro).strip()})
                nested = extract_blocks(child)
                for block in nested:
                    if block["kind"] == "paragraph":
                        block["kind"] = "list"
                blocks.extend(nested)
                continue
            if tag == "row":
                text = "  |  ".join(" ".join("".join(cell.itertext()).split()) for cell in child)
            else:
                text = node_text(child)
            if text:
                kind = ("heading" if tag in HEADINGS else "list" if tag in {"li", "item"}
                        else "quote" if tag in {"quote", "blockquote"} else
                        "code" if tag in {"pre", "code"} else "paragraph")
                blocks.append({"kind": kind, "text": text})
        elif isinstance(tag, str):
            blocks.extend(extract_blocks(child))
    return blocks


def select_metadata(tree, name):
    return (tree.xpath(f'//meta[@property="{name}"]/@content | //meta[@name="{name}"]/@content') or [""])[0]


def parse_article(raw, url, content_type=""):
    if isinstance(raw, bytes):
        charset = re.search(r"charset\s*=\s*['\"]?([\w.-]+)", content_type, re.I)
        if charset:
            try:
                raw = raw.decode(charset[1], errors="replace")
            except LookupError:
                pass
    try:
        tree = html.fromstring(raw)
    except (ValueError, TypeError):
        tree = html.fromstring(b"<html></html>")
    original_title = clean_text(" ".join(tree.xpath("//title/text()")).strip())
    hint = (tree.xpath("//html/@lang") or [""])[0]
    extracted = bare_extraction(tree, url=url, include_comments=False, include_formatting=True,
                                include_tables=True, with_metadata=True)
    blocks = extract_blocks(extracted.body) if extracted and extracted.body is not None else []
    if not blocks:
        candidates = tree.xpath("//article | //main | //*[@role='main']")
        if candidates:
            for bad in candidates[0].xpath(".//nav | .//aside | .//footer | .//script | .//style | .//form"):
                bad.drop_tree()
            blocks = extract_blocks(candidates[0])
    title = clean_text((extracted.title if extracted else "") or original_title or urlsplit(url).netloc)
    page_text = " ".join(tree.xpath(
        "//body//text()[not(ancestor::script or ancestor::style or ancestor::template)]"
    ))[:80_000]
    restricted = bool(RESTRICTED.search(page_text) or re.search(
        r"^(?:just a moment|access denied|sign in|log in|captcha|请登录)[.!…\s|:–-]",
        original_title + " ", re.I
    ))
    if restricted:
        blocks = [block for block in blocks if not RESTRICTED.search(block["text"])]
    blocks = [block for block in blocks if block["text"] != title or block["kind"] != "heading"]
    if not blocks:
        return None, restricted
    limited = []
    total = 0
    for block in blocks[:2500]:
        remaining = MAX_TEXT - total
        if remaining <= 0:
            break
        block["text"] = block["text"][:remaining]
        total += len(block["text"])
        limited.append(block)
    readable = sum(sum(ch.isalpha() for ch in block["text"]) for block in limited if block["kind"] != "heading")
    if readable < 12:
        return None, restricted
    article = {
        "title": title[:400], "author": clean_text((extracted.author if extracted else "") or "")[:300],
        "published": clean_text(select_metadata(tree, "article:published_time")
                                or select_metadata(tree, "datePublished")
                                or ((extracted.date if extracted else "") or ""))[:80],
        "blocks": limited, "final_url": url, "language_hint": hint,
        "partial": restricted or len(limited) < len(blocks) or total >= MAX_TEXT or readable < 100,
    }
    return article, restricted


def render_html(url):
    from playwright.sync_api import Error, sync_playwright

    start = time.monotonic()
    count = 0
    transferred = 0

    def respond(route):
        nonlocal count, transferred
        request = route.request
        count += 1
        if (count > 60 or transferred > 18 * 1024 * 1024
                or time.monotonic() - start > 20 or request.method not in {"GET", "HEAD"}
                or request.resource_type in {"image", "font", "media", "eventsource"}):
            route.abort()
            return
        try:
            status, headers, body, _ = request_url(
                request.url, method=request.method, timeout=4,
                headers={k: v for k, v in request.headers.items()
                         if k in {"accept", "accept-language", "origin", "referer"}},
            )
            transferred += len(body)
            route.fulfill(status=status, headers=headers, body=body)
        except (SourceError, Error):
            try:
                route.abort()
            except Error:
                pass

    try:
        with sync_playwright() as playwright:
            # The dead proxy closes direct browser egress. HTTP resources are served through respond().
            options = {"headless": True, "proxy": {"server": "http://127.0.0.1:1", "bypass": "<-loopback>"},
                       "args": ["--disable-background-networking", "--disable-quic"]}
            for channel in ("msedge", "chrome", None):
                try:
                    browser = playwright.chromium.launch(channel=channel, timeout=7000, **options)
                    break
                except Error:
                    if channel is None:
                        return None
            try:
                context = browser.new_context(service_workers="block", accept_downloads=False)
                context.route("**/*", respond)
                context.route_web_socket("**/*", lambda ws: ws.close())
                page = context.new_page()
                page.goto(url, wait_until="domcontentloaded", timeout=14_000)
                for _ in range(15):
                    try:
                        if page.evaluate(
                            """() => (document.querySelector('article, main, [role=main]')
                                       || document.body)?.innerText.length >= 220"""
                        ):
                            break
                    except Error:
                        break
                    page.wait_for_timeout(220)
                return page.content()[:MAX_PAGE], normalize_url(page.url)
            finally:
                browser.close()
    except (Error, SourceError, OSError):
        return None


def fetch_article(url):
    status, headers, body, final = request_url(url)
    if status in {401, 403, 407, 451}:
        raise SourceError(f"网站限制访问（HTTP {status}）。可以粘贴你能看到的正文。")
    if status >= 400:
        raise SourceError(f"网站返回 HTTP {status}。", transient=status in {408, 429, 500, 502, 503, 504})
    content_type = headers.get("content-type", "").lower()
    if content_type and "html" not in content_type and "xhtml" not in content_type:
        raise SourceError("链接返回的内容不是 HTML 网页。可以复制正文后在工具里粘贴。")
    article, restricted = parse_article(body, final, content_type)
    if not restricted and (article is None or article["partial"]):
        rendered = render_html(final)
        if rendered:
            dynamic, _ = parse_article(rendered[0], rendered[1])
            if dynamic and (article is None or
                            sum(len(b["text"]) for b in dynamic["blocks"]) >
                            sum(len(b["text"]) for b in article["blocks"])):
                article = dynamic
    if article is None:
        raise SourceError("网页需要登录、订阅或验证。" if restricted else
                          "这次未提取到可用正文。可以粘贴正文或稍后重试。")
    article["language"] = language_blocks(article["blocks"], article.pop("language_hint", ""))
    return article


def manual_article(title, text):
    text = clean_text(text).replace("\r\n", "\n").replace("\r", "\n").strip()
    split = re.split(r"\n[ \t]*\n+", text)
    if len(split) == 1:
        split = text.splitlines()
    blocks = [{"kind": "paragraph", "text": part.strip()} for part in split if part.strip()]
    if not blocks or len(blocks) > 2500 or len(text) > MAX_TEXT:
        raise SourceError("请输入正文，每次最多 2500 段、35 万字符。")
    return {"title": clean_text(title).strip() or "手动粘贴的正文", "author": "", "published": "",
            "final_url": "", "blocks": blocks, "language": language_blocks(blocks), "partial": False}
