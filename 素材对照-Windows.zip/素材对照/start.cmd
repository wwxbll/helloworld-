@echo off
setlocal
cd /d "%~dp0"
set "ARCHIVE_PYTHON="
if exist ".venv\Scripts\python.exe" goto venv
if exist ".deps\fastapi\__init__.py" if exist ".deps\python-path.txt" set /p "ARCHIVE_PYTHON="<".deps\python-path.txt"
if defined ARCHIVE_PYTHON if exist "%ARCHIVE_PYTHON%" goto run

where py.exe >nul 2>&1
if errorlevel 1 goto use_python
py -3 -m venv .venv
if errorlevel 1 goto missing_python
goto venv

:use_python
python -m venv .venv
if errorlevel 1 goto missing_python

:venv
set "ARCHIVE_PYTHON=%CD%\.venv\Scripts\python.exe"
"%ARCHIVE_PYTHON%" -c "import fastapi, uvicorn, trafilatura, lingua, playwright, docx, keyring" >nul 2>&1
if not errorlevel 1 goto run
"%ARCHIVE_PYTHON%" -m pip install -r requirements.txt
if errorlevel 1 goto failed

:run
"%ARCHIVE_PYTHON%" app.py --open %*
if errorlevel 1 goto failed
exit /b 0

:missing_python
echo Install Python 3.11 or later, then run start.cmd again.
:failed
pause
exit /b 1
