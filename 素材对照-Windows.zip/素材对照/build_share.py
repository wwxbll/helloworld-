from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile


PROJECT = Path(__file__).resolve().parent
PACKAGE_FILES = (
    "README.md", "requirements.txt", "start.cmd", "start-edge.cmd", "start-chrome.cmd", "package.cmd",
    "build_share.py", "app.py", "archive.py", "cloud.py", "source.py", "word_export.py",
    "static/index.html", "static/styles.css", "static/app.js", "static/local-translation.js",
)


def build_package():
    destination = PROJECT / "release" / "素材对照-Windows.zip"
    destination.parent.mkdir(exist_ok=True)
    with TemporaryDirectory(dir=destination.parent) as temp:
        staging = Path(temp) / destination.name
        with ZipFile(staging, "w", compression=ZIP_DEFLATED, compresslevel=6) as package:
            for name in PACKAGE_FILES:
                package.write(PROJECT / name, arcname=f"素材对照/{name}")
        staging.replace(destination)
    return destination


if __name__ == "__main__":
    print(build_package())
