import argparse
import hashlib
import http.client
import json
import logging
import os
import re
import subprocess
import sys
import time
import webbrowser
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from pathlib import Path
from threading import Thread
from typing import Literal
from urllib.parse import quote

APP_DIR = Path(__file__).resolve().parent
if sys.prefix == sys.base_prefix and (APP_DIR / ".deps").is_dir():
    sys.path.insert(0, str(APP_DIR / ".deps"))

import uvicorn
from fastapi import FastAPI, Query, Request
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from starlette.middleware.trustedhost import TrustedHostMiddleware

from archive import Archive, ArchiveError
from cloud import ENGINES, api_key, list_local_models, public_settings, save_settings, translate_job
from source import SourceError, clean_text, fetch_article, manual_article, normalize_url
from word_export import export_collection, export_word


LOG = logging.getLogger("web_bilingual_archive")
ARCHIVE = Archive(Path(os.environ.get("WEB_ARCHIVE_DATA", APP_DIR / "data")) / "archive.sqlite3")
INSTANCE = hashlib.sha256(os.path.normcase(str(ARCHIVE.path.resolve())).encode("utf-8")).hexdigest()


def harvest(article_id):
    url = ARCHIVE.claim_fetch(article_id)
    if not url:
        return
    try:
        for attempt in range(2):
            try:
                source = fetch_article(url)
                ARCHIVE.save_snapshot(article_id, source, "web")
                return
            except SourceError as exc:
                if attempt == 0 and exc.transient:
                    time.sleep(0.7)
                    continue
                ARCHIVE.fail_fetch(article_id, str(exc))
    except ArchiveError as exc:
        if exc.status != 404:
            LOG.exception("抓取任务未能保存 article_id=%s", article_id)
            ARCHIVE.fail_fetch(article_id, str(exc))
    except Exception:
        LOG.exception("抓取任务失败 article_id=%s", article_id)
        ARCHIVE.fail_fetch(article_id, "正文处理遇到错误。可以重试或手动粘贴正文。")


@asynccontextmanager
async def lifespan(app):
    with ThreadPoolExecutor(max_workers=2, thread_name_prefix="fetch-article") as fetch, \
         ThreadPoolExecutor(max_workers=2, thread_name_prefix="translate-cloud") as cloud:
        app.state.fetch = fetch
        app.state.cloud = cloud
        waiting_fetch, waiting_cloud = ARCHIVE.recover()
        for article_id in waiting_fetch:
            fetch.submit(harvest, article_id)
        for job_id in waiting_cloud:
            cloud.submit(translate_job, ARCHIVE, job_id)
        yield


app = FastAPI(title="素材对照", docs_url=None, redoc_url=None, openapi_url=None, lifespan=lifespan)
app.add_middleware(TrustedHostMiddleware, allowed_hosts=["127.0.0.1", "localhost", "testserver"])
app.mount("/static", StaticFiles(directory=APP_DIR / "static"), name="static")


@app.middleware("http")
async def protect_local_app(request: Request, call_next):
    if request.method not in {"GET", "HEAD", "OPTIONS"}:
        origin = request.headers.get("origin")
        if request.headers.get("x-archive-request") != "1" or (
            origin and origin != f"{request.url.scheme}://{request.headers.get('host')}"
        ):
            return JSONResponse({"detail": "此操作只能从本工具的页面发起。"}, status_code=403)
    response = await call_next(request)
    response.headers["Cache-Control"] = "no-store"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; "
        "style-src 'self' 'unsafe-inline'; form-action 'self'"
    )
    return response


@app.exception_handler(ArchiveError)
async def archive_error(request, exc):
    return JSONResponse({"detail": str(exc)}, status_code=exc.status)


@app.exception_handler(SourceError)
async def source_error(request, exc):
    return JSONResponse({"detail": str(exc)}, status_code=400)


class NewLink(BaseModel):
    url: str = Field(min_length=1, max_length=4000)


class MoveArticle(BaseModel):
    direction: Literal["up", "down"]


class ManualText(BaseModel):
    article_id: int | None = None
    url: str = Field(default="", max_length=4000)
    title: str = Field(default="", max_length=400)
    text: str = Field(min_length=1, max_length=350_000)


class LocalResult(BaseModel):
    language: str = Field(pattern=r"^[a-z]{2,3}$")
    text: str = Field(default="", max_length=500_000)
    error: str = Field(default="", max_length=240)
    browser: Literal["", "Edge", "Chrome"] = ""


class LanguageChoice(BaseModel):
    language: str = Field(pattern=r"^[a-z]{2,3}$")


class ActiveTranslation(BaseModel):
    translation_id: int


class Highlight(BaseModel):
    translation_id: int | None = None
    start: int = Field(ge=0)
    end: int = Field(ge=1)
    selected: str = Field(min_length=1, max_length=350_000)


class LocalModelConnection(BaseModel):
    local_provider: Literal["Ollama", "llama.cpp"] = "Ollama"
    local_model_url: str = Field(default="", max_length=1000)
    local_model_key: str = Field(default="", max_length=2000)
    clear_local_model: bool = False


class SettingsInput(LocalModelConnection):
    local_model_name: str = Field(default="", max_length=500)
    llm_url: str = Field(default="", max_length=1000)
    llm_model: str = Field(default="", max_length=200)
    llm_structured: bool = False
    terms: str = Field(default="", max_length=3000)
    llm_key: str = Field(default="", max_length=2000)
    clear_llm: bool = False


class CloudJob(BaseModel):
    engine: Literal["local_model", "llm"]
    mode: Literal["missing", "all", "candidate"]
    block_id: int | None = None
    context: bool = True


@app.get("/")
def index():
    return FileResponse(APP_DIR / "static" / "index.html")


@app.get("/api/health")
def health():
    return {"app": "material-comparison", "instance": INSTANCE}


@app.get("/api/articles")
def list_articles():
    return ARCHIVE.list_articles()


@app.post("/api/articles")
def add_article(payload: NewLink):
    url = normalize_url(payload.url)
    article_id, added = ARCHIVE.register(payload.url.strip(), url)
    if added:
        app.state.fetch.submit(harvest, article_id)
    return {"id": article_id, "added": added}


@app.get("/api/articles/{article_id}")
def article_detail(article_id: int, snapshot: int | None = None):
    return ARCHIVE.article(article_id, snapshot)


@app.delete("/api/articles/{article_id}")
def delete_article(article_id: int):
    return {"deleted": ARCHIVE.delete_articles(article_id)}


@app.delete("/api/articles")
def clear_articles():
    return {"deleted": ARCHIVE.delete_articles()}


@app.post("/api/articles/{article_id}/move")
def move_article(article_id: int, payload: MoveArticle):
    return {"moved": ARCHIVE.move_article(article_id, payload.direction)}


@app.post("/api/articles/{article_id}/refresh")
def refresh(article_id: int):
    if ARCHIVE.queue_fetch(article_id):
        app.state.fetch.submit(harvest, article_id)
    return {"id": article_id}


@app.post("/api/manual")
def save_manual(payload: ManualText):
    source = manual_article(payload.title, payload.text)
    kind = "manual"
    if payload.article_id is not None:
        previous = ARCHIVE.article(payload.article_id)
        article_id = previous["id"]
        if previous["snapshot"]:
            kind = "supplement"
            for name in ("final_url", "author", "published"):
                source[name] = previous["snapshot"][name]
    else:
        normalized = normalize_url(payload.url) if payload.url.strip() else None
        article_id, _ = ARCHIVE.register(payload.url.strip(), normalized, manual=True)
    snapshot = ARCHIVE.save_snapshot(article_id, source, kind)
    return {"id": article_id, "snapshot": snapshot}


@app.get("/api/local-work")
def local_work(exclude: str = ""):
    excluded = [item for item in exclude.split(",")[:80] if re.fullmatch(r"[a-z]{2,3}", item)]
    return ARCHIVE.local_work(excluded)


@app.post("/api/blocks/{block_id}/local")
def local_result(block_id: int, payload: LocalResult):
    text = clean_text(payload.text).strip()
    if not text and not payload.error:
        raise ArchiveError("未收到可保存的译文。")
    ARCHIVE.save_local(block_id, payload.language, text, clean_text(payload.error), payload.browser)
    return ARCHIVE.block(block_id)


@app.post("/api/blocks/{block_id}/retry")
def local_retry(block_id: int):
    ARCHIVE.retry_local(block_id)
    return ARCHIVE.block(block_id)


@app.post("/api/blocks/{block_id}/language")
def change_language(block_id: int, payload: LanguageChoice):
    ARCHIVE.set_language(block_id, payload.language)
    return ARCHIVE.block(block_id)


@app.post("/api/blocks/{block_id}/active")
def activate_translation(block_id: int, payload: ActiveTranslation):
    ARCHIVE.activate(block_id, payload.translation_id)
    return ARCHIVE.block(block_id)


@app.post("/api/blocks/{block_id}/highlight")
def add_highlight(block_id: int, payload: Highlight):
    ARCHIVE.highlight(block_id, payload.translation_id, payload.start, payload.end, payload.selected)
    return ARCHIVE.block(block_id)


@app.delete("/api/highlights/{highlight_id}")
def remove_highlight(highlight_id: int):
    return ARCHIVE.block(ARCHIVE.remove_highlight(highlight_id))


@app.get("/api/settings")
def get_settings():
    return public_settings(ARCHIVE)


@app.put("/api/settings")
def update_settings(payload: SettingsInput):
    values = payload.model_dump()
    values["llm_structured"] = "true" if payload.llm_structured else "false"
    for name in ("local_model_key", "llm_key"):
        values[name] = checked_key(values[name])
    save_settings(ARCHIVE, values)
    return public_settings(ARCHIVE)


def checked_key(value):
    key = value.strip()
    if key and not re.fullmatch(r"[\x21-\x7e]+", key):
        raise ArchiveError("API 密钥请输入不含空格或换行的可见 ASCII 字符。")
    return key


@app.post("/api/local-models")
def get_local_models(payload: LocalModelConnection):
    key = checked_key(payload.local_model_key)
    if not key and not payload.clear_local_model:
        key = api_key("local_model")
    return {"models": list_local_models(payload.local_model_url, payload.local_provider, key)}


@app.post("/api/snapshots/{snapshot_id}/cloud")
def start_cloud(snapshot_id: int, payload: CloudJob):
    if not public_settings(ARCHIVE)[f"{payload.engine}_ready"]:
        raise ArchiveError("请先在翻译设置中配置这个翻译引擎。")
    if (payload.mode == "candidate") != (payload.block_id is not None):
        raise ArchiveError("单段重译需要有效的段落编号。")
    job_id = ARCHIVE.register_job(snapshot_id, payload.engine, payload.block_id, payload.mode, payload.context)
    app.state.cloud.submit(translate_job, ARCHIVE, job_id)
    return {"id": job_id}


@app.post("/api/cloud-jobs/{job_id}/retry")
def resume_cloud(job_id: int):
    options = public_settings(ARCHIVE)
    ready_engines = {engine for engine in ENGINES if options[f"{engine}_ready"]}
    if ARCHIVE.retry_job(job_id, ready_engines):
        app.state.cloud.submit(translate_job, ARCHIVE, job_id)
    return {"id": job_id}


@app.get("/api/articles/{article_id}/export")
def download(article_id: int, snapshot: int | None = None, marked: bool = False,
             tz: int = Query(default=480, ge=-840, le=840)):
    article = ARCHIVE.article(article_id, snapshot)
    data = export_word(article, marked, tz)
    title = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", article["snapshot"]["title"])[:80].strip(" .")
    filename = (title or "素材对照") + (" · 高亮摘录" if marked else " · 双语对照")
    return word_response(data, filename)


@app.get("/api/export")
def download_collection(tz: int = Query(default=480, ge=-840, le=840)):
    return word_response(export_collection(ARCHIVE.collection(), tz), "素材对照 · 完整归档")


def word_response(data, title):
    return Response(data, media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(title + '.docx')}"})


def browser_binary(preferred):
    if os.name != "nt":
        return None
    roots = [os.environ.get("ProgramFiles(x86)"), os.environ.get("ProgramFiles"), os.environ.get("LocalAppData")]
    names = {"edge": "Microsoft/Edge/Application/msedge.exe", "chrome": "Google/Chrome/Application/chrome.exe"}
    for browser in names if preferred == "auto" else (preferred,):
        for root in filter(None, roots):
            path = Path(root) / names[browser]
            if path.is_file():
                return path
    return None


def existing_server(port):
    connection = http.client.HTTPConnection("127.0.0.1", port, timeout=0.8)
    try:
        connection.request("GET", "/api/health")
        with connection.getresponse() as response:
            return response.status == 200 and json.load(response).get("instance") == INSTANCE
    except (OSError, ValueError, AttributeError, http.client.HTTPException):
        return False
    finally:
        connection.close()


def main():
    parser = argparse.ArgumentParser(description="运行素材对照与高亮归档工具")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--open", action=argparse.BooleanOptionalAction, default=False,
                        help="在桌面浏览器中打开独立阅读面板")
    parser.add_argument("--browser", choices=("auto", "edge", "chrome"), default="auto",
                        help="选择阅读面板使用的桌面浏览器")
    parser.add_argument("--package", action="store_true", help="生成分享用 Windows 压缩包")
    args = parser.parse_args()
    if args.package:
        from build_share import build_package

        print(build_package(), flush=True)
        return
    browser = browser_binary(args.browser) if args.open else None
    if args.open and args.browser != "auto" and not browser:
        parser.exit(1, f"未找到 {args.browser.title()}。请安装该浏览器或使用另一个启动入口。\n")
    address = f"http://127.0.0.1:{args.port}/"

    def open_browser():
        if browser:
            try:
                subprocess.Popen([str(browser), f"--app={address}"])
                return
            except OSError:
                if args.browser != "auto":
                    print(f"无法打开 {args.browser.title()}，可手动访问 {address}", flush=True)
                    return
        webbrowser.open(address)

    if args.open and existing_server(args.port):
        open_browser()
        return
    server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=args.port, access_log=False))

    def open_panel():
        for _ in range(100):
            if server.started:
                open_browser()
                return
            time.sleep(0.1)

    if args.open:
        Thread(target=open_panel, daemon=True).start()
    server.run()


if __name__ == "__main__":
    main()
