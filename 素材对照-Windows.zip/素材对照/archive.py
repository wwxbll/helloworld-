import hashlib
import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

from source import clean_text


class ArchiveError(Exception):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


SCHEMA = """
CREATE TABLE IF NOT EXISTS articles (
    id INTEGER PRIMARY KEY,
    original_url TEXT NOT NULL,
    normalized_url TEXT UNIQUE,
    created_at TEXT NOT NULL,
    checked_at TEXT,
    state TEXT NOT NULL,
    error TEXT,
    sort_position INTEGER
);
CREATE TABLE IF NOT EXISTS snapshots (
    id INTEGER PRIMARY KEY,
    article_id INTEGER NOT NULL REFERENCES articles(id),
    captured_at TEXT NOT NULL,
    kind TEXT NOT NULL,
    title TEXT NOT NULL,
    final_url TEXT NOT NULL,
    author TEXT NOT NULL,
    published TEXT NOT NULL,
    language TEXT NOT NULL,
    partial INTEGER NOT NULL,
    fingerprint TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS snapshots_by_article ON snapshots(article_id, id DESC);
CREATE TABLE IF NOT EXISTS blocks (
    id INTEGER PRIMARY KEY,
    snapshot_id INTEGER NOT NULL REFERENCES snapshots(id),
    position INTEGER NOT NULL,
    kind TEXT NOT NULL,
    text TEXT NOT NULL,
    language TEXT NOT NULL,
    active_translation INTEGER REFERENCES translations(id),
    local_error TEXT,
    UNIQUE(snapshot_id, position)
);
CREATE TABLE IF NOT EXISTS cloud_jobs (
    id INTEGER PRIMARY KEY,
    snapshot_id INTEGER NOT NULL REFERENCES snapshots(id),
    engine TEXT NOT NULL,
    mode TEXT NOT NULL,
    block_ids TEXT NOT NULL,
    context INTEGER NOT NULL,
    state TEXT NOT NULL,
    done INTEGER NOT NULL DEFAULT 0,
    total INTEGER NOT NULL,
    error TEXT,
    created_at TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS one_cloud_job_per_snapshot
    ON cloud_jobs(snapshot_id) WHERE state IN ('queued', 'running');
CREATE TABLE IF NOT EXISTS translations (
    id INTEGER PRIMARY KEY,
    block_id INTEGER NOT NULL REFERENCES blocks(id),
    engine TEXT NOT NULL,
    model TEXT NOT NULL,
    source_language TEXT NOT NULL,
    text TEXT NOT NULL,
    created_at TEXT NOT NULL,
    job_id INTEGER REFERENCES cloud_jobs(id),
    UNIQUE(job_id, block_id)
);
CREATE INDEX IF NOT EXISTS translations_by_block ON translations(block_id, id);
CREATE TABLE IF NOT EXISTS highlights (
    id INTEGER PRIMARY KEY,
    block_id INTEGER NOT NULL REFERENCES blocks(id),
    translation_id INTEGER REFERENCES translations(id),
    start INTEGER NOT NULL,
    end INTEGER NOT NULL,
    selected TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS highlights_by_block ON highlights(block_id, id);
CREATE TABLE IF NOT EXISTS settings (
    name TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS id_counters (
    table_name TEXT PRIMARY KEY,
    last_id INTEGER NOT NULL
);
"""

ID_TABLES = ("articles", "snapshots", "blocks", "cloud_jobs", "translations", "highlights")


class Archive:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.executescript(SCHEMA)
            db.execute("BEGIN IMMEDIATE")
            columns = {column["name"] for column in db.execute("PRAGMA table_info(articles)")}
            if "sort_position" not in columns:
                db.execute("ALTER TABLE articles ADD COLUMN sort_position INTEGER")
            for table in ID_TABLES:
                db.execute(f"INSERT OR IGNORE INTO id_counters SELECT ?, coalesce(max(id), 0) FROM {table}",
                           (table,))

    @staticmethod
    def reserve_ids(db, table, count=1):
        # A delayed browser result or worker must never find a new record at a deleted ID.
        return db.execute("""
            UPDATE id_counters SET last_id=last_id+? WHERE table_name=? RETURNING last_id-?+1
        """, (count, table, count)).fetchone()[0]

    @contextmanager
    def connect(self, write=False):
        db = sqlite3.connect(self.path, timeout=15)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys = ON")
        try:
            if write:
                db.execute("BEGIN IMMEDIATE")
            yield db
            db.commit()
        finally:
            db.close()

    def list_articles(self):
        with self.connect() as db:
            return [dict(row) for row in db.execute("""
                SELECT a.*, s.id AS snapshot_id, s.title, s.language,
                    (SELECT count(*) FROM blocks b WHERE b.snapshot_id=s.id) AS total,
                    (SELECT count(*) FROM blocks b WHERE b.snapshot_id=s.id
                      AND (b.language='zh' OR b.kind='code' OR b.active_translation IS NOT NULL)) AS done
                FROM articles a LEFT JOIN snapshots s ON s.id =
                    (SELECT id FROM snapshots WHERE article_id=a.id ORDER BY id DESC LIMIT 1)
                ORDER BY coalesce(a.sort_position, a.id)
            """)]

    def register(self, original, normalized, manual=False):
        with self.connect(write=True) as db:
            if normalized:
                found = db.execute("SELECT id FROM articles WHERE normalized_url=?", (normalized,)).fetchone()
                if found:
                    return found["id"], False
            state = "manual" if manual else "queued"
            article_id = self.reserve_ids(db, "articles")
            db.execute("""
                INSERT INTO articles(id,original_url,normalized_url,created_at,state) VALUES(?,?,?,?,?)
            """, (article_id, original, normalized, now(), state))
            return article_id, True

    def queue_fetch(self, article_id):
        with self.connect(write=True) as db:
            article = self.require(db, "articles", article_id, "来源")
            if not article["normalized_url"]:
                raise ArchiveError("这篇正文没有来源链接。")
            if article["state"] in ("queued", "fetching"):
                return False
            db.execute("UPDATE articles SET state='queued',error=NULL WHERE id=?", (article_id,))
            return True

    def move_article(self, article_id, direction):
        with self.connect(write=True) as db:
            ordered = db.execute("""
                SELECT id, coalesce(sort_position, id) AS position FROM articles ORDER BY position
            """).fetchall()
            index = next((i for i, row in enumerate(ordered) if row["id"] == article_id), None)
            if index is None:
                raise ArchiveError("未找到这个素材。", 404)
            neighbor = index + (-1 if direction == "up" else 1)
            if not 0 <= neighbor < len(ordered):
                return False
            current, other = ordered[index], ordered[neighbor]
            db.executemany("UPDATE articles SET sort_position=? WHERE id=?",
                           [(other["position"], current["id"]), (current["position"], other["id"])])
            return True

    def claim_fetch(self, article_id):
        with self.connect(write=True) as db:
            row = db.execute("SELECT * FROM articles WHERE id=?", (article_id,)).fetchone()
            if not row or row["state"] != "queued":
                return ""
            db.execute("UPDATE articles SET state='fetching' WHERE id=?", (article_id,))
            return row["normalized_url"]

    def delete_articles(self, article_id=None):
        with self.connect(write=True) as db:
            scope = "SELECT id FROM articles" if article_id is None else "SELECT id FROM articles WHERE id=?"
            params = () if article_id is None else (article_id,)
            snapshots = f"SELECT id FROM snapshots WHERE article_id IN ({scope})"
            blocks = f"SELECT id FROM blocks WHERE snapshot_id IN ({snapshots})"
            db.execute(f"DELETE FROM highlights WHERE block_id IN ({blocks})", params)
            db.execute(f"UPDATE blocks SET active_translation=NULL WHERE id IN ({blocks})", params)
            db.execute(f"DELETE FROM translations WHERE block_id IN ({blocks})", params)
            db.execute(f"DELETE FROM cloud_jobs WHERE snapshot_id IN ({snapshots})", params)
            db.execute(f"DELETE FROM blocks WHERE snapshot_id IN ({snapshots})", params)
            db.execute(f"DELETE FROM snapshots WHERE article_id IN ({scope})", params)
            return db.execute("DELETE FROM articles" if article_id is None else
                              "DELETE FROM articles WHERE id=?", params).rowcount

    def fail_fetch(self, article_id, message):
        with self.connect(write=True) as db:
            db.execute("""
                UPDATE articles SET state='failed',error=?,checked_at=? WHERE id=? AND state='fetching'
            """, (message, now(), article_id))

    def recover(self):
        with self.connect(write=True) as db:
            db.execute("UPDATE articles SET state='queued' WHERE state='fetching'")
            db.execute("""
                UPDATE cloud_jobs
                SET state=CASE WHEN done=total THEN 'ready' WHEN done>0 THEN 'partial' ELSE 'failed' END,
                    error=CASE WHEN done=total THEN NULL ELSE 'DeepL 接口已移除，请重新选择翻译引擎。' END
                WHERE engine='deepl' AND state IN ('queued','running')
            """)
            db.execute("UPDATE cloud_jobs SET state='queued' WHERE state='running'")
            return ([r["id"] for r in db.execute("SELECT id FROM articles WHERE state='queued'")],
                    [r["id"] for r in db.execute("SELECT id FROM cloud_jobs WHERE state='queued'")])

    def save_snapshot(self, article_id, source, kind):
        timestamp = now()
        signature = {key: val for key, val in source.items() if key != "blocks"}
        signature["blocks"] = [(b["kind"], b["text"]) for b in source["blocks"]]
        fingerprint = hashlib.sha256(json.dumps(signature, ensure_ascii=False).encode("utf-8")).hexdigest()
        with self.connect(write=True) as db:
            record = self.require(db, "articles", article_id, "来源")
            if kind != "web" and record["state"] in {"queued", "fetching"}:
                raise ArchiveError("正在抓取这个链接。等抓取结束后可以补充正文。", 409)
            previous = db.execute("""
                SELECT * FROM snapshots WHERE article_id=? ORDER BY id DESC LIMIT 1
            """, (article_id,)).fetchone()
            if previous and previous["kind"] == kind and previous["fingerprint"] == fingerprint:
                snapshot_id = previous["id"]
            else:
                snapshot_id = self.reserve_ids(db, "snapshots")
                db.execute("""
                    INSERT INTO snapshots(id,article_id,captured_at,kind,title,final_url,author,
                                          published,language,partial,fingerprint)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?)
                """, (snapshot_id, article_id, timestamp, kind, source["title"], source["final_url"],
                      source["author"], source["published"], source["language"], int(source["partial"]), fingerprint))
                first_block_id = self.reserve_ids(db, "blocks", len(source["blocks"]))
                db.executemany("""
                    INSERT INTO blocks(id,snapshot_id,position,kind,text,language) VALUES(?,?,?,?,?,?)
                """, [(first_block_id+i-1, snapshot_id, i, block["kind"], block["text"], block["language"])
                      for i, block in enumerate(source["blocks"], 1)])
            db.execute("UPDATE articles SET state=?,checked_at=?,error=NULL WHERE id=?",
                       ("partial" if source["partial"] else "ready", timestamp, article_id))
            return snapshot_id

    def article(self, article_id, snapshot_id=None):
        with self.connect() as db:
            db.execute("BEGIN")
            return self.read_article(db, article_id, snapshot_id)

    def collection(self):
        with self.connect() as db:
            db.execute("BEGIN")
            return [self.read_article(db, row["id"]) for row in db.execute(
                "SELECT id FROM articles ORDER BY coalesce(sort_position, id)"
            )]

    def read_article(self, db, article_id, snapshot_id=None):
        article = dict(self.require(db, "articles", article_id, "来源"))
        snapshots = [dict(r) for r in db.execute("""
            SELECT id,title,captured_at,kind,partial,language FROM snapshots WHERE article_id=? ORDER BY id DESC
        """, (article_id,))]
        if snapshot_id is None and snapshots:
            snapshot_id = snapshots[0]["id"]
        article.update(snapshots=snapshots, snapshot=None, blocks=[], job=None)
        if snapshot_id is None:
            return article
        snapshot = self.require(db, "snapshots", snapshot_id, "正文版本")
        if snapshot["article_id"] != article_id:
            raise ArchiveError("未找到这个正文版本。", 404)
        article["snapshot"] = dict(snapshot)
        blocks = {r["id"]: {**dict(r), "translations": [], "highlights": []} for r in db.execute(
            "SELECT * FROM blocks WHERE snapshot_id=? ORDER BY position", (snapshot_id,)
        )}
        for key in ("translations", "highlights"):
            for r in db.execute(f"""
                SELECT data.* FROM {key} data JOIN blocks b ON data.block_id=b.id
                WHERE b.snapshot_id=? ORDER BY data.id DESC
            """, (snapshot_id,)):
                blocks[r["block_id"]][key].append(dict(r))
        article["blocks"] = list(blocks.values())
        job = db.execute("""
            SELECT * FROM cloud_jobs WHERE snapshot_id=? ORDER BY id DESC LIMIT 1
        """, (snapshot_id,)).fetchone()
        article["job"] = dict(job) if job else None
        return article

    def block(self, block_id):
        with self.connect() as db:
            block = dict(self.require(db, "blocks", block_id, "段落"))
            for key in ("translations", "highlights"):
                block[key] = [dict(r) for r in db.execute(
                    f"SELECT * FROM {key} WHERE block_id=? ORDER BY id DESC", (block_id,)
                )]
            return block

    def local_work(self, excluded):
        with self.connect() as db:
            return [dict(r) for r in db.execute(f"""
                WITH pending AS (
                    SELECT b.id,b.text,b.language,s.article_id,
                           row_number() OVER(PARTITION BY b.language ORDER BY s.article_id,b.position) AS n
                    FROM blocks b JOIN snapshots s ON b.snapshot_id=s.id
                    WHERE b.active_translation IS NULL AND b.local_error IS NULL
                      AND b.kind!='code' AND b.language NOT IN ('zh','und')
                      AND b.language NOT IN ({','.join('?' for _ in excluded) if excluded else "''"})
                      AND s.id=(SELECT id FROM snapshots WHERE article_id=s.article_id ORDER BY id DESC LIMIT 1)
                      AND NOT EXISTS (SELECT 1 FROM cloud_jobs j WHERE j.snapshot_id=s.id
                                      AND j.mode!='candidate' AND j.state IN ('queued','running'))
                )
                SELECT id,text,language,article_id FROM pending WHERE n<=4 ORDER BY article_id,id LIMIT 280
            """, tuple(excluded))]

    def save_local(self, block_id, language, text, error, browser=""):
        with self.connect(write=True) as db:
            block = self.require(db, "blocks", block_id, "段落")
            if block["language"] != language or block["active_translation"] is not None:
                return
            if error:
                db.execute("UPDATE blocks SET local_error=? WHERE id=?", (error, block_id))
                return
            version = self.reserve_ids(db, "translations")
            db.execute("""
                INSERT INTO translations(id,block_id,engine,model,source_language,text,created_at)
                VALUES(?,?,?,?,?,?,?)
            """, (version, block_id, "local", browser, language, text, now()))
            db.execute("UPDATE blocks SET active_translation=?,local_error=NULL WHERE id=?", (version, block_id))

    def set_language(self, block_id, language):
        with self.connect(write=True) as db:
            block = self.require(db, "blocks", block_id, "段落")
            if block["language"] != language:
                db.execute("""
                    UPDATE blocks SET language=?,active_translation=NULL,local_error=NULL WHERE id=?
                """, (language, block_id))

    def retry_local(self, block_id):
        with self.connect(write=True) as db:
            self.require(db, "blocks", block_id, "段落")
            db.execute("UPDATE blocks SET local_error=NULL WHERE id=?", (block_id,))

    def activate(self, block_id, translation_id):
        with self.connect(write=True) as db:
            row = self.require(db, "translations", translation_id, "译文")
            if row["block_id"] != block_id:
                raise ArchiveError("译文与段落不匹配。")
            db.execute("UPDATE blocks SET active_translation=?,local_error=NULL WHERE id=?",
                       (translation_id, block_id))

    def highlight(self, block_id, translation_id, start, end, selected):
        with self.connect(write=True) as db:
            block = self.require(db, "blocks", block_id, "段落")
            text = block["text"]
            if translation_id is not None:
                translation = self.require(db, "translations", translation_id, "译文")
                if translation["block_id"] != block_id:
                    raise ArchiveError("译文与段落不匹配。")
                text = translation["text"]
            if not (0 <= start < end <= len(text)) or text[start:end] != selected or not selected.strip():
                raise ArchiveError("选区已变动，请重新选择文字。", 409)
            found = db.execute("""
                SELECT id FROM highlights WHERE block_id=? AND translation_id IS ? AND start=? AND end=?
            """, (block_id, translation_id, start, end)).fetchone()
            if not found:
                db.execute("""
                    INSERT INTO highlights(id,block_id,translation_id,start,end,selected) VALUES(?,?,?,?,?,?)
                """, (self.reserve_ids(db, "highlights"), block_id, translation_id, start, end, selected))

    def remove_highlight(self, highlight_id):
        with self.connect(write=True) as db:
            row = self.require(db, "highlights", highlight_id, "高亮")
            db.execute("DELETE FROM highlights WHERE id=?", (highlight_id,))
            return row["block_id"]

    def settings(self):
        with self.connect() as db:
            return {r["name"]: r["value"] for r in db.execute("SELECT * FROM settings")}

    def save_settings(self, options):
        with self.connect(write=True) as db:
            db.executemany("""
                INSERT INTO settings(name,value) VALUES(?,?)
                ON CONFLICT(name) DO UPDATE SET value=excluded.value
            """, list(options.items()))

    def register_job(self, snapshot_id, engine, block_id, mode, context):
        with self.connect(write=True) as db:
            self.require(db, "snapshots", snapshot_id, "正文版本")
            if db.execute("""
                SELECT 1 FROM cloud_jobs WHERE snapshot_id=? AND state IN ('queued','running')
            """, (snapshot_id,)).fetchone():
                raise ArchiveError("这篇文章已有翻译任务正在运行。", 409)
            blocks = [r["id"] for r in db.execute("""
                SELECT id FROM blocks WHERE snapshot_id=?
                AND (language!='zh' OR ?='candidate') AND kind!='code'
                AND (? IS NULL OR id=?)
                AND (?!='missing' OR active_translation IS NULL)
                ORDER BY position
            """, (snapshot_id, mode, block_id, block_id, mode))]
            if not blocks:
                raise ArchiveError("没有符合条件的待翻译段落。")
            job_id = self.reserve_ids(db, "cloud_jobs")
            db.execute("""
                INSERT INTO cloud_jobs(id,snapshot_id,engine,mode,block_ids,context,state,total,created_at)
                VALUES(?,?,?,?,?,?,'queued',?,?)
            """, (job_id, snapshot_id, engine, mode, json.dumps(blocks), int(context), len(blocks), now()))
            return job_id

    def claim_job(self, job_id):
        with self.connect(write=True) as db:
            row = db.execute("SELECT * FROM cloud_jobs WHERE id=?", (job_id,)).fetchone()
            if not row or row["state"] != "queued":
                return None, []
            db.execute("UPDATE cloud_jobs SET state='running' WHERE id=?", (job_id,))
            pending = set(json.loads(row["block_ids"]))
            finished = {r[0] for r in db.execute("SELECT block_id FROM translations WHERE job_id=?", (job_id,))}
            blocks = [dict(r) for r in db.execute(
                "SELECT * FROM blocks WHERE snapshot_id=? ORDER BY position", (row["snapshot_id"],)
            )]
            return dict(row), [(b, blocks[i - 1] if i else None, blocks[i + 1] if i + 1 < len(blocks) else None)
                               for i, b in enumerate(blocks) if b["id"] in pending - finished]

    def retry_job(self, job_id, ready_engines):
        with self.connect(write=True) as db:
            job = self.require(db, "cloud_jobs", job_id, "翻译任务")
            if job["engine"] not in ready_engines:
                raise ArchiveError("请先重新配置这个翻译引擎。")
            if job["state"] in {"queued", "running", "ready"}:
                return False
            if db.execute("""
                SELECT 1 FROM cloud_jobs WHERE snapshot_id=? AND state IN ('queued','running')
            """, (job["snapshot_id"],)).fetchone():
                raise ArchiveError("这篇文章已有翻译任务正在运行。", 409)
            latest = db.execute("SELECT max(id) FROM cloud_jobs WHERE snapshot_id=?",
                                (job["snapshot_id"],)).fetchone()[0]
            if latest != job_id:
                raise ArchiveError("请从当前的翻译记录续跑。")
            db.execute("UPDATE cloud_jobs SET state='queued',error=NULL WHERE id=?", (job_id,))
            return True

    def save_cloud(self, job, outputs, label):
        with self.connect(write=True) as db:
            if not db.execute("SELECT 1 FROM cloud_jobs WHERE id=?", (job["id"],)).fetchone():
                return
            for block, text in outputs:
                current = self.require(db, "blocks", block["id"], "段落")
                if current["language"] != block["language"]:
                    continue
                translated = db.execute("""
                    INSERT INTO translations(id,block_id,engine,model,source_language,text,created_at,job_id)
                    VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(job_id,block_id) DO NOTHING
                """, (self.reserve_ids(db, "translations"), block["id"], job["engine"], label,
                      block["language"], clean_text(text), now(), job["id"]))
                if translated.rowcount and (job["mode"] == "all" or
                                             (job["mode"] == "missing" and current["active_translation"] is None)):
                    db.execute("UPDATE blocks SET active_translation=?,local_error=NULL WHERE id=?",
                               (translated.lastrowid, block["id"]))
            db.execute("""
                UPDATE cloud_jobs SET done=(SELECT count(*) FROM translations WHERE job_id=?) WHERE id=?
            """, (job["id"], job["id"]))

    def finish_job(self, job_id, error=None):
        with self.connect(write=True) as db:
            db.execute("""
                UPDATE cloud_jobs SET state=CASE WHEN done=total THEN 'ready'
                                             WHEN done>0 THEN 'partial' ELSE 'failed' END,
                    error=CASE WHEN done=total THEN NULL ELSE ? END
                WHERE id=?
            """, (error or "部分段落未完成，需要重试或检查语种。", job_id))

    def snapshot_title(self, snapshot_id):
        with self.connect() as db:
            row = db.execute("SELECT title FROM snapshots WHERE id=?", (snapshot_id,)).fetchone()
            return row["title"] if row else ""

    def job_exists(self, job_id):
        with self.connect() as db:
            return bool(db.execute("SELECT 1 FROM cloud_jobs WHERE id=?", (job_id,)).fetchone())

    @staticmethod
    def require(db, table, identifier, label):
        row = db.execute(f"SELECT * FROM {table} WHERE id=?", (identifier,)).fetchone()
        if row is None:
            raise ArchiveError(f"未找到{label}。", 404)
        return row
