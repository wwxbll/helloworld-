@echo off
call "%~dp0start.cmd" --package
if not errorlevel 1 pause
